package borg.trikeshed.web

import borg.trikeshed.landscape.LandscapeMomentum
import borg.trikeshed.landscape.LandscapeNavigation
import kotlinx.browser.document
import kotlinx.browser.window
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign

/**
 * patch-camera.js: the camera both construction surfaces use; navigation never edits a graph.
 * [harness] is the blackboard's Harness object on /blackboard, null on /panels.
 */
class PatchCamera(private val s: PatchSurface, private val harness: () -> dynamic = { null }) {
    private class Binding(val target: dynamic, val type: String, val handler: (dynamic) -> Unit,
                          val admitted: (dynamic) -> Unit, val options: dynamic)
    private val bindings = mutableListOf<Binding>()
    private var closed = false
    private fun on(target: dynamic, type: String, handler: (dynamic) -> Unit, options: dynamic = undefined) {
        check(!closed) { "Camera is closed" }
        val admitted: (dynamic) -> Unit = { if (!closed) handler(it) }
        bindings.add(Binding(target, type, handler, admitted, options))
        borg.trikeshed.web.on(target, type, admitted, options)
    }
    private fun off(target: dynamic, type: String, handler: (dynamic) -> Unit) {
        val index = bindings.indexOfFirst { it.target === target && it.type == type && it.handler === handler }
        if (index < 0) return
        val binding = bindings.removeAt(index)
        borg.trikeshed.web.off(binding.target, binding.type, binding.admitted, binding.options)
    }
    private val view get() = s.view
    private val viewport get() = s.viewport

    fun scopeZoomCeiling(px: Double, py: Double, camera: dynamic = view): Double {
        // Screen pixels of slop the pointer gets when aiming at a scope, so a deeply nested
        // one stays reachable after it shrinks below a pixel.
        val pickMinPx = 12.0
        val viewportBox = viewport.getBoundingClientRect()
        val wx = (px - num(camera.x)) / num(camera.z); val wy = (py - num(camera.y)) / num(camera.z)
        val regions = HashMap<Any, dynamic>()
        fun region(n: dynamic): dynamic {
            if (regions.containsKey(n)) return regions[n]
            val host = n._childHost
            val r = host?.getBoundingClientRect()
            val box: dynamic = if (r != null && num(host.offsetWidth) > 0 && num(r.width) > 0 && num(r.height) > 0 && !truthy(n.collapsed) &&
                n.el?.classList?.contains("collapsed") != true) {
                val b = obj()
                b.x = (num(r.left) - viewportBox.left - num(view.x)) / num(view.z)
                b.y = (num(r.top) - viewportBox.top - num(view.y)) / num(view.z)
                b.w = num(r.width) / num(view.z); b.h = num(r.height) / num(view.z)
                b.scale = num(r.width) / num(host.offsetWidth) / num(view.z) * (if (truthy(n._view?.z)) num(n._view.z) else 1.0)
                b
            } else null
            regions[n.unsafeCast<Any>()] = box
            return box
        }
        fun contains(b: dynamic): Boolean {
            if (b == null) return false
            val slop = pickMinPx / num(camera.z)
            val padX = max(0.0, (slop - num(b.w)) / 2); val padY = max(0.0, (slop - num(b.h)) / 2)
            return wx >= num(b.x) - padX && wy >= num(b.y) - padY && wx <= num(b.x) + num(b.w) + padX && wy <= num(b.y) + num(b.h) + padY
        }
        var scale = 1.0; var depth = -1
        for (n in s.nodes()) {
            if (!truthy(n._childHost)) continue
            val box = region(n); if (!contains(box)) continue
            var level = 0; var visible = true
            var p = n._parentScope
            while (truthy(p)) { level++; if (!contains(region(p))) { visible = false; break }; p = p._parentScope }
            if (visible && level > depth) { scale = num(box.scale); depth = level }
        }
        return LandscapeNavigation.maxZoom(scale)
    }

    fun restoreCameraView(camera: dynamic) {
        killMomentum()
        if (camera == null || !listOf(camera.x, camera.y, camera.z).all { typeOf(it) == "number" && num(it).isFinite() } || num(camera.z) <= 0) return
        val r = viewport.getBoundingClientRect(); val ax = r.width / 2; val ay = r.height / 2
        val c = LandscapeNavigation.zoomAt(PatchNavigation.camera(camera), num(camera.z), borg.trikeshed.landscape.Pt(ax, ay), scopeZoomCeiling(ax, ay, camera))
        view.x = c.x; view.y = c.y; view.z = c.z
    }

    private var cameraDetailRoot: dynamic = null
    fun restoreCameraDetail() {
        if (cameraDetailRoot == null) return
        val n = cameraDetailRoot; val v = n._view
        n._childHost.appendChild(n._ringWorld)
        n._ringWorld.style.transform = "translate(${v.x}px,${v.y}px) scale(${v.z})"
        n._ringWorld.style.zIndex = ""; cameraDetailRoot = null
    }

    fun projectCameraDetail() {
        val h = harness() ?: return
        val root = cameraDetailRoot
        if (root != null && (!truthy(root.el.isConnected) || truthy(root.collapsed) || root._program != h.selected)) restoreCameraDetail()
        val vr = viewport.getBoundingClientRect()
        fun project(n: dynamic): Boolean {
            val host = n._childHost; val r = host.getBoundingClientRect(); val scale = num(r.width) / num(host.offsetWidth); val v = n._view
            if (!scale.isFinite() || scale <= 0) return false
            n._ringWorld.style.transform = "matrix(${scale * num(v.z)},0,0,${scale * num(v.z)},${num(r.left) - vr.left + num(v.x) * scale},${num(r.top) - vr.top + num(v.y) * scale})"
            return true
        }
        if (cameraDetailRoot != null && !project(cameraDetailRoot)) restoreCameraDetail()
        var next: dynamic = null; var depth = -1
        if (num(view.z) > DETAIL_LIFT_ZOOM) for (n in s.nodes()) {
            if (!truthy(n._childHost) || !truthy(n.el.isConnected) || truthy(n.collapsed) || n._program != h.selected) continue
            val r = n._childHost.getBoundingClientRect()
            if (num(r.left) > vr.left || num(r.top) > vr.top || num(r.right) < vr.right || num(r.bottom) < vr.bottom) continue
            var level = 0; var visible = true
            var p = n._parentScope
            while (truthy(p)) {
                level++; val b = p._childHost.getBoundingClientRect()
                if (truthy(p.collapsed) || num(b.left) > vr.left || num(b.top) > vr.top || num(b.right) < vr.right || num(b.bottom) < vr.bottom) { visible = false; break }
                p = p._parentScope
            }
            if (visible && level > depth) { next = n; depth = level }
        }
        if (next === cameraDetailRoot) return
        restoreCameraDetail()
        if (next != null) {
            // Only lift a window covering the entire viewport, so clipping is intact.
            cameraDetailRoot = next; viewport.appendChild(next._ringWorld)
            next._ringWorld.style.zIndex = "3"; project(next)
        }
    }

    /** set after construction by the shake module: badges ride the camera */
    var projectVerdicts: () -> Unit = {}
    /** set by the blackboard: its landscape repaints on every camera move */
    var landscapeSchedule: () -> Unit = {}

    fun applyView() {
        s.blipLeave()
        // Matrix translations are numbers, not CSS lengths (which clamp around 33 million px).
        s.world.style.transform = "matrix(${view.z},0,0,${view.z},${view.x},${view.y})"
        projectCameraDetail()
        s.applyWireBox()
        projectVerdicts()
        document.body!!.classList.toggle("zoomed-out", num(view.z) < .45)
        landscapeSchedule()
        val h = harness()
        if (h != null) {
            h.rememberView()
            val breakout = document.getElementById("panelsBreakout").asDynamic()
            if (breakout != null) breakout.href = "/panels" + (if (truthy(h.selected))
                "?" + (if (truthy(h.previews.has(h.selected))) "example" else "load") + "=" + encodeURIComponent(str(h.selected)) else "")
        }
    }

    /* momentum — the common LandscapeMomentum: pan velocity in screen px/ms, zoom velocity in
       log-scale per 16.7ms anchored at the last wheel point. Off under prefers-reduced-motion. */
    val reducedMotion: Boolean = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    private val momentum = LandscapeMomentum(reducedMotion)
    private var momFrame = 0

    fun killMomentum() = momentum.kill()

    private fun now(): Double = window.performance.now()

    private fun tickMomentum() {
        momFrame = 0
        val g = momentum.frame(now()) ?: return
        view.x = num(view.x) + g.dx; view.y = num(view.y) + g.dy
        if (g.factor != 1.0) {
            val ceiling = scopeZoomCeiling(g.ax, g.ay)
            val before = num(view.z)
            PatchNavigation.zoomAt(view, num(view.z) * g.factor, g.ax, g.ay, ceiling)
            val h = harness()
            if (num(view.z) > before && h != null) h.observeZoom(g.ax, g.ay)
            momentum.landed(g, before, num(view.z), ceiling)
        }
        applyView()
        if (momentum.live) glide() else saveCameraSoon()
    }

    private fun glide() { if (momFrame == 0) momFrame = window.requestAnimationFrame { tickMomentum() } }

    private var camSaveT = 0
    /** Blackboard navigation saves only its bookmark; /panels saves and rewrites the hash. */
    fun saveCameraSoon() {
        if (closed) return
        window.clearTimeout(camSaveT)
        val h = harness()
        if (h != null) { h.rememberView(); return }
        camSaveT = window.setTimeout({
            s.save()
            val url = jsNew(js("URL"), window.location.href)
            url.hash = PatchNavigation.encode(view)
            window.history.replaceState(null, "", url)
        }, 250)
    }

    /** deltaMode: 0=pixel, 1=line, 2=page. Firefox sends lines. */
    private fun wheelPixels(e: dynamic, rectHeight: Double): Double =
        LandscapeMomentum.wheelPixels(num(e.deltaY), num(e.deltaMode).toInt(), rectHeight)

    fun install() {
        check(!closed) { "Camera is closed" }
        on(viewport, "pointerdown", { e ->
            if (e.button != 0) return@on
            val hb = harness(); if (hb != null) hb.terrainBookmark = null
            val sx = num(e.clientX); val sy = num(e.clientY); val ox = num(view.x); val oy = num(view.y)
            momentum.press(sx, sy, now())
            viewport.classList.add("panning")
            lateinit var mv: (dynamic) -> Unit
            lateinit var up: (dynamic) -> Unit
            mv = { ev ->
                view.x = ox + num(ev.clientX) - sx; view.y = oy + num(ev.clientY) - sy; applyView()
                momentum.drag(num(ev.clientX), num(ev.clientY), now())
            }
            up = {
                viewport.classList.remove("panning"); off(window, "pointermove", mv); off(window, "pointerup", up); saveCameraSoon()
                if (momentum.release(now())) glide()
            }
            on(window, "pointermove", mv); on(window, "pointerup", up)
        })
        val passive = obj(); passive.passive = false
        on(viewport, "wheel", { e ->
            e.preventDefault()
            val r = viewport.getBoundingClientRect()
            val px = num(e.clientX) - r.left; val py = num(e.clientY) - r.top
            val dy = wheelPixels(e, r.height)
            // proportional step: a trackpad sends many small deltas where a mouse sends few large ones
            val f = LandscapeNavigation.wheelFactor(dy); val before = num(view.z)
            val ceiling = scopeZoomCeiling(px, py)
            PatchNavigation.zoomAt(view, num(view.z) * f, px, py, ceiling)
            val h = harness()
            if (num(view.z) > before && h != null) h.observeZoom(px, py)
            applyView(); saveCameraSoon()
            if (momentum.wheel(px, py, f, before, num(view.z), ceiling, now())) glide()
        }, passive)
    }

    /** Release the mounted camera's callbacks without scheduling another save or momentum frame. */
    fun close() {
        if (closed) return
        closed = true
        var failure: Throwable? = null
        fun release(action: () -> Unit) {
            try { action() } catch (caught: Throwable) {
                if (failure == null) failure = caught else if (failure !== caught) failure?.addSuppressed(caught)
            }
        }
        release { killMomentum() }
        release { window.cancelAnimationFrame(momFrame) }
        release { window.clearTimeout(camSaveT) }
        momFrame = 0; camSaveT = 0
        release { viewport.classList.remove("panning") }
        release { restoreCameraDetail() }
        for (binding in bindings) release { borg.trikeshed.web.off(binding.target, binding.type, binding.admitted, binding.options) }
        bindings.clear()
        failure?.let { throw it }
    }

    companion object {
        /** zoom past which a covering scope is re-projected at its own scale instead of magnifying #world's raster */
        const val DETAIL_LIFT_ZOOM = 8.0
    }
}
