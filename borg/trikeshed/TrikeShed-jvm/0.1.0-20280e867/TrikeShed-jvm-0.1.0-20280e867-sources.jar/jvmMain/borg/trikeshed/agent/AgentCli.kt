package borg.trikeshed.agent

import borg.trikeshed.lcnc.AgentCliInfo
import borg.trikeshed.userspace.nio.channels.spi.JvmProcessProtocolPipes
import borg.trikeshed.userspace.nio.file.spi.*
import borg.trikeshed.userspace.nio.process.ProcessCaptureChannel
import borg.trikeshed.userspace.nio.spi.NioSupervisor
import kotlinx.coroutines.*
import java.io.File

/**
 * The roster of coding-agent CLIs on this host: which binaries exist, how each is run
 * non-interactively, and how its answer is read back. Probed once at boot with a
 * bounded `--version`; `which` is never trusted here because on the owner's Mac it
 * resolves to cmux shims, so the probe walks real directories and skips shim dirs.
 *
 * The roster is codex and opencode, both enabled by default. It is the owner's board
 * and the owner's product surface: a vendor does not get a lane in it, or a name
 * rendered on a card, for free.
 */
class AgentCli(
    val id: String,
    val binary: String,
    /** How the brief reaches the CLI: on stdin (codex) or as the last argument (opencode). */
    val briefOnStdin: Boolean,
    private val argv: (scratch: File, model: String, lastMessage: File, brief: String) -> List<String>,
) {
    fun command(scratch: File, model: String, lastMessage: File, brief: String): List<String> = argv(scratch, model, lastMessage, brief)

    companion object {
        const val CODEX = "codex"
        const val OPENCODE = "opencode"
        val DEFAULT_ENABLED: Set<String> = setOf(CODEX, OPENCODE)
        val KNOWN: List<String> = listOf(CODEX, OPENCODE)

        /** Directories a real install lands in, in order; then the PATH walk minus shim and temp dirs. */
        fun candidateDirs(home: String = System.getProperty("user.home") ?: "", path: String = System.getenv("PATH") ?: "", tmp: String = System.getenv("TMPDIR") ?: ""): List<String> {
            val fixed = listOf("/opt/homebrew/bin", "$home/.local/bin", "/usr/local/bin")
            val walked = path.split(File.pathSeparatorChar).filter { it.isNotBlank() }
                .filter { !it.contains("cmux-cli-shims") && (tmp.isBlank() || !it.startsWith(tmp.trimEnd('/'))) }
            return (fixed + walked).distinct()
        }

        fun definition(id: String, binary: String): AgentCli = when (id) {
            CODEX -> AgentCli(id, binary, briefOnStdin = true) { scratch, model, last, _ ->
                buildList {
                    add(binary); add("exec"); add("--json"); add("-C"); add(scratch.absolutePath)
                    add("-s"); add("workspace-write"); add("--ephemeral"); add("--skip-git-repo-check")
                    add("-o"); add(last.absolutePath)
                    if (model.isNotBlank()) { add("-m"); add(model) }
                    add("-")
                }
            }
            OPENCODE -> AgentCli(id, binary, briefOnStdin = false) { scratch, model, _, brief ->
                buildList {
                    add(binary); add("run"); add("--format"); add("json"); add("--dir"); add(scratch.absolutePath); add("--auto")
                    if (model.isNotBlank()) { add("-m"); add(model) }
                    add(brief)
                }
            }
            else -> throw IllegalArgumentException("unknown agent id '$id'")
        }

        /** A resolved roster: every known id, found or not, with the reason it is not offered. */
        suspend fun probe(enabled: Set<String>, dirs: List<String> = candidateDirs(), versionTimeoutMs: Long = 5_000L): List<AgentCliInfo> = withContext(fileIoContext) {
            val context = currentCoroutineContext()
            val files = context[FileOperations] ?: context[NioSupervisor]?.service<FileOperations>() ?: JvmFileOperations()
            KNOWN.map { id ->
                val found = dirs.asSequence().map { File(it, id) }.firstOrNull { files.isFile(it.path) && it.canExecute() }
                when {
                    found == null -> AgentCliInfo(id, "", "", enabled = false, why = "not installed in ${dirs.take(3).joinToString(", ")} or on PATH")
                    id !in enabled -> AgentCliInfo(id, found.absolutePath, version(found, versionTimeoutMs), enabled = false, why = "installed; enable with --agents")
                    else -> {
                        val v = version(found, versionTimeoutMs)
                        if (v.isEmpty()) AgentCliInfo(id, found.absolutePath, "", enabled = false, why = "--version gave nothing within ${versionTimeoutMs} ms")
                        else AgentCliInfo(id, found.absolutePath, v, enabled = true)
                    }
                }
            }
        }

        /** `<binary> --version`, bounded capture through the same owned process boundary as agent runs. */
        suspend fun version(binary: File, timeoutMs: Long): String = try {
            require(timeoutMs > 0)
            val pipes = JvmProcessProtocolPipes.open(command = { _, _ -> listOf(binary.absolutePath, "--version") },
                environment = AgentEnvironment.build(System.getenv(), listOf(binary.parent)), mergeError = true)
            val capture = try { ProcessCaptureChannel(currentCoroutineContext(), pipes, maxBytes = 16_384, timeoutMillis = timeoutMs) }
            catch (failure: Throwable) {
                withContext(NonCancellable) {
                    try { pipes.close() } catch (cleanup: Throwable) { if (cleanup !== failure) failure.addSuppressed(cleanup) }
                }
                throw failure
            }
            val result = capture.await()
            if (result.timedOut || result.exit != 0) ""
            else result.text().lineSequence().take(4).firstOrNull { it.isNotBlank() }?.trim().orEmpty().take(120)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) { "" }
    }
}
