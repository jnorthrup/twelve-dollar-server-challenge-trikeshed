package borg.trikeshed.cas

import borg.trikeshed.pijul.GitPijulGateway
import borg.trikeshed.userspace.containment.EntropyPathScanner
import java.io.File

/**
 * N-way Pijul merge of every unmerged origin branch — the one-shot CLI from
 * d5061224b (flywheel/cli/FunnelMergeBranchesCli, deleted with the flywheel in
 * 4790932e5) brought back on the [GitPijulGateway], branch arms only.
 *
 * What stayed from the original: arms = unmerged `origin/<branch>` branches, one
 * channel seeded from master, the isolated `git worktree` preflight, the
 * conflict-marker scan, the `./gradlew jvmMainClasses` gate, one commit,
 * `merge --ff-only` into master, push. What went: the WAL/CAS arms, the
 * per-session tags and WorkDrained receipts (the flywheel's), and the
 * CrossInstanceCollusionDetector (never re-added — overlapping files are the
 * CRDT's job). What is new: the gate does the coordinate conversion and
 * content-addressing, and same-locus divergence is POSTED and must be
 * resolved by a table before anything lands.
 *
 * Usage:
 *   FunnelMergeBranchesCli <repoDir> --report [--since YYYY-MM-DD]
 *   FunnelMergeBranchesCli <repoDir> --resolve <table> [--since …] [--subject "…"] [--push]
 *
 * `--report` never writes to the repo. `--resolve` lands only when every
 * posted locus has a line in the table and the build gate is green.
 */
fun main(args: Array<String>) {
    val positional = args.filter { !it.startsWith("--") }
    val repoDir = File(positional.firstOrNull() ?: ".")
    require(repoDir.isDirectory && File(repoDir, ".git").exists()) { "usage: FunnelMergeBranchesCli <repoDir> …: $repoDir is not a git repo" }
    fun opt(name: String): String? = args.indexOf(name).takeIf { it >= 0 }?.let { args.getOrNull(it + 1) }
    val since = opt("--since") ?: "2026-08-01"
    val table = opt("--resolve")?.let { File(it) }
    val report = args.contains("--report") || table == null
    val push = args.contains("--push")
    val subject = opt("--subject")
    val exit = FunnelMergeBranchesCli(repoDir, since).run(report, table, subject, push)
    if (exit != 0) kotlin.system.exitProcess(exit)
}

class FunnelMergeBranchesCli(private val repoDir: File, private val since: String) {


    private data class ArmSource(val ref: String, val date: String, val dropped: List<String>)

    fun run(report: Boolean, table: File?, subject: String?, push: Boolean): Int {
        git("fetch", "origin", "--prune")
        val baseSha = git("rev-parse", "HEAD").second.trim()
        val branch = git("rev-parse", "--abbrev-ref", "HEAD").second.trim()
        require(branch == "master") { "not on master (on $branch)" }
        val dirty = git("status", "--porcelain").second.lineSequence().filter { it.length > 3 }.map { it.substring(3).trim().substringAfter(" -> ") }.toSet()

        // ── arms ──────────────────────────────────────────────────────────
        // Each branch's OWN change: its diff against its merge-base with master. Every hunk is
        // then re-anchored on master's current text by content (GitPijulGateway.rebase): a hunk
        // master already contains is SUPERSEDED, one master rewrote is STALE, both dropped and
        // reported; EXACT and RELOCATED hunks are the arm. (An octopus common base with master
        // as an arm was tried first: git cuts the same edit into different hunk shapes on the
        // two sides, the ids differ, and the edit lands twice — the build gate caught it.)
        val refs: List<Pair<String, String>> = git("for-each-ref", "--sort=committerdate", "--format=%(committerdate:short) %(refname:short)", "refs/remotes/origin").second
            .lineSequence().map { it.trim() }.filter { it.isNotEmpty() }
            .map { it.substringBefore(' ') to it.substringAfter(' ') }
            .filter { (d, r) -> d >= since && r != "origin/master" && r != "origin/HEAD" && r != "origin" }
            .toList()
        val arms = ArrayList<GitPijulGateway.Arm>()
        val sources = LinkedHashMap<String, ArmSource>()
        val outcomes = LinkedHashMap<String, MutableList<String>>()
        val live = refs.filter { (_, ref) -> git("rev-list", "--count", "master..$ref").second.trim() != "0" }
        val skippedMerged = refs.size - live.size
        if (live.isEmpty()) { println("[FUNNEL-MERGE] since=$since refs=${refs.size} — every branch is already in master"); return 0 }
        val masterText = HashMap<String, String>()
        fun masterFile(path: String): String = masterText.getOrPut(path) { git("show", "master:$path").let { if (it.first == 0) it.second else "" } }
        for ((date, ref) in live) {
            val diff = git("diff", "--no-color", "master...$ref")
            if (diff.first != 0 || diff.second.isBlank()) continue
            val all = GitPijulGateway.hunksOf(diff.second)
            val dropped = all.map { it.path }.distinct().filterNot(GitPijulGateway::isProductionPath)
            val production = all.filter { GitPijulGateway.isProductionPath(it.path) }
            val label = ref.removePrefix("origin/")
            val newPaths = production.map { it.path }.distinct().filter { git("cat-file", "-e", "master:$it").first != 0 }
            val quarantined = EntropyPathScanner.scanTouchedPaths(newPaths).map { it.path }.toSet()
            if (quarantined.isNotEmpty()) println("[FUNNEL-MERGE] QUARANTINE $label: new paths with entropy > 3.5 dropped: $quarantined")
            // Resurrection guard (Jim's rule: kept merges must not bring owner-deleted files back):
            // a path the branch adds that master's history has deleted is a deletion being undone.
            val resurrected = newPaths.filter { it !in quarantined }.filter { path ->
                git("log", "--diff-filter=D", "-1", "--format=%h", "master", "--", path).second.isNotBlank()
            }.toSet()
            if (resurrected.isNotEmpty()) println("[FUNNEL-MERGE] RESURRECTION refused for $label: $resurrected")
            val log = outcomes.getOrPut(label) { ArrayList() }
            val kept = ArrayList<GitPijulGateway.Hunk>()
            for (h in production) {
                if (h.path in quarantined || h.path in resurrected) continue
                when (val r = GitPijulGateway.rebase(h, masterFile(h.path))) {
                    is GitPijulGateway.Rebased.Exact -> kept.add(r.hunk)
                    is GitPijulGateway.Rebased.Relocated -> { kept.add(r.hunk); log.add("relocated ${h.path}:L${r.from}→L${r.hunk.lo}") }
                    is GitPijulGateway.Rebased.Superseded -> log.add("superseded ${h.path}:L${h.lo} (master already has it)")
                    is GitPijulGateway.Rebased.Stale -> log.add("stale ${h.path}:L${h.lo} (master rewrote those lines)")
                }
            }
            sources[label] = ArmSource(ref, date, dropped + quarantined + resurrected)
            if (kept.isEmpty()) { println("[FUNNEL-MERGE] $label: nothing left to merge — ${log.joinToString("; ").ifEmpty { "scratch/quarantined paths only" }}"); continue }
            arms.add(GitPijulGateway.Arm(label, kept))
        }
        println("[FUNNEL-MERGE] since=$since refs=${refs.size} alreadyMerged=$skippedMerged arms=${arms.size} head=${baseSha.take(12)}")
        for ((label, log) in outcomes) if (log.isNotEmpty()) println("[FUNNEL-MERGE] $label: " + log.joinToString("; "))

        // ── plan ──────────────────────────────────────────────────────────
        val resolutions = table?.let { GitPijulGateway.parseResolutions(it.readText()) } ?: emptyMap()
        val plan = GitPijulGateway.plan(arms, resolutions)
        printReport(plan, sources)
        if (report) return 0
        if (plan.unresolved.isNotEmpty()) {
            System.err.println("[FUNNEL-MERGE] ${plan.unresolved.size} posted loci without a resolution — nothing lands")
            return 2
        }
        val unknown = resolutions.keys - plan.groups.map { it.locus }.toSet()
        if (unknown.isNotEmpty()) { System.err.println("[FUNNEL-MERGE] resolutions name loci that do not exist: $unknown"); return 2 }

        // ── render into an isolated worktree ─────────────────────────────
        val tempRoot = java.nio.file.Files.createTempDirectory("funnel-merge-").toFile()
        val worktree = File(tempRoot, "worktree")
        try {
            if (git("worktree", "add", "--detach", worktree.absolutePath, baseSha).first != 0) { System.err.println("[FUNNEL-MERGE] worktree add failed"); return 3 }
            val touched = plan.survivors.keys.sorted()
            for (path in touched) {
                val target = File(worktree, path)
                val rendered = GitPijulGateway.render(masterFile(path), plan.survivors.getValue(path))
                if (rendered.isEmpty() && target.isFile) target.delete()
                else { target.parentFile?.mkdirs(); target.writeText(rendered) }
            }
            gitIn(worktree, "add", "-A", "--", *touched.toTypedArray())
            val staged = gitIn(worktree, "diff", "--cached", "--unified=0").second
            if (staged.lineSequence().any { it.startsWith("+<<<<<<< ") || it == "+=======" || it.startsWith("+>>>>>>> ") }) {
                System.err.println("[FUNNEL-MERGE] rendered result contains conflict markers — aborting"); return 3
            }
            val names = gitIn(worktree, "diff", "--cached", "--name-only").second.trim()
            if (names.isBlank()) { println("[FUNNEL-MERGE] no delta vs master — everything already present"); return 0 }
            val stagedPaths = names.lines().map { it.trim() }.filter { it.isNotEmpty() }
            // Render-drift gate: a path may differ from master ONLY if a branch hunk survived on it.
            // Only paths with a surviving branch hunk may be written; anything else staged is a render fault.
            val drift = stagedPaths.filter { it !in plan.survivors.keys }
            if (drift.isNotEmpty()) { System.err.println("[FUNNEL-MERGE] RENDER DRIFT — master-only files came out different, aborting: $drift"); return 3 }
            val overlap = stagedPaths.filter { it in dirty }
            if (overlap.isNotEmpty()) { System.err.println("[FUNNEL-MERGE] working tree has uncommitted edits in paths this merge changes: $overlap — commit or park them first"); return 3 }
            println("[FUNNEL-MERGE] staged (${stagedPaths.size}):\n" + stagedPaths.joinToString("\n") { "  $it" })

            // ── build gate ────────────────────────────────────────────────
            val gate = gradle(worktree, "jvmMainClasses")
            if (gate.first != 0) { System.err.println("[FUNNEL-MERGE] BUILD RED — nothing landed:\n" + gate.second.takeLast(4000)); return 4 }
            println("[FUNNEL-MERGE] build gate green")

            // ── commit, fast-forward, push ────────────────────────────────
            val msg = buildString {
                append(subject ?: "funnel ${arms.size}-way merge — ${plan.groups.count { it.converged }} loci converged, ${plan.groups.size - plan.groups.count { it.converged }} resolved")
                append("\n\nEvery unmerged origin branch since $since, absorbed through the Pijul gateway: each\n")
                append("branch's own hunks re-anchored on master by content; what master already had or\n")
                append("rewrote is dropped and named below. Through the\n")
                append("Pijul gateway (GitPijulGateway): hunks content-addressed, identical edits applied\n")
                append("once, same-locus divergence resolved by the table below, scratch paths refused.\n")
                append("\nArms (${arms.size}):\n")
                for (a in arms) append("  ${a.label}  (${sources[a.label]?.date}, ${a.hunks.size} hunks)\n")
                val notes = outcomes.filter { it.value.isNotEmpty() }
                if (notes.isNotEmpty()) { append("\nRe-anchoring:\n"); for ((l, log) in notes) append("  $l: ${log.joinToString("; ")}\n") }
                val nonProd = sources.filter { it.value.dropped.isNotEmpty() }
                if (nonProd.isNotEmpty()) {
                    append("\nRefused as scratch / gh-pages (never committed):\n")
                    for ((l, s) in nonProd) append("  $l: ${s.dropped.joinToString(", ")}\n")
                }
                if (resolutions.isNotEmpty()) {
                    append("\nResolutions:\n")
                    for ((locus, r) in resolutions) append("  $locus → " + when (r) { is GitPijulGateway.Resolution.Accept -> "accept ${r.arm}"; GitPijulGateway.Resolution.Reject -> "reject" } + "\n")
                }
                append("\nThe commutativity laws in PijulCrdtPropertyTest are unskipped and green;\nthe gateway applies survivors bottom-up per path so the render is a function of the set.\n")
            }
            val commit = gitIn(worktree, "commit", "--no-verify", "-q", "-m", msg)
            if (commit.first != 0) { System.err.println("[FUNNEL-MERGE] commit failed: ${commit.second.take(400)}"); return 5 }
            val revision = gitIn(worktree, "rev-parse", "HEAD").second.trim()
            if (git("rev-parse", "HEAD").second.trim() != baseSha) {
                System.err.println("[FUNNEL-MERGE] master moved during preflight — aborting"); return 6
            }
            val ff = git("merge", "--ff-only", revision)
            if (ff.first != 0) { System.err.println("[FUNNEL-MERGE] ff failed: ${ff.second.take(400)}"); return 6 }
            println("[FUNNEL-MERGE] LANDED $revision on master (${arms.size} arms, one commit)")
            if (push) {
                val p = git("push", "origin", "master")
                println(if (p.first == 0) "[FUNNEL-MERGE] pushed origin/master" else "[FUNNEL-MERGE] push failed: ${p.second.take(400)}")
                if (p.first != 0) return 7
            }
            return 0
        } finally {
            git("worktree", "remove", "--force", worktree.absolutePath)
            git("worktree", "prune")
            tempRoot.deleteRecursively()
        }
    }

    private fun printReport(plan: GitPijulGateway.Plan, sources: Map<String, ArmSource>) {
        val byPath = plan.groups.groupBy { it.path }
        for ((path, gs) in byPath) {
            val conv = gs.filter { it.converged }
            val posted = gs.filterNot { it.converged }
            if (posted.isEmpty()) {
                val arms = conv.flatMap { g -> g.variants.flatMap { it.arms } }.distinct()
                println("CONVERGED $path  hunks=${conv.size} arms=${arms.size} [${arms.joinToString(" ")}] loci=${conv.joinToString(" ") { it.locus.substringAfterLast(':') }}")
            } else {
                if (conv.isNotEmpty()) println("CONVERGED $path  hunks=${conv.size} (outside the posted loci)")
                for (g in posted) {
                    println("POSTED ${g.locus}  variants=${g.variants.size}")
                    for (v in g.variants) {
                        println("   ${v.hunk.hex}  arms=[${v.arms.joinToString(" ")}]")
                        if (v.hunk.deleteCount > 0) println("      -L${v.hunk.deleteStart}" + (if (v.hunk.deleteCount > 1) "..${v.hunk.deleteStart + v.hunk.deleteCount - 1}" else "") + " (${v.hunk.deleteCount} lines)")
                        for (l in v.hunk.inserted.take(12)) println("      + $l")
                        if (v.hunk.inserted.size > 12) println("      + … ${v.hunk.inserted.size - 12} more")
                    }
                }
            }
        }
        val refused = sources.filter { it.value.dropped.isNotEmpty() }
        if (refused.isNotEmpty()) {
            println("REFUSED paths (scratch / gh-pages), never merged:")
            for ((l, s) in refused) println("   $l: ${s.dropped.joinToString(", ")}")
        }
        println("[FUNNEL-MERGE] groups=${plan.groups.size} converged=${plan.groups.count { it.converged }} posted=${plan.unresolved.size} rejected=${plan.rejected.size} filesToWrite=${plan.survivors.size}")
    }

    private fun git(vararg args: String): Pair<Int, String> = gitIn(repoDir, *args)

    private fun gitIn(dir: File, vararg args: String): Pair<Int, String> {
        val pb = ProcessBuilder(listOf("git") + args).directory(dir).redirectErrorStream(true)
        pb.environment().apply { clear(); putAll(borg.trikeshed.graal.subvm.GuestEnvironment.curated()) }
        val proc = pb.start()
        val outAsync = java.util.concurrent.CompletableFuture.supplyAsync { proc.inputStream.bufferedReader().readText() }
        val finished = proc.waitFor(5, java.util.concurrent.TimeUnit.MINUTES)
        if (!finished) {
            proc.destroyForcibly()
            proc.waitFor()
        }
        val out = runCatching { outAsync.get() }.getOrDefault("")
        return proc.exitValue() to out
    }

    private fun gradle(dir: File, task: String): Pair<Int, String> {
        val gradlew = File(dir, "gradlew")
        val pb = ProcessBuilder(if (gradlew.canExecute()) "./gradlew" else "gradle", task, "--console=plain", "-q")
            .directory(dir).redirectErrorStream(true)
        pb.environment().apply { clear(); putAll(borg.trikeshed.graal.subvm.GuestEnvironment.curated()) }
        val proc = pb.start()
        val outAsync = java.util.concurrent.CompletableFuture.supplyAsync { proc.inputStream.bufferedReader().readText() }
        val finished = proc.waitFor(15, java.util.concurrent.TimeUnit.MINUTES)
        if (!finished) {
            proc.destroyForcibly()
            proc.waitFor()
        }
        val out = runCatching { outAsync.get() }.getOrDefault("")
        return proc.exitValue() to out
    }
}
