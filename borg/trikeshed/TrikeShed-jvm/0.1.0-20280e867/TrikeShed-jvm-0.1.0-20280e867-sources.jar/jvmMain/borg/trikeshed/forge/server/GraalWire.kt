package borg.trikeshed.forge.server

import borg.trikeshed.parse.reify
import borg.trikeshed.parse.jsonOf

import borg.trikeshed.couch.CouchReportEvent
import borg.trikeshed.couch.CouchReportReactorElement
import borg.trikeshed.couch.CouchStore
import borg.trikeshed.couch.Couch
import borg.trikeshed.couch.Document
import borg.trikeshed.cas.LineCas
import borg.trikeshed.graal.subvm.HermesCapsule
import borg.trikeshed.graal.vitals.JvmVitals
import borg.trikeshed.graal.GraalDocumentPolicy
import borg.trikeshed.litebike.JvmKanbanServer
import borg.trikeshed.lib.get
import borg.trikeshed.lib.size
import borg.trikeshed.util.oroboros.CouchAttachmentGateway
import borg.trikeshed.util.oroboros.RepoOccupancy
import borg.trikeshed.util.oroboros.WorktreeCouchGateway
import borg.trikeshed.util.oroboros.element.WorktreeReconcileElement
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

/**
 * GraalWire — the Graal console: a web console with APIs, riding the same listener as everything
 * else ("port" of the PWA in the retained sense — console + APIs + CLI, not a copy of the shell).
 *
 *   GET /graal                    the console page (classpath `web/graal.html`)
 *   GET /graal.webmanifest        install manifest (reuses the forge icons)
 *   GET /futon                     the couch-CRUD companion — Futon lineage, plain document editing
 *   GET /api/graal/vitals         [JvmVitals.snapshot] + pointcut route summary
 *   GET /api/graal/pointcuts      every `pointcut/…` document as a route row
 *   GET /api/graal/map            the whole store as compact `[id, bytes]` rows — the RTS terrain
 *   POST /api/graal/sync          reconcile the worktree and the daemon's boot-absorbed planes,
 *                                 and await their document/index updates
 *   GET /api/graal/doc?id=…       selected document detail sanitized for the Graal inspector
 *   GET /api/graal/content?id=…   selected attachment bytes through the same project-db resolver
 *   GET /api/graal/dag[?id=…]     the DAG arcs the tree cannot show: shared-blob cross-links and
 *                                 pointcut→class edges for one node, or the high-degree hubs
 *   GET /api/graal/impact?node=…&depth=n  dependents of a node over the dag edges, ringed 1..n;
 *                                 `source` rings the Kotlin import/package dependents of a `.kt` node
 *   GET /api/graal/classfile?id=… selected class attachment projection, parsed by JDK 25
 *   GET /api/graal/decompile?source=… source + byte-identical classpath mates, parsed by JDK 25
 *   GET /api/graal/aot             process AOT flags and configured HotSpot cache metadata
 *   GET /api/graal/aot/blob        configured opaque HotSpot AOT archive bytes
 *   POST /api/graal/aot/capture    land that archive in the replicated Couch/CAS attachment plane
 *   GET /api/graal/events         SSE: compile / deopt / gc / cpu flourishes, plus store commits
 *   POST /api/graal/ingest?name=… raw bytes → Tika/OCR when binary → store citizen under dropzone/…
 *                                 → plan-shape gate → board cards when it parses as a plan
 *   POST /api/graal/capsule/spawn {id?}              a hermes sleeve: GraalPy + its own btrfs subvolume
 *   POST /api/graal/capsule/{id}/stdin {text}         one line typed at the captured shell
 *   GET  /api/graal/capsule/{id}/output               the VT scrollback so far (poll, not stream)
 *   POST /api/graal/capsule/{id}/kill                 interrupt + close the guest
 *   GET  /api/graal/occupy                            occupied repos: id, path, live path count
 *   POST /api/graal/occupy {path}                     absorb a git repo's worktree under repos/<id>/
 *                                                      and watch it live — [RepoOccupancy]
 *   POST /api/graal/occupy/{id}/release                stop watching; already-absorbed content stays
 *
 * CLI twin: `borg.trikeshed.graal.vitals.GraalConsoleCli` (vitals | watch) reads the same
 * instrument cluster for a JVM you are inside of.
 */
class GraalWire(
    private val vitals: JvmVitals,
    private val couchStore: CouchStore?,
    private val report: CouchReportReactorElement?,
    private val scope: CoroutineScope,
    private val couch: Couch? = null,
    /** Sub-VM host, when mounted: its Spawned/Evaluated/Revoked/Landed events join the flourish feed. */
    private val vmHost: borg.trikeshed.vm.VmHost? = null,
    /** Needed only to [RepoOccupancy.occupy] a repo on demand; absent means /api/graal/occupy 503s. */
    private val attachmentGateway: CouchAttachmentGateway? = null,
    /** Mounted project dbs: their docs join the terrain as top-level `<name>/…` territories. */
    private val projectDbs: ProjectDbRegistry? = null,
    /**
     * R1: per-ring density shading + the heap/zoom panes. Read live (the index is restored /
     * re-ingested over the daemon's life) by [densityFor] → `/api/graal/density`. Absent (CLI /
     * bare-wire hosts) means the route 503s.
     */
    private val memoryStore: borg.trikeshed.memory.MemoryStore? = null,
    /**
     * Boot-absorbed file planes the panel sync reconciles beside the primary worktree — e.g.
     * the hermes home corpus, whose boot reconcile otherwise never runs again while the daemon
     * lives, so filenodes missing from disk stay in the terrain until a restart. Each lane
     * returns its snapshot and the response sums the counts; a lane that fails fails the sync.
     */
    private val planeSyncs: List<suspend () -> WorktreeCouchGateway.Snapshot> = emptyList(),
    private val pointcuts: borg.trikeshed.pointcut.PointcutBlackboardAdapter? = null,
) {
    private val occupancies = ConcurrentHashMap<String, RepoOccupancy>()
    private val classEvents = MutableSharedFlow<JvmVitals.VitalEvent>(extraBufferCapacity = 256)

    /** File activity is observable before content-addressed ingestion, including identical rebuilds. */
    suspend fun classFileChanged(id: String, phase: String, deleted: Boolean) {
        classEvents.emit(JvmVitals.VitalEvent("class-update", mapOf(
            "id" to id, "phase" to phase, "deleted" to deleted,
        )))
    }
    companion object {
        const val EVENTS_PATH = "/api/graal/events"
        val STREAMING: Set<String> = setOf(EVENTS_PATH)
        private const val REDACTED = "[redacted]"
        private val SENSITIVE_ID = GraalDocumentPolicy.SENSITIVE_ID
        private val SAFE_FIELD_NAMES = GraalDocumentPolicy.SAFE_FIELD_NAMES
        private val SENSITIVE_FIELD_NAMES = GraalDocumentPolicy.SENSITIVE_FIELD_NAMES
        private val SECRET_TEXT_PATTERNS = GraalDocumentPolicy.SECRET_TEXT_PATTERNS
    }

    suspend fun route(method: String, path: String, text: String, respond: (suspend (ByteArray) -> Unit)?): JvmKanbanServer.HttpResponse? {
        val p = path.substringBefore('?')
        return when {
            method == "GET" && (p == "/graal" || p == "/graal/") -> page()
            method == "GET" && (p == "/futon" || p == "/futon/") -> asset("web/futon.html", "text/html; charset=utf-8")
            method == "GET" && p == "/graal.webmanifest" -> JvmKanbanServer.HttpResponse(200, MANIFEST, "application/manifest+json; charset=utf-8")
            method == "GET" && p == "/api/graal/vitals" -> JvmKanbanServer.HttpResponse(200, jsonOf(vitals.snapshot() + ("pointcuts" to pointcutSummary())))
            method == "GET" && p == "/api/graal/heap" -> withContext(Dispatchers.IO) {
                JvmKanbanServer.HttpResponse(200, jsonOf(vitals.heapHistogram()))
            }
            method == "GET" && p == "/api/graal/allocations" -> withContext(Dispatchers.IO) {
                val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
                val allocated = q["class"]?.takeIf { it.isNotBlank() }
                val recent = vitals.allocationSites.snapshot(allocated, System.currentTimeMillis())
                JvmKanbanServer.HttpResponse(200, jsonOf(recent + mapOf(
                    "jfr" to vitals.jfrLive, "jfrError" to vitals.jfrError,
                    "aot" to HotSpotAotBlobAccess.snapshot(),
                )))
            }
            method == "GET" && p == "/api/graal/allocation-frame" -> withContext(Dispatchers.IO) {
                val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
                val frame = vitals.allocationSites.frame(q["site"].orEmpty(), q["frame"]?.toIntOrNull() ?: -1,
                    System.currentTimeMillis())
                    ?: return@withContext JvmKanbanServer.HttpResponse(404, """{"error":"allocation_site_expired_or_missing"}""")
                val result = runCatching { AllocationFrameProjection(couch).project(frame) }
                    .getOrElse { frame.wire() + mapOf("available" to false, "reason" to (it.message ?: "projection_failed")) }
                JvmKanbanServer.HttpResponse(200, jsonOf(result))
            }
            method == "GET" && p == "/api/graal/pointcuts" -> JvmKanbanServer.HttpResponse(200, jsonOf(mapOf("routes" to pointcutRoutes())))
            method == "GET" && p == "/api/graal/map" -> JvmKanbanServer.HttpResponse(200, jsonOf(mapMap()))
            method == "POST" && p == "/api/graal/sync" -> {
                val worktree = scope.coroutineContext[WorktreeReconcileElement]
                    ?: return json(503, mapOf("error" to "worktree_sync_unavailable"))
                try {
                    val snapshot = worktree.sync()
                    val planes = planeSyncs.map { it() }
                    json(200, mapOf(
                        "paths" to snapshot.paths.size + planes.sumOf { it.paths.size },
                        "deleted" to snapshot.deletedPaths.size + planes.sumOf { it.deletedPaths.size },
                        "skippedDirs" to snapshot.skippedDirs + planes.flatMap { it.skippedDirs },
                        "skippedFiles" to snapshot.skippedFiles + planes.flatMap { it.skippedFiles },
                    ))
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    json(500, mapOf("error" to "worktree_sync_failed"))
                }
            }
            method == "GET" && p == "/api/graal/doc" -> withContext(Dispatchers.IO) { docRoute(path) }
            method == "GET" && p == "/api/graal/content" -> withContext(Dispatchers.IO) { contentRoute(path) }
            method == "GET" && p == "/api/graal/zoom" -> zoomRoute(path)
            method == "GET" && p == "/api/graal/strength" -> strengthRoute(path)
            method == "GET" && p == "/api/graal/density" -> densityRoute(path)
            method == "GET" && p == "/api/graal/sheet" -> withContext(Dispatchers.IO) { sheetRoute(path) }
            method == "GET" && p == "/api/graal/dag" -> {
                val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
                JvmKanbanServer.HttpResponse(200, jsonOf(q["id"]?.let { dagFor(it) } ?: dagHubs()))
            }
            method == "GET" && p == "/api/graal/impact" -> withContext(Dispatchers.IO) {
                val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
                val node = q["node"] ?: return@withContext JvmKanbanServer.HttpResponse(400, """{"error":"node_required"}""")
                JvmKanbanServer.HttpResponse(200, jsonOf(impactFor(node, (q["depth"]?.toIntOrNull() ?: 3).coerceIn(1, 16))))
            }
            method == "GET" && p == "/api/graal/classfile" -> withContext(Dispatchers.IO) {
                val id = borg.trikeshed.relaxfactory.CouchHttpSurface
                    .parseQuery(path.substringAfter('?', ""))["id"]
                    ?: return@withContext JvmKanbanServer.HttpResponse(400, """{"error":"class_id_required"}""")
                val projection = classfileProjection(id)
                JvmKanbanServer.HttpResponse(
                    (projection["status"] as? Number)?.toInt() ?: if (projection["error"] == null) 200 else 404,
                    jsonOf(projection),
                )
            }
            method == "GET" && p == "/api/graal/decompile" -> withContext(Dispatchers.IO) {
                val source = borg.trikeshed.relaxfactory.CouchHttpSurface
                    .parseQuery(path.substringAfter('?', ""))["source"]
                    ?: return@withContext JvmKanbanServer.HttpResponse(400, """{"error":"source_required"}""")
                val target = graalDocTarget(source)
                    ?: return@withContext JvmKanbanServer.HttpResponse(503, """{"error":"cas_database_unavailable"}""")
                if (GraalDocumentPolicy.sensitiveDocId(source)) return@withContext JvmKanbanServer.HttpResponse(403, """{"error":"content_preview_blocked"}""")
                val projection = ClasspathSourceProjection(target.db).project(target.docId)
                val resolved = (projection["source"] as? Map<*, *>)?.get("id") as? String
                val sourceDoc = resolved?.let { target.store.get(it) }
                if (resolved?.let { GraalDocumentPolicy.sensitiveDocId(it) } == true || GraalDocumentPolicy.containsSecretText(projection) ||
                    sourceDoc?.let { doc ->
                        val resolvedId = requireNotNull(resolved)
                        GraalDocumentPolicy.sensitiveDocument(resolvedId, target.db.render(doc, target.store.head.getRev(resolvedId)))
                    } == true) return@withContext JvmKanbanServer.HttpResponse(403, """{"error":"content_preview_blocked"}""")
                JvmKanbanServer.HttpResponse(
                    if (projection["error"] == null) 200 else 404,
                    jsonOf(projection),
                )
            }
            method == "GET" && p == "/api/graal/aot" -> withContext(Dispatchers.IO) {
                JvmKanbanServer.HttpResponse(200, jsonOf(HotSpotAotBlobAccess.snapshot()))
            }
            method == "GET" && p == "/api/graal/aot/blob" -> withContext(Dispatchers.IO) {
                val blob = HotSpotAotBlobAccess.blob()
                    ?: return@withContext JvmKanbanServer.HttpResponse(404, """{"error":"aot_blob_unavailable"}""")
                JvmKanbanServer.HttpResponse(200, "", "application/x-java-aot-cache", blob.second)
            }
            method == "POST" && p == "/api/graal/aot/capture" -> withContext(Dispatchers.IO) {
                val db = couch
                    ?: return@withContext JvmKanbanServer.HttpResponse(503, """{"error":"cas_database_unavailable"}""")
                val captured = HotSpotAotBlobAccess.capture(db)
                JvmKanbanServer.HttpResponse(
                    if (captured["ok"] == true) 201 else 409,
                    jsonOf(captured),
                )
            }
            method == "GET" && p == EVENTS_PATH && respond != null -> { stream(respond); JvmKanbanServer.HttpResponse(200, "") }
            else -> null
        }
    }

    private fun page(): JvmKanbanServer.HttpResponse = asset("web/graal.html", "text/html; charset=utf-8")

    private fun asset(resource: String, contentType: String): JvmKanbanServer.HttpResponse {
        val bytes = GraalWire::class.java.classLoader.getResourceAsStream(resource)?.use { it.readBytes() }
            ?: return JvmKanbanServer.HttpResponse(404, """{"error":"asset_missing","resource":"$resource"}""")
        return JvmKanbanServer.HttpResponse(200, "", contentType, bytes)
    }

    private data class GraalDocTarget(
        val displayId: String,
        val dbName: String,
        val docId: String,
        val db: Couch,
        val store: CouchStore,
    )

    private fun graalDocTarget(id: String): GraalDocTarget? {
        if (id.isBlank()) return null
        val slash = id.indexOf('/')
        if (slash > 0) {
            val dbName = id.substring(0, slash)
            val rest = id.substring(slash + 1)
            val pdb = projectDbs?.get(dbName)
            if (pdb != null) return GraalDocTarget(id, pdb.name, rest, pdb.db, pdb.store)
        }
        val db = couch ?: return null
        return GraalDocTarget(id, db.name, id, db, couchStore ?: db.store)
    }

    private fun docRoute(path: String): JvmKanbanServer.HttpResponse {
        val id = borg.trikeshed.relaxfactory.CouchHttpSurface
            .parseQuery(path.substringAfter('?', ""))["id"]
            ?: return json(400, mapOf("error" to "id_required"))
        livePointcut(id)?.let { return json(200, sanitizeGraalDocument(id, it)) }
        val target = graalDocTarget(id)
            ?: return json(503, mapOf("error" to "cas_database_unavailable", "id" to id))
        val doc = target.store.get(target.docId)
            ?: return json(404, mapOf("error" to "document_missing", "id" to id))
        if (isGraalDeleted(doc)) return json(410, mapOf("error" to "document_deleted", "id" to id))
        val rendered = target.db.render(doc, target.store.head.getRev(target.docId))
        return json(200, sanitizeGraalDocument(target.displayId, rendered))
    }

    private fun contentRoute(path: String): JvmKanbanServer.HttpResponse {
        val id = borg.trikeshed.relaxfactory.CouchHttpSurface
            .parseQuery(path.substringAfter('?', ""))["id"]
            ?: return json(400, mapOf("error" to "id_required"))
        val target = graalDocTarget(id)
            ?: return json(503, mapOf("error" to "cas_database_unavailable", "id" to id))
        val doc = target.store.get(target.docId)
            ?: return json(404, mapOf("error" to "document_missing", "id" to id))
        if (isGraalDeleted(doc)) return json(410, mapOf("error" to "document_deleted", "id" to id))
        val rendered = target.db.render(doc, target.store.head.getRev(target.docId))
        val safeDocument = sanitizeGraalDocument(target.displayId, rendered)
        if ((safeDocument["_graal"] as? Map<*, *>)?.get("previewBlocked") == true) {
            return json(403, mapOf("error" to "content_preview_blocked", "id" to id))
        }
        val (contentType, bytes) = target.db.attachment(target.docId)
            ?: return json(404, mapOf("error" to "content_missing", "id" to id))
        if (containsSecretText(bytes.decodeToString())) {
            return json(403, mapOf("error" to "content_preview_blocked"))
        }
        return JvmKanbanServer.HttpResponse(200, "", contentType, bytes)
    }

    private fun classfileProjection(id: String): Map<String, Any?> {
        if (sensitiveDocId(id)) return mapOf("error" to "content_preview_blocked", "status" to 403)
        val target = graalDocTarget(id)
            ?: return linkedMapOf("error" to "cas_database_unavailable", "status" to 503, "id" to id)
        val doc = target.store.get(target.docId)
        if (doc != null) {
            if (isGraalDeleted(doc)) return linkedMapOf("error" to "class_blob_deleted", "status" to 410, "id" to id)
            val safe = sanitizeGraalDocument(id, target.db.render(doc, target.store.head.getRev(target.docId)))
            if ((safe["_graal"] as? Map<*, *>)?.get("previewBlocked") == true)
                return mapOf("error" to "content_preview_blocked", "status" to 403)
        }
        val projection = ClassfileBlobProjection(target.db, vitals).project(target.docId).withGraalId(id, target)
        return if (containsSecretText(projection)) mapOf("error" to "content_preview_blocked", "status" to 403) else projection
    }

    private fun Map<String, Any?>.withGraalId(id: String, target: GraalDocTarget): Map<String, Any?> {
        if (target.docId == id) return this
        val out = LinkedHashMap<String, Any?>()
        out.putAll(this)
        out["id"] = id
        out["docId"] = target.docId
        out["database"] = target.dbName
        return out
    }

    private fun isGraalDeleted(doc: Document): Boolean = doc.fields.any { field ->
        when (field.name) {
            "_deleted" -> field.value == true
            "deleted" -> field.value == true || field.value?.toString()?.equals("true", ignoreCase = true) == true
            else -> false
        }
    }

    private data class Sanitized(val value: Any?, val redacted: Boolean)

    private fun sanitizeGraalDocument(id: String, raw: Map<String, Any?>): Map<String, Any?> {
        val sensitive = sensitiveDocId(id) ||
            raw.keys.any { sensitiveFieldName(it, true) } ||
            raw.values.any { containsSecretText(it) }
        var redacted = false
        val out = LinkedHashMap<String, Any?>()
        for ((key, value) in raw) {
            when {
                key == "_rev" && sensitive -> {
                    out[key] = REDACTED
                    redacted = true
                }
                key == "contentId" && sensitive -> {
                    out[key] = REDACTED
                    redacted = true
                }
                key == "_attachments" && sensitive -> {
                    out[key] = blockedAttachmentStub(value)
                    redacted = true
                }
                else -> {
                    val payload = sensitive && (value is Map<*, *> || value is List<*> ||
                        key.filter { it.isLetterOrDigit() }.lowercase() !in SAFE_FIELD_NAMES)
                    val item = sanitizeGraalValue(key, value, payload || sensitiveFieldName(key, sensitive), sensitive)
                    out[key] = item.value
                    redacted = redacted || item.redacted
                }
            }
        }
        out["_graal"] = mapOf(
            "redacted" to redacted,
            "previewBlocked" to sensitive,
            "documentId" to id,
        )
        return out
    }

    private fun sanitizeGraalValue(key: String, value: Any?, keySensitive: Boolean, documentSensitive: Boolean): Sanitized =
        when (value) {
            is Map<*, *> -> {
                var redacted = false
                val out = LinkedHashMap<String, Any?>()
                for ((rawKey, rawValue) in value) {
                    val childKey = rawKey?.toString().orEmpty()
                    val item = sanitizeGraalValue(childKey, rawValue, keySensitive || sensitiveFieldName(childKey, documentSensitive), documentSensitive)
                    out[childKey] = item.value
                    redacted = redacted || item.redacted
                }
                Sanitized(out, redacted)
            }
            is List<*> -> {
                var redacted = false
                val out = value.map { item ->
                    val sanitized = sanitizeGraalValue(key, item, keySensitive, documentSensitive)
                    redacted = redacted || sanitized.redacted
                    sanitized.value
                }
                Sanitized(out, redacted)
            }
            is String -> if (keySensitive || looksSecretText(value)) Sanitized(REDACTED, true) else Sanitized(value, false)
            null -> Sanitized(null, false)
            else -> if (keySensitive) Sanitized(REDACTED, true) else Sanitized(value, false)
        }

    private fun containsSecretText(value: Any?): Boolean = GraalDocumentPolicy.containsSecretText(value)

    private fun blockedAttachmentStub(value: Any?): Map<String, Any?> {
        val content = ((value as? Map<*, *>)?.get("content") as? Map<*, *>).orEmpty()
        val stub = LinkedHashMap<String, Any?>()
        stub["stub"] = true
        stub["previewBlocked"] = true
        content["content_type"]?.let { stub["content_type"] = it }
        content["length"]?.let { stub["length"] = it }
        return mapOf("content" to stub)
    }

    private fun sensitiveDocId(id: String): Boolean = GraalDocumentPolicy.sensitiveDocId(id)

    private fun sensitiveFieldName(name: String, documentSensitive: Boolean): Boolean =
        GraalDocumentPolicy.sensitiveFieldName(name, documentSensitive)

    private fun looksSecretText(value: String): Boolean = GraalDocumentPolicy.looksSecretText(value)

    /**
     * The 30k-foot terrain: every live document as `[id, bytes]`. The console builds the
     * prefix-tree territories client-side and lays them out as a zoomable treemap; bytes come
     * from the attachment `length` field where present, else the field count as a stand-in mass.
     */
    private fun mapMap(): Map<String, Any?> {
        val store = couchStore
        // last commit sequence per doc: the store's own causal order
        val lastSeq = HashMap<String, Long>()
        if (store != null) {
            val frames = store.changes.series()
            for (i in 0 until frames.size) {
                val f = frames[i]
                lastSeq[f.docId] = f.sequence + 1
            }
        }
        // 5th row element: the doc code — taxonomy signature of the id path (ids ARE paths)
        // plus the stored code field when one was minted at ingest (dropzone/attachments).
        fun codeOf(id: String, stored: Int?): Int {
            val s = stored ?: return borg.trikeshed.narsese.AngularCodec.fragmentCode(
                borg.trikeshed.narsese.AngularCodec.taxonomySigOfKey(id).toString() + "/" + id.substringAfterLast('/'),
            )
            return s
        }
        val rows = store?.all().orEmpty()
            .filter { d -> !isGraalDeleted(d) }
            .map { d ->
                val len = (d.fields.firstOrNull { it.name == "length" }?.value as? String)?.toLongOrNull()
                val gen = store?.head?.getRev(d.id)?.substringBefore('-')?.toIntOrNull() ?: 1
                val stored = (d.fields.firstOrNull { it.name == "code" }?.value as? String)?.toIntOrNull()
                listOf(d.id, len ?: (d.fields.size.toLong() * 64), lastSeq[d.id] ?: 0L, gen, codeOf(d.id, stored))
            }
        // Project dbs join the terrain as top-level territories named after the db;
        // the client resolves `<db>/<docid>` rows back to `/<db>/<docid>` fetches.
        val projectRows = projectDbs?.all().orEmpty().flatMap { pdb ->
            pdb.store.all()
                .filter { d -> !isGraalDeleted(d) }
                .map { d ->
                    val len = (d.fields.firstOrNull { it.name == "length" }?.value as? String)?.toLongOrNull()
                    val gen = pdb.store.head.getRev(d.id)?.substringBefore('-')?.toIntOrNull() ?: 1
                    val stored = (d.fields.firstOrNull { it.name == "code" }?.value as? String)?.toIntOrNull()
                    val id = "${pdb.name}/${d.id}"
                    listOf(id, len ?: (d.fields.size.toLong() * 64), 0L, gen, codeOf(id, stored))
                }
        }
        return mapOf(
            "rows" to rows + projectRows,
            "dbs" to projectDbs?.all().orEmpty().map { it.name },
            "at" to System.currentTimeMillis(),
        )
    }

    /**
     * `/api/graal/sheet?id=<docId>` — the live wiring [borg.trikeshed.forge.sheet.CursorSheet]
     * never had. `id=vms` returns the sub-VM sheet (already served flat at `/api/vm`, offered
     * here too so one client can navigate both families the same way); any other id is treated
     * as a couch document, parsed as Confix, and returned as its FULL nested sheet family — every
     * object/array field is a [borg.trikeshed.forge.sheet.SheetRef] cell the client can drill
     * into, grid-in-cell, to whatever depth the document actually nests. This is the concentric
     * treesheet PRELOAD/CursorSheet already specify; nothing before this route ever served it.
     */
    private fun sheetRoute(path: String): JvmKanbanServer.HttpResponse {
        val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
        val id = q["id"] ?: return JvmKanbanServer.HttpResponse(400, """{"error":"id required"}""")
        livePointcut(id)?.let {
            val safe = sanitizeGraalDocument(id, it)
            return json(200, projectionSheets(id, safe).map { sheet -> sheet.toMap() })
        }

        if (id == "vms") {
            val host = vmHost ?: return JvmKanbanServer.HttpResponse(503, """{"error":"no sub-VM host mounted"}""")
            val columns = borg.trikeshed.vm.VM_COLUMNS.map { borg.trikeshed.forge.sheet.SheetColumn(it.first, it.second.name) }
            val sheet = borg.trikeshed.forge.sheet.sheetSeed("vms", "Sub-VMs", host.rows(), columns = columns)
            return JvmKanbanServer.HttpResponse(200, jsonOf(listOf(sheet.toMap())))
        }

        val target = graalDocTarget(id) ?: return JvmKanbanServer.HttpResponse(503, """{"error":"store not wired"}""")
        val doc = target.store.get(target.docId) ?: return JvmKanbanServer.HttpResponse(404, """{"error":"no such document","id":"$id"}""")
        if (isGraalDeleted(doc)) return JvmKanbanServer.HttpResponse(410, """{"error":"document_deleted","id":"$id"}""")
        val rendered = target.db.render(doc, target.store.head.getRev(target.docId))
        val safeDocument = sanitizeGraalDocument(id, rendered)
        if ((safeDocument["_graal"] as? Map<*, *>)?.get("previewBlocked") == true) {
            val projection = safeDocument.filterKeys { !it.startsWith("_") || it == "_graal" }
            return JvmKanbanServer.HttpResponse(
                200,
                jsonOf(projectionSheets(id, projection).map { it.toMap() }),
            )
        }
        val fields = linkedMapOf<String, Any?>()
        for (f in doc.fields) if (!f.name.startsWith("_")) fields[f.name] = f.value
        val projection = when {
            id.endsWith(".class") -> classfileProjection(id).let { structure ->
                if (structure["error"] != null) structure else linkedMapOf<String, Any?>().apply {
                    // Keep small facets ahead of instruction/pointcut collections in the shared sheet budget.
                    for (key in listOf("id", "className", "superClass", "interfaces", "sourceFile", "classFile",
                        "classfileApi", "blobCid", "runtimeCid", "exactRuntimeBlob", "onClasspath",
                        "fields", "methods", "runtimeObservation", "pointcuts")) {
                        if (structure.containsKey(key)) put(key, structure[key])
                    }
                }
            }
            id.endsWith(".kt") || id.endsWith(".java") -> {
                ClasspathSourceProjection(target.db).project(target.docId)
            }
            else -> fields
        }
        if (containsSecretText(projection)) return json(403, mapOf("error" to "content_preview_blocked"))
        if (projection !== fields && projection["error"] != null) return JvmKanbanServer.HttpResponse(
            (projection["status"] as? Number)?.toInt() ?: 404, jsonOf(projection),
        )
        if (projection !== fields) return JvmKanbanServer.HttpResponse(
            200, jsonOf(projectionSheets(id, projection).map { it.toMap() }),
        )
        val confix = runCatching {
            borg.trikeshed.parse.confix.confixDoc(jsonOf(projection))
        }.getOrElse {
            return JvmKanbanServer.HttpResponse(502, """{"error":"document did not parse as confix","detail":"${it.message}"}""")
        }
        val family = borg.trikeshed.forge.sheet.confixSheets(id, id, confix)
        return JvmKanbanServer.HttpResponse(200, jsonOf(family.map { it.toMap() }))
    }

    /**
     * The ingest lane — the product loop, not a graphics demo. Every drop becomes a store citizen:
     * raw bytes as a CAS blob + attachment doc under `dropzone/<name>`; binary goes through
     * Tika/Tesseract to markdown; the extraction lands beside it as `dropzone/<name>.extract.md`;
     * and if the text passes [ForgeKanbanIngest.isPlan]'s shape grammar it is persisted into the
     * board — the terrain, the shape strip and the kanban all grow from one drop.
     * RawRoute (binary-safe): register beside CouchWire in `rawRoutes`.
     */
    suspend fun ingestRoute(method: String, path: String, payload: ByteArray, respond: (suspend (ByteArray) -> Unit)?): JvmKanbanServer.HttpResponse? {
        val p = path.substringBefore('?')
        if (p == "/api/graal/capsule/list" || p == "/api/graal/capsule/spawn" || p.startsWith("/api/graal/capsule/")) return capsuleRoute(method, p, payload)
        if (p == "/api/graal/occupy" || p.startsWith("/api/graal/occupy/")) return occupyRoute(method, p, payload)
        if (p != "/api/graal/ingest") return null
        if (method != "POST") return JvmKanbanServer.HttpResponse(405, """{"error":"method_not_allowed"}""")
        val database = couch ?: return JvmKanbanServer.HttpResponse(501, """{"error":"no store mounted"}""")
        val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
        val rawName = (q["name"] ?: "drop-${System.currentTimeMillis()}").substringAfterLast('/').substringAfterLast('\\')
        val name = rawName.replace(Regex("[^\\w .()-]+"), "_").ifBlank { "drop" }
        val bytes = CouchWire.bodyOf(payload)
        if (bytes.isEmpty()) return JvmKanbanServer.HttpResponse(400, """{"error":"empty body"}""")
        return try {
            val texty = name.lowercase().let { n -> listOf(".md", ".txt", ".markdown", ".json", ".yaml", ".yml", ".csv").any { n.endsWith(it) } }
            // 1) the original bytes become a store citizen
            val cid = database.blockPut(bytes)
            val docId = "dropzone/$name"
            // the locality-preserving coordinate: doc id path + text surface (or RLE shape for binary)
            val docCode = borg.trikeshed.narsese.AngularCodec.fragmentCode(
                borg.trikeshed.narsese.AngularCodec.taxonomySigOfKey(docId).toString() + "/" + name,
            )
            putAttachmentDoc(database, docId, borg.trikeshed.util.io.ContentTypes.forPath(name), cid, bytes.size.toLong(), docCode)
            // 2) binary → markdown: in-tree COS disassembler first (its output flows through the
            //    same text lanes as any drop), Tika/Tesseract as the fallback; text is its own markdown
            val pdfText: String? = if (!texty && name.lowercase().endsWith(".pdf")) runCatching {
                val doc = borg.trikeshed.pdf.JvmPdfDisassembler.parse(bytes)
                borg.trikeshed.pdf.PdfText.extract(doc).text.takeIf { it.isNotBlank() }
            }.getOrNull() else null
            val markdown = when {
                texty -> bytes.decodeToString()
                pdfText != null -> pdfText
                else -> {
                    val tmp = java.nio.file.Files.createTempFile("graal-ingest-", "-$name")
                    try {
                        java.nio.file.Files.write(tmp, bytes)
                        borg.trikeshed.kanban.JvmTikaIngestAdapter.extractToMarkdown(tmp)
                    } finally { runCatching { java.nio.file.Files.deleteIfExists(tmp) } }
                }
            }
            var extractId: String? = null
            if (!texty && markdown.isNotBlank()) {
                val mdBytes = markdown.encodeToByteArray()
                val mdCid = database.blockPut(mdBytes)
                extractId = "$docId.extract.md"
                putAttachmentDoc(database, extractId, "text/markdown", mdCid, mdBytes.size.toLong(),
                    borg.trikeshed.narsese.AngularCodec.fragmentCode(markdown.take(4096)))
            }
            // 3) the plan gate: shape grammar decides whether this drop is board material
            val plan = runCatching { borg.trikeshed.kanban.ForgeKanbanIngest.isPlan(markdown) }.getOrDefault(false)
            var persisted = false
            if (plan && q["persist"] != null) {
                val tmpMd = java.nio.file.Files.createTempFile("graal-plan-", ".md")
                try {
                    java.nio.file.Files.write(tmpMd, markdown.encodeToByteArray())
                    borg.trikeshed.kanban.ForgeKanbanIngest.persistMarkdown(q["persist"]!!, tmpMd.toString())
                    persisted = true
                } finally { runCatching { java.nio.file.Files.deleteIfExists(tmpMd) } }
            }
            val shapeKey = runCatching { borg.trikeshed.kanban.ForgeKanbanIngest.planShape(markdown) }.getOrDefault("")
            val byteSurface: borg.trikeshed.cas.ByteEpistemicSurface? = null
            JvmKanbanServer.HttpResponse(200, jsonOf(mapOf(
                "ok" to true, "id" to docId, "cid" to cid.value, "bytes" to bytes.size,
                "extracted" to extractId, "chars" to markdown.length, "markdown" to markdown, "shape" to shapeKey.take(80),
                "plan" to plan, "persisted" to persisted,
                "code" to docCode, "codeRing8" to ((docCode ushr 8) and 0xFF),
                // byte schema: organic comprehension without parser
                "byteSchema" to byteSurface?.documentSchema?.structuralKey?.take(120),
                "byteChunks" to byteSurface?.chunks?.size,
                "byteLzPhrases" to byteSurface?.documentSchema?.lzPhraseCount,
                "byteComplexity" to byteSurface?.documentSchema?.let {
                    String.format("%.4f", it.normalizedComplexity)
                },
                "byteLinks" to byteSurface?.links?.size,
                "pdfLane" to (pdfText != null),
            )))
        } catch (t: Throwable) {
            JvmKanbanServer.HttpResponse(500, jsonOf(mapOf("error" to (t.message ?: t.toString()))))
        }
    }

    // ── capsule: the hermes sleeve's captured VT shell ────────────

    private fun json(status: Int, v: Any?) = JvmKanbanServer.HttpResponse(status, jsonOf(v))


    private fun capsuleRoute(method: String, p: String, payload: ByteArray): JvmKanbanServer.HttpResponse {
        val tail = p.removePrefix("/api/graal/capsule/")
        if (tail == "list") {
            return json(200, mapOf("capsules" to HermesCapsule.registry.map { (id, c) -> mapOf("id" to id, "alive" to c.alive) }))
        }
        if (tail == "spawn") {
            if (method != "POST") return json(405, mapOf("error" to "method_not_allowed"))
            @Suppress("UNCHECKED_CAST")
            val body = runCatching { reify(CouchWire.bodyOf(payload).decodeToString()) as? Map<String, Any?> }.getOrNull().orEmpty()
            val id = (body["id"] as? String)?.takeIf { it.isNotBlank() } ?: "hermes-${System.currentTimeMillis() % 100000}"
            if (!id.matches(Regex("[A-Za-z0-9._:-]{1,128}"))) return json(400, mapOf("error" to "invalid capsule id"))
            if (HermesCapsule.registry[id]?.alive == true) return json(409, mapOf("error" to "already running", "id" to id))
            val terminal = (vmHost as? borg.trikeshed.vm.HypervisorVmHost)?.terminals?.open(
                id,
                borg.trikeshed.pointcut.VmFacet.GRAAL_PYTHON,
                "capsule",
            )
            val capsule = HermesCapsule(id, terminal)
            HermesCapsule.registry[id] = capsule
            capsule.start(scope)
            return json(202, mapOf("ok" to true, "id" to id, "terminal" to "/vm-terminal?id=$id"))
        }
        val parts = tail.split('/')
        val id = parts.getOrNull(0) ?: return json(404, mapOf("error" to "missing capsule id"))
        val capsule = HermesCapsule.registry[id] ?: return json(404, mapOf("error" to "no such capsule", "id" to id))
        return when (parts.getOrNull(1)) {
            "stdin" -> {
                if (method != "POST") return json(405, mapOf("error" to "method_not_allowed"))
                @Suppress("UNCHECKED_CAST")
                val body = runCatching { reify(CouchWire.bodyOf(payload).decodeToString()) as? Map<String, Any?> }.getOrNull().orEmpty()
                capsule.type((body["text"] as? String).orEmpty())
                json(200, mapOf("ok" to true))
            }
            "output" -> json(200, mapOf("id" to id, "alive" to capsule.alive, "text" to capsule.output()))
            "kill" -> { capsule.kill(); json(200, mapOf("ok" to true)) }
            else -> json(404, mapOf("error" to "unknown capsule route"))
        }
    }

    // ── occupy: absorb + live-watch an arbitrary git repo, on demand ──

    private suspend fun occupyRoute(method: String, p: String, payload: ByteArray): JvmKanbanServer.HttpResponse {
        if (p == "/api/graal/occupy") {
            if (method == "GET") {
                return json(200, mapOf("repos" to occupancies.values.map { it.toMap() }))
            }
            if (method != "POST") return json(405, mapOf("error" to "method_not_allowed"))
            val gateway = attachmentGateway ?: return json(503, mapOf("error" to "cas_database_unavailable"))
            @Suppress("UNCHECKED_CAST")
            val body = runCatching { reify(CouchWire.bodyOf(payload).decodeToString()) as? Map<String, Any?> }.getOrNull().orEmpty()
            val pathStr = (body["path"] as? String)?.takeIf { it.isNotBlank() }
                ?: return json(400, mapOf("error" to "path required"))
            val dir = java.io.File(pathStr)
            if (!RepoOccupancy.looksLikeGitRepo(dir)) return json(400, mapOf("error" to "not a git repo (no .git)", "path" to dir.absolutePath))
            occupancies.values.firstOrNull { it.repoPath == dir.absolutePath }?.let {
                return json(409, mapOf("error" to "already occupied", "id" to it.id))
            }
            val id = RepoOccupancy.idFor(dir, occupancies.keys)
            return try {
                val occ = RepoOccupancy.occupy(dir, id, gateway, scope.coroutineContext[Job])
                occupancies[id] = occ
                json(202, mapOf("ok" to true, "id" to id, "prefix" to occ.prefix))
            } catch (t: Throwable) {
                json(500, mapOf("error" to (t.message ?: t.toString())))
            }
        }
        val tail = p.removePrefix("/api/graal/occupy/")
        val parts = tail.split('/')
        val id = parts.getOrNull(0) ?: return json(404, mapOf("error" to "missing id"))
        val occ = occupancies[id] ?: return json(404, mapOf("error" to "no such occupancy", "id" to id))
        return when (parts.getOrNull(1)) {
            "release" -> {
                if (method != "POST") return json(405, mapOf("error" to "method_not_allowed"))
                occ.stop()
                occupancies.remove(id)
                json(200, mapOf("ok" to true))
            }
            else -> json(404, mapOf("error" to "unknown occupy route"))
        }
    }

    private fun putAttachmentDoc(
        database: borg.trikeshed.couch.Couch,
        id: String,
        contentType: String,
        cid: borg.trikeshed.job.ContentId,
        length: Long,
        code: Int? = null,
    ) {
        // The derived-code-as-metadata precedent (MemoryStore.spineCid): the locality-preserving
        // coordinate rides the doc so similarity grouping never needs the bytes.
        val fields = mutableListOf(
            borg.trikeshed.couch.Field("contentType", contentType),
            borg.trikeshed.couch.Field("length", length.toString()),
            borg.trikeshed.couch.Field("contentId", cid.value),
            borg.trikeshed.couch.Field("agentId", "dropzone"),
            borg.trikeshed.couch.Field("revision", "drop"),
            borg.trikeshed.couch.Field("sequence", System.currentTimeMillis().toString()),
        )
        if (code != null) {
            fields += borg.trikeshed.couch.Field("code", code.toString())
            // ring8 = the HIGH byte (bits 15..8) — the coarse ring, matching LineNode.codeRing8,
            // ByteChunk.codeRing8, and the client's similarity split. Low byte is the fine ring.
            fields += borg.trikeshed.couch.Field("codeRing8", ((code ushr 8) and 0xFF).toString())
        }
        database.store.put(borg.trikeshed.couch.Document(id, fields), database.store.head.getRev(id))
    }

    // ── DAG arcs: what the prefix tree cannot show ───────────────
    // The terrain is a tree of ids, but the blackboard is a DAG: many documents name the same CAS
    // blob (dedup), and pointcut routes point INTO class attachments. These are the cross-links.

    /**
     * `/api/graal/zoom?code=<ring8 in hex or dec>` — the mid-zoom ring for Step E: representative
     * fragments per group. Served as cids (Claim Check — never inlined): the client fetches real
     * bytes via `_cas` when it wants the content side by side.
     */
    private fun zoomRoute(path: String): JvmKanbanServer.HttpResponse {
        val db = couch ?: return JvmKanbanServer.HttpResponse(503, """{"error":"no store mounted"}""")
        val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
        val raw = q["code"] ?: return JvmKanbanServer.HttpResponse(400, """{"error":"code required"}""")
        val ring8 = (raw.toIntOrNull(16) ?: raw.toIntOrNull())?.and(0xFF)
            ?: return JvmKanbanServer.HttpResponse(400, """{"error":"code must be a byte (hex or dec)"}""")
        val chunkDocs = db.store.all().filter { d ->
            d.fields.any { it.name == "kind" && it.value == "byte-chunk" } &&
                d.fields.any { it.name == "codeRing8" && (it.value as? String)?.toIntOrNull() == ring8 }
        }
        val reps = chunkDocs.take(64).map { d ->
            mapOf(
                "id" to d.id,
                "chunkCid" to cidOf(d),
                "code" to (d.fields.firstOrNull { it.name == "code" }?.value as? String)?.toIntOrNull(),
                "structuralKey" to (d.fields.firstOrNull { it.name == "structuralKey" }?.value as? String)?.take(96),
                "cas" to "/api/graal/cas/${cidOf(d)}",
            )
        }
        return JvmKanbanServer.HttpResponse(200, jsonOf(mapOf(
            "ring8" to ring8, "docs" to chunkDocs.size, "representatives" to reps,
        )))
    }

    /**
     * `/api/graal/strength?a=<cid>&b=<cid>` — the CAS-granting-strength proof by bytes (Step E).
     * Both fragments are re-ingested through [LineCas] and graded with [MatchGrade] /
     * [LinkConfidence] / rampScore; the answer carries both cids so the client can lay the
     * actual stored bytes side by side — the bytes prove the grouping, not the chrome.
     */
    private fun strengthRoute(path: String): JvmKanbanServer.HttpResponse {
        val db = couch ?: return JvmKanbanServer.HttpResponse(503, """{"error":"no store mounted"}""")
        val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
        val a = q["a"] ?: return JvmKanbanServer.HttpResponse(400, """{"error":"a cid required"}""")
        val b = q["b"] ?: return JvmKanbanServer.HttpResponse(400, """{"error":"b cid required"}""")
        val bytesA = db.blockGet(a) ?: return JvmKanbanServer.HttpResponse(404, """{"error":"a not in cas"}""")
        val bytesB = db.blockGet(b) ?: return JvmKanbanServer.HttpResponse(404, """{"error":"b not in cas"}""")
        val spineA = LineCas.spineInto(db.cas, bytesA.decodeToString())
        val spineB = LineCas.spineInto(db.cas, bytesB.decodeToString())
        val overlap = LineCas.overlapCounts(spineA, spineB)
        val proximity = LineCas.proximity(spineA, spineB)
        val grades = overlap.linked to (overlap.partial)
        val confidence = when {
            overlap.linked > 0 -> "CONFIRMED"
            overlap.partial > 0 -> "PROVISIONAL"
            overlap.contentOnly > 0 -> "CANDIDATE"
            else -> "NONE"
        }
        return JvmKanbanServer.HttpResponse(200, jsonOf(mapOf(
            "a" to a, "b" to b,
            "linked" to grades.first, "partial" to grades.second, "contentOnly" to overlap.contentOnly,
            "proximity" to String.format("%.4f", proximity),
            "confidence" to confidence,
            "ramp" to when (confidence) {
                "CONFIRMED" -> 1.0; "PROVISIONAL" -> 0.45; "CANDIDATE" -> 0.12; else -> 0.0
            },
            "aBytes" to bytesA.size, "bBytes" to bytesB.size,
        )))
    }

    private fun cidOf(d: borg.trikeshed.couch.Document): String? =
        d.fields.firstOrNull { it.name == "contentId" }?.value as? String

    /**
     * `/api/graal/density?path=<doc>&aperture=L0..L3` — per-region residual density at a zoom
     * band (Step C's `residualDensity(probe, aperture)` behind a route). Resolves the path to
     * its [borg.trikeshed.cas.LineSpine] through [memoryStore].spineOf (reads the live index,
     * restored at boot and re-ingested over the daemon's life) and serializes the regional
     * top-k with [densityMap].
     */
    private suspend fun densityRoute(path: String): JvmKanbanServer.HttpResponse {
        val store = memoryStore
            ?: return JvmKanbanServer.HttpResponse(503, """{"error":"memory store not mounted"}""")
        val q = borg.trikeshed.relaxfactory.CouchHttpSurface.parseQuery(path.substringAfter('?', ""))
        val id = q["path"] ?: q["id"] ?: return JvmKanbanServer.HttpResponse(400, """{"error":"path or id required"}""")
        val aperture = borg.trikeshed.collections.LineAperture.entries.firstOrNull { it.name == (q["aperture"] ?: "L2") }
            ?: return JvmKanbanServer.HttpResponse(400, """{"error":"aperture must be L0|L1|L2|L3"}""")
        val spine = withContext(Dispatchers.IO) { store.spineOf(id) }
            ?: return JvmKanbanServer.HttpResponse(404, """{"error":"no spine for $id"}""")
        val result = withContext(Dispatchers.IO) { store.lineIndex.residualDensity(spine, aperture) }
        return JvmKanbanServer.HttpResponse(
            200,
            jsonOf(densityMap(result) + ("path" to id) + ("aperture" to aperture.name)),
        )
    }

    /**
     * Serialize [borg.trikeshed.cas.LineCasIndex.residualDensity]'s
     * `Series<Join<Int, Series<Join<ContentId, OverlapCounts>>>>` to plain JSON:
     * `regions[i]` carries the top-k overlap rows plus region-level sums.
     */
    internal fun densityMap(
        result: Any?,
    ): Map<String, Any?> {
        val size = (result as? borg.trikeshed.lib.Series<*>)?.a ?: 0
        val regions = ArrayList<Map<String, Any?>>(size)
        var linkedTotal = 0
        var partialTotal = 0
        var contentTotal = 0
        for (i in 0 until size) {
            @Suppress("UNCHECKED_CAST")
            val row = (result as borg.trikeshed.lib.Series<Any?>)[i] as? borg.trikeshed.lib.Join<Int, *>
                ?: continue
            val inner = row.b as? borg.trikeshed.lib.Series<*>
                ?: continue
            val n = inner.size
            val rows = ArrayList<Map<String, Any?>>(n)
            for (j in 0 until n) {
                val pair = inner[j] as? borg.trikeshed.lib.Join<borg.trikeshed.job.ContentId, borg.trikeshed.cas.OverlapCounts>
                    ?: continue
                val c = pair.b
                rows += mapOf("cid" to pair.a.hex, "linked" to c.linked, "partial" to c.partial, "contentOnly" to c.contentOnly)
                linkedTotal += c.linked
                partialTotal += c.partial
                contentTotal += c.contentOnly
            }
            regions += mapOf(
                "region" to row.a,
                "rows" to rows,
                "linked" to rows.sumOf { (it["linked"] as? Int) ?: 0 },
                "partial" to rows.sumOf { (it["partial"] as? Int) ?: 0 },
                "contentOnly" to rows.sumOf { (it["contentOnly"] as? Int) ?: 0 },
            )
        }
        return mapOf(
            "regions" to regions,
            "totals" to mapOf("linked" to linkedTotal, "partial" to partialTotal, "contentOnly" to contentTotal),
        )
    }

    /** Edges for one node: every other doc sharing its blob, plus pointcut→class targets. */
    private fun dagFor(id: String): Map<String, Any?> {
        val all = couchStore?.all().orEmpty()
        val me = all.firstOrNull { it.id == id } ?: return mapOf("node" to id, "edges" to emptyList<Any?>())
        val edges = mutableListOf<Map<String, Any?>>()
        val cid = cidOf(me)
        if (cid != null) for (d in all) {
            if (d.id != id && cidOf(d) == cid) edges += mapOf("to" to d.id, "kind" to "shared-blob", "cid" to cid)
        }
        if (id.startsWith("pointcut/")) {
            @Suppress("UNCHECKED_CAST")
            val cls = (me.fields.firstOrNull { it.name == "coordinate" }?.value as? Map<String, Any?>)?.get("className")?.toString()
            if (cls != null) {
                val rel = cls.replace('.', '/') + ".class"
                for (d in all) if (d.id.endsWith(rel)) edges += mapOf("to" to d.id, "kind" to "pointcut-target")
            }
        } else {
            // reverse: pointcut routes aimed at this class
            if (id.endsWith(".class")) {
                val stem = id.substringAfterLast('/').removeSuffix(".class")
                for (d in all) if (d.id.startsWith("pointcut/")) {
                    @Suppress("UNCHECKED_CAST")
                    val cls = (d.fields.firstOrNull { it.name == "coordinate" }?.value as? Map<String, Any?>)?.get("className")?.toString()
                    if (cls != null && cls.substringAfterLast('.') == stem) edges += mapOf("to" to d.id, "kind" to "pointcut-source")
                }
            }
        }
        return mapOf("node" to id, "cid" to cid, "edges" to edges.take(200))
    }

    /**
     * Blast radius over [dagFor]'s edge set, walked in the dependent direction only: documents
     * naming the same blob (shared-blob) and pointcuts aimed at a class (pointcut-source).
     * Levels are breadth-first rings 1..depth; a node lands in the first ring that reaches it.
     */
    private fun impactFor(id: String, depth: Int): Map<String, Any?> {
        val all = couchStore?.all().orEmpty()
        val byCid = HashMap<String, MutableList<String>>()
        val cidById = HashMap<String, String>()
        val pointcutsByStem = HashMap<String, MutableList<String>>()
        for (d in all) {
            cidOf(d)?.let { cid -> cidById[d.id] = cid; byCid.getOrPut(cid) { mutableListOf() } += d.id }
            if (d.id.startsWith("pointcut/")) {
                @Suppress("UNCHECKED_CAST")
                val cls = (d.fields.firstOrNull { it.name == "coordinate" }?.value as? Map<String, Any?>)?.get("className")?.toString()
                if (cls != null) pointcutsByStem.getOrPut(cls.substringAfterLast('.')) { mutableListOf() } += d.id
            }
        }
        if (all.none { it.id == id }) return mapOf("node" to id, "depth" to depth, "total" to 0, "levels" to emptyList<Any?>())
        val seen = hashSetOf(id)
        var ring = listOf(id)
        val levels = mutableListOf<Map<String, Any?>>()
        for (level in 1..depth) {
            val next = mutableListOf<String>()
            for (n in ring) {
                cidById[n]?.let { cid -> for (m in byCid[cid].orEmpty()) if (seen.add(m)) next += m }
                if (n.endsWith(".class")) for (m in pointcutsByStem[n.substringAfterLast('/').removeSuffix(".class")].orEmpty()) if (seen.add(m)) next += m
            }
            levels += mapOf("depth" to level, "count" to next.size, "ids" to next.take(200))
            if (next.isEmpty()) break
            ring = next
        }
        return mapOf("node" to id, "cid" to cidById[id], "depth" to depth, "total" to seen.size - 1, "levels" to levels,
            "source" to kotlinImpact(all, id, depth))
    }

    private val kotlinHeaders = ConcurrentHashMap<String, borg.trikeshed.dag.KotlinHeader>()
    @Volatile private var kotlinGraph: Triple<List<String>, List<String>, borg.trikeshed.dag.KotlinSourceGraph>? = null

    /**
     * Kotlin source dependents of a worktree `.kt` document: [borg.trikeshed.dag.KotlinSourceGraph]
     * over every `projects/` `.kt` document's attachment bytes, headers cached by content id and
     * the graph rebuilt when the id/cid set changes.
     */
    private fun kotlinImpact(all: List<Document>, id: String, depth: Int): Map<String, Any?> {
        if (!id.endsWith(".kt")) return mapOf("available" to false, "reason" to "not_kotlin_source")
        val db = couch ?: return mapOf("available" to false, "reason" to "cas_database_unavailable")
        val docs = all.filter { it.id.startsWith("projects/") && it.id.endsWith(".kt") && !isGraalDeleted(it) && cidOf(it) != null }
            .sortedBy { it.id }
        val ids = docs.map { it.id }
        val cids = docs.map { cidOf(it)!! }
        val graph = kotlinGraph?.takeIf { it.first == ids && it.second == cids }?.third ?: run {
            val headers = Array(docs.size) { k ->
                kotlinHeaders.getOrPut(cids[k]) {
                    borg.trikeshed.dag.kotlinHeader(db.blockGet(cids[k]) ?: ByteArray(0))
                }
            }
            borg.trikeshed.dag.KotlinSourceGraph(headers).also { kotlinGraph = Triple(ids, cids, it) }
        }
        val node = ids.binarySearch(id)
        if (node < 0) return mapOf("available" to false, "reason" to "source_document_missing")
        val h = graph.headers[node]
        val rings = graph.rings(node, depth)
        return mapOf(
            "available" to true,
            "package" to h.pkg,
            "imports" to h.imports.size,
            "declared" to h.declared.distinct(),
            "siblings" to (graph.packages[h.pkg]?.size ?: 1) - 1,
            "graph" to mapOf(
                "files" to ids.size, "packages" to graph.packages.size,
                "importLines" to graph.importLines, "unresolvedImports" to graph.unresolvedImports,
                "importEdges" to graph.importEdges, "packageEdges" to graph.packageEdges,
            ),
            "total" to rings.sumOf { it.a.size + it.b.size },
            "levels" to rings.mapIndexed { k, r ->
                mapOf(
                    "depth" to k + 1, "count" to r.a.size + r.b.size,
                    "viaImport" to r.a.size, "viaPackage" to r.b.size,
                    "ids" to (r.a.map { ids[it] } + r.b.map { ids[it] }).take(200),
                )
            },
        )
    }

    /** The DAG's high-degree vertices: blobs named by more than one document (dedup hubs). */
    private fun dagHubs(): Map<String, Any?> {
        val byCid = HashMap<String, MutableList<String>>()
        for (d in couchStore?.all().orEmpty()) {
            val cid = cidOf(d) ?: continue
            byCid.getOrPut(cid) { mutableListOf() } += d.id
        }
        val hubs = byCid.entries.filter { it.value.size > 1 }.sortedByDescending { it.value.size }.take(60)
            .map { (cid, ids) -> mapOf("cid" to cid, "degree" to ids.size, "ids" to ids.take(24)) }
        return mapOf("hubs" to hubs)
    }

    // ── pointcut routes: the `pointcut/…` plane of the store ─────

    private fun pointcutDocs() = couchStore?.all().orEmpty().filter { it.id.startsWith("pointcut/") }

    /** Live observations are read through their owner, without pretending they are Couch revisions. */
    private fun livePointcut(id: String): Map<String, Any?>? =
        (pointcuts?.blackboard?.get(id) as? borg.trikeshed.pointcut.PointcutBlackboardAdapter.PointcutLanding)
            ?.let(::pointcutFields)

    private fun pointcutFields(landing: borg.trikeshed.pointcut.PointcutBlackboardAdapter.PointcutLanding): Map<String, Any?> =
        mapOf("_id" to landing.key, "facet" to landing.facet.id, "mark" to landing.markRaw.toInt(),
            "property" to landing.propertyName, "value" to landing.value,
            "coordinate" to landing.coordinateFields(), "persistence" to "live observation") + landing.sourceFields()

    private fun pointcutSummary(): Map<String, Any?> {
        val rows = pointcutRoutes()
        return mapOf(
            "routes" to rows.size,
            "byFacet" to rows.groupingBy { it["facet"]?.toString() ?: "?" }.eachCount(),
        )
    }

    private fun pointcutRoutes(): List<Map<String, Any?>> {
        val live = pointcuts?.blackboard?.snapshot()?.values?.values.orEmpty().mapNotNull {
            (it as? borg.trikeshed.pointcut.PointcutBlackboardAdapter.PointcutLanding)?.let(::pointcutFields)
        }
        val stored = pointcutDocs().map { d -> d.fields.associate { it.name to it.value } + ("_id" to d.id) }
        return (live + stored).distinctBy { it["_id"] }.map { row ->
            val d = sanitizeGraalDocument(row["_id"].toString(), row)
            fun f(n: String): Any? = d[n]
            @Suppress("UNCHECKED_CAST")
            val coord = f("coordinate") as? Map<String, Any?> ?: emptyMap()
            mapOf(
                "route" to d["_id"],
                "facet" to f("facet"),
                "property" to f("property"),
                "value" to f("value"),
                "mark" to f("mark"),
                "className" to coord["className"],
                "methodName" to coord["methodName"],
                "bci" to coord["bytecodeOffset"],
                "sourcePath" to f("sourcePath"),
                "line" to f("line"),
                "column" to f("column"),
            )
        }.sortedBy { it["route"].toString() }
    }

    // ── the flourish feed ────────────────────────────────────────

    /**
     * H2 scoring tape: completed scoring sessions join the SSE fanout as `score` events
     * beside compile|deopt|gc|cpu|commit|vm. Publishers emit [scoreEvents]; Step F's
     * session service (mechanical scorers only) is the intended source.
     */
    private val _scoreEvents = MutableSharedFlow<Map<String, Any?>>(replay = 32, extraBufferCapacity = 256)
    val scoreEvents: SharedFlow<Map<String, Any?>> = _scoreEvents.asSharedFlow()

    /** Publish one scoring-session completion onto the tape. */
    fun publishScore(sessionCid: String, corpusSeq: Long, scores: Int, topConfidence: String) {
        _scoreEvents.tryEmit(mapOf(
            "session" to sessionCid, "corpusSeq" to corpusSeq,
            "scores" to scores, "confidence" to topConfidence,
        ))
    }

    private suspend fun stream(respond: suspend (ByteArray) -> Unit) {
        val head = "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\nAccess-Control-Allow-Origin: *\r\n\r\n"
        respond(head.toByteArray(StandardCharsets.UTF_8))
        val out = Channel<String>(capacity = 256)
        val jobs = mutableListOf(
            vitals.events.onEach { e ->
                out.send(jsonOf(mapOf("kind" to e.kind, "at" to e.atMs) + e.detail))
            }.launchIn(scope),
            classEvents.onEach { e ->
                out.send(jsonOf(mapOf("kind" to e.kind, "at" to e.atMs) + e.detail))
            }.launchIn(scope),
            scoreEvents.onEach { m ->
                out.send(jsonOf(mapOf("kind" to "score", "at" to System.currentTimeMillis()) + m))
            }.launchIn(scope),
        )
        report?.let { r ->
            jobs += r.events.onEach { e ->
                if (e is CouchReportEvent.Committed) {
                    out.send(jsonOf(mapOf("kind" to "commit", "id" to e.docId, "seq" to e.seq, "deleted" to e.deleted, "at" to e.timestampMs)))
                }
            }.launchIn(scope)
        }
        vmHost?.let { h ->
            // Sub-VM runs were previously silent: a spawn/eval/revoke on /api/vm had no signal on
            // the console until the next 5s poll. These land on the same feed the terrain uses.
            jobs += h.events.onEach { e ->
                val m = e.toMap()
                out.send(jsonOf(mapOf("kind" to "vm", "vmKind" to m["kind"]) + m.filterKeys { it != "kind" }))
            }.launchIn(scope)
        }
        try {
            for (line in out) {
                respond("data: $line\n\n".toByteArray(StandardCharsets.UTF_8))
            }
        } catch (_: Throwable) {
            // client went away — the normal end of a feed
        } finally {
            jobs.forEach { it.cancel() }
            out.close()
        }
    }
}

private val MANIFEST = """
{
  "name": "Graal Console",
  "short_name": "Graal",
  "start_url": "/graal",
  "display": "standalone",
  "background_color": "#0b0e14",
  "theme_color": "#0b0e14",
  "icons": [
    { "src": "/icons/forge-icon.svg", "sizes": "any", "type": "image/svg+xml" },
    { "src": "/icons/forge-icon-maskable.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "maskable" }
  ]
}
""".trimIndent()
