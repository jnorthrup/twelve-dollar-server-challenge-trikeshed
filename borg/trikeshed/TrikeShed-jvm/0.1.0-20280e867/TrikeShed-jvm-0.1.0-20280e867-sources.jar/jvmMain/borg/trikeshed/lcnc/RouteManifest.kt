package borg.trikeshed.lcnc

/**
 * The registered route manifest, written once at each wire's definition site
 * and consumed by [RouteParityGate] and RouteManifestParityTest. A route that
 * starts serving without a manifest line FAILS the gate — the manifest is the
 * single author of "what does this daemon answer", and the gate is what keeps
 * it honest.
 *
 * Manifest shape: `METHOD PATH` where PATH may carry:
 * - ellipsis (…) wildcard meaning "any continuation" (prefix match, mirrors startsWith)
 * - `{param}` segments matching any single path segment (parameterized routes)
 *
 * Streaming/SSE routes are annotated by the wires themselves; the gate only
 * checks existence, not transport.
 *
 * The couch surface (/{db}/ pattern) is reconciled with
 * `src/commonMain/resources/openapi/couch-oroboros.openapi.yaml` — that spec
 * stays authoritative for request/response schemas on the couch/_cas surface.
 *
 * Machine-readable: call [toJson] to serialize the manifest to JSON.
 */
object RouteManifest {
    /** A manifest entry with method, path, and a one-line summary. */
    data class RouteEntry(val method: String, val path: String, val summary: String) {
        override fun toString(): String = "$method $path"
    }

    /** Every route the daemon serves, grouped by owning wire. */
    val entries: Map<String, List<RouteEntry>> = mapOf(
        // -- PatchWire: mux/projects/panels/LCNC --
        "PatchWire" to listOf(
            RouteEntry("GET", "/api/mux/models", "discovered provider roster"),
            RouteEntry("GET", "/api/mux/catalog", "full operator catalog including provider-qualified model ids"),
            RouteEntry("GET", "/api/mux/keys", "full roster with key-presence flags"),
            RouteEntry("GET", "/api/mux/standings", "quota-legion standings"),
            RouteEntry("GET", "/api/mux/endpoints", "user-declared provider endpoints"),
            RouteEntry("POST", "/api/mux/endpoints", "register a provider endpoint"),
            RouteEntry("DELETE", "/api/mux/endpoints/{name}", "remove a provider endpoint"),
            RouteEntry("POST", "/api/mux/chat", "provider-neutral failover chat"),
            RouteEntry("GET", "/api/mux/activity", "bounded live model call receipts"),
            RouteEntry("GET", "/api/mux/reel", "live ACE comparison, breadcrumb lineage and measurements"),
            RouteEntry("POST", "/api/mux/reel/run", "compare identical source through full, main hierarchical and local hierarchical summaries"),
            RouteEntry("POST", "/api/mux/reel/vote", "record a human comparison against a specific ACE run"),
            RouteEntry("POST", "/api/mux/reel/review", "persist summary accuracy, selection, concept review and source-linked human correction"),
            RouteEntry("POST", "/api/mux/reel/retain", "pin a captured-byte fraction within a time window at a durable manifest watermark"),
            RouteEntry("GET", "/api/mux/reel/payload", "retrieve the complete CID-verified payload named by a reel manifest"),
            RouteEntry("GET", "/api/mux/sessions", "durable conversations and branch tracking"),
            RouteEntry("POST", "/api/mux/sessions", "create conversation"),
            RouteEntry("POST", "/api/mux/sessions/run", "run chat or model fan-out and fan-in"),
            RouteEntry("POST", "/api/mux/sessions/cancel", "cancel a session run and its branches"),
            RouteEntry("POST", "/api/mux/sessions/fork", "fork conversation history"),
            RouteEntry("POST", "/api/mux/sessions/update", "rename or archive conversation"),
            RouteEntry("GET", "/api/lcnc/mating-options", "kind-compatible mates for a source port"),
            RouteEntry("GET", "/api/lcnc/fills", "param fills for a node type"),
            RouteEntry("GET", "/api/lcnc/autowire", "auto-wire proposal between two types"),
            RouteEntry("POST", "/api/lcnc/treeshake", "whole-graph tree-shake under type/scope rules"),
            RouteEntry("GET", "/api/projects", "mounted project scopes"),
            RouteEntry("POST", "/api/projects", "mount a directory as a project scope"),
            RouteEntry("DELETE", "/api/projects/{name}", "unmount a project scope"),
            RouteEntry("GET", "/api/panels", "list stored panel constructions"),
            RouteEntry("GET", "/api/panels/presets", "LCNC preset gallery"),
            RouteEntry("GET", "/api/panels/{name}", "load a panel construction; ?entry=1 is the board entry with typed cables, ?history=1 lists the versions the program ledger recorded"),
            RouteEntry("POST", "/api/panels/{name}", "save a panel construction; ?baseCid= names the version the editor loaded and a moved board refuses with 409 stale_base"),
            RouteEntry("GET", "/api/prompts", "the stored prompts: every head with its lineage"),
            RouteEntry("GET", "/api/prompts/{name}", "a prompt head's canonical bytes; ?history=1 lists its recorded versions"),
            RouteEntry("POST", "/api/prompts/{name}", "save a prompt version (text/plain, or JSON {text, role?, tags?, baseCid?}); a stale baseCid is refused"),
            RouteEntry("POST", "/api/snapshots", "take a workspace snapshot {note?}: programs, prompts, project sequences, latest receipts, as one CAS citizen"),
            RouteEntry("GET", "/api/snapshots", "the snapshot lineage, newest first"),
            RouteEntry("GET", "/api/snapshots/{cid}", "one snapshot's canonical bytes, cid-verified"),
            RouteEntry("GET", "/api/projects/{name}/docs", "a mounted project's document listing (prefix, glob, limit)"),
            RouteEntry("GET", "/api/projects/{name}/docs/{id}", "one project document: text, cid, rev, seq, and the miner's extract twin"),
            RouteEntry("POST", "/api/projects/{name}/docs/{id}/retain-source", "retain a selected primary TXT/MD source revision for review; requires exact cid/rev/seq"),
            RouteEntry("PUT", "/api/projects/{name}/notes/{id}", "curation notes beside a document (`key: value` conventions + prose), read by project.notes and book.curate"),
            RouteEntry("GET", "/api/projects/{name}/recognize/{id}", "what one document is before ingest: bytes, type, text layer or OCR, pages, sampled columns per page, ingested yet"),
            RouteEntry("POST", "/api/projects/{name}/ingest/{id}", "ingest one document by hand: its text lands as the extract twin (text layer in column order, else OCR)"),
            RouteEntry("POST", "/api/projects/{name}/mine", "Tika/OCR mining over a project"),
            RouteEntry("GET", "/api/projects/{name}/mine", "mining progress"),
        ),
        // -- ModuleWire: module lifecycle --
        // -- LcncRdfWire: the canvas as RDF, and its alignment --
        "LcncRdfWire" to listOf(
            RouteEntry("POST", "/api/lcnc/spacegraph", "commonMain SpaceGraph shadow of the full LCNC document, typed ports and epistemic alignment candidates"),
            RouteEntry("GET", "/api/lcnc/rdf", "LCNC vocabulary as Turtle (ontology + bindings)"),
            RouteEntry("POST", "/api/lcnc/rdf", "a program document as Turtle (ports as resources, one lcnc:feeds per cable)"),
            RouteEntry("POST", "/api/lcnc/rdf/program", "Turtle in the LCNC vocabulary back to a program document"),
            RouteEntry("POST", "/api/lcnc/rdf/align", "a program joined with the Rete productions, causal rules and KIF facts that mention its terms; plus its causal projection for /api/beliefs/kg"),
        ),
        // -- ReteWire: the fact plane read back — JSON, Turtle, and who watches it --
        "ReteWire" to listOf(
            RouteEntry("GET", "/api/rete/facts", "current Rete facts as JSON {count, facts:[{partition,id,versionCid,fields}]}: ?partition= alone lists a partition, &field=&value= filters on one field, ?key= filters on the reserved key field"),
            RouteEntry("GET", "/api/facts/rdf", "the same selection projected through PlaneFacts.toTriples as Turtle (fact:/plane# prefixes); every partition when ?partition= is omitted"),
            RouteEntry("GET", "/api/rete/productions", "registered productions {count, productions:[{ruleId, salience, interests:[field=value]}]} — the row shape /api/lcnc/rdf/align prints"),
        ),
        // -- PostgrestWire: Supabase's data API over the SQL catalog --
        "PostgrestWire" to listOf(
            RouteEntry("GET", "/rest/v1", "OpenAPI 2.0 of the SQL tables (PostgREST)"),
            RouteEntry("GET", "/rest/v1/{table}", "PostgREST read: select, filters, order, limit, offset, Range, Prefer count"),
            RouteEntry("POST", "/rest/v1/{table}", "PostgREST insert, upsert with on_conflict (Prefer return, resolution)"),
            RouteEntry("PATCH", "/rest/v1/{table}", "PostgREST update of the filtered rows"),
            RouteEntry("DELETE", "/rest/v1/{table}", "PostgREST delete of the filtered rows"),
            RouteEntry("POST", "/rest/v1/rpc/{fn}", "a function call: match_documents, evoke_query, evoke_hybrid_fuse_candidates"),
            RouteEntry("GET", "/rest/v1/rpc/{fn}", "a stable function called with its arguments in the query string"),
            RouteEntry("POST", "/pg/query", "pg-meta raw SQL: SELECT, CREATE TABLE, DROP TABLE, and SPARQL … (SPASQL) over DB.DBA.RDF_QUAD"),
        ),
        "DocumentPdfLinksWire" to listOf(
            RouteEntry("POST", "/api/documents/pdf-links", "retain unreviewed URI annotation candidates from an exact current PDF revision; no fetch or model"),
            RouteEntry("POST", "/api/documents/pdf-links/collect", "collect selected host-issued PDF links under existing egress policy into the same manual project; source-linked and unreviewed"),
        ),
        "DocumentReviewWire" to listOf(
            RouteEntry("POST", "/api/documents/review/horn-query", "bounded operator-configured native Horn query over authenticated review observations; no admission"),
            RouteEntry("POST", "/api/documents/review/horn-input", "prepare authenticated review-record observations for the pinned Horn backend; no execution or admission"),
            RouteEntry("POST", "/api/documents/review/taxonomy-plan", "Authenticated non-consuming current STRICT_BOOK inspection with explicit taxonomy exclusions; no sink permit or norm promotion"),
        ),
        // -- SparqlWire: Virtuoso's SPARQL endpoint over the quad store --
        "SparqlWire" to listOf(
            RouteEntry("GET", "/sparql", "SPARQL 1.1 protocol: query, default-graph-uri, named-graph-uri; format or Accept picks results JSON, CSV or TSV"),
            RouteEntry("POST", "/sparql", "SPARQL 1.1 protocol by form or application/sparql-query; SPARQL Update INSERT DATA and DELETE DATA by update or application/sparql-update"),
            RouteEntry("POST", "/sparql/visual", "Read-only LCNC SPARQL syntax graph over the explicitly selected quad-store or quad-store+rete dataset"),
            RouteEntry("POST", "/sql/visual", "Read-only limited LCNC SQL syntax graph over the quad store"),
            RouteEntry("POST", "/db/{db}/tx/commit", "Neo4j HTTP API: Cypher MATCH statements over the quad store, answered in the results, data, row shape"),
        ),
        "ModuleWire" to listOf(
            RouteEntry("GET", "/api/modules", "attached modules and claimed routes"),
            RouteEntry("POST", "/api/modules", "attach a module by FQCN"),
            RouteEntry("DELETE", "/api/modules/{id}", "detach a module"),
        ),
        // -- KanbanModule: board + LCNC runtimes --
        "KanbanModule" to listOf(
            RouteEntry("GET", "/api/board", "WAL-backed live board"),
            RouteEntry("POST", "/api/invoke", "batched browser commands to store intake"),
            RouteEntry("POST", "/api/board/import", "tolerant plan-doc import"),
            RouteEntry("POST", "/api/archives/import", "ZIP entries (JSON {path, mediaType, base64}) into the TreeDoc/CAS pipeline; returns the manifest cid"),
            RouteEntry("GET", "/api/archives/manifest", "an archive's immutable entry identities and ordinals, by cid"),
            RouteEntry("GET", "/api/archives/content", "one restored entry's bytes, CID-verified, by cid and entry"),
            RouteEntry("GET", "/api/lcnc/kanban", "active LCNC sheets"),
            RouteEntry("GET", "/api/lcnc/concentric", "modules + rings + wizard roster"),
            RouteEntry("GET", "/api/lcnc/workgroups", "live declared program workgroups, frozen program identities and registration refusals"),
            RouteEntry("POST", "/api/lcnc/kanban/move", "move a card to a new column"),
            RouteEntry("GET", "/api/lcnc/contracts", "late-bound LCNC vocabulary: contracts + composites, kind hierarchy, bindings"),
            RouteEntry("GET", "/api/lcnc/workspace", "workspace facets, bound runners and installed language capabilities"),
            RouteEntry("POST", "/api/lcnc/workspace", "inspect constructions, pinned CAS JSON or indexed Couch revisions through Confix facets without executing or publishing"),
            RouteEntry("PUT", "/api/lcnc/workspace", "explicit bounded Couch-to-dense indexing; source and checkpoints unchanged"),
            RouteEntry("GET", "/api/lcnc/ontology", "the same vocabulary as Turtle triples (kinds, ports, bindings)"),
            RouteEntry("GET", "/api/lcnc/facts", "the vocabulary, corpus wires and bindings as KIF tuples — what LcncFacts.parse reads back"),
            RouteEntry("POST", "/api/lcnc/run", "generic runner dispatch"),
            RouteEntry("GET", "/api/lcnc/content", "bounded immutable LCNC content by cid; raw JSON or shared sheet projection"),
            RouteEntry("GET", "/api/lcnc/trail", "the LCNC activity ring drained from ?since=<seq>&nodes=<known>: packed begin/end/ring/yield/turn/skip/fail events, new node rows, and how many events the reader lost"),
            RouteEntry("GET", "/api/lcnc/runs", "the head run for a program's current version and canonical inputs (?program=&inputs=&show=): what a page's lcnc-run block shows — lamp, reason, receipt cid, rebuildOf, and the stale marker naming the moved documents"),
            RouteEntry("POST", "/api/lcnc/run/cancel", "cancel an active scoped run; receipt lands on the durable work timeline"),
            RouteEntry("GET", "/api/lcnc/run/debug", "read an active run's transient node-boundary pause by debug token"),
            RouteEntry("POST", "/api/lcnc/run/debug", "step or continue the same admitted run at the observed pause ordinal; stale commands are refused"),
            RouteEntry("GET", "/api/lcnc/oroboros", "local concentric execution inventory and live or retained LCNC debugger state by runId"),
            RouteEntry("POST", "/api/lcnc/oroboros", "pointcut selection, cooperative pause/cancel, paused inputs and lexical scope edits, bounded monitoring"),
            RouteEntry("POST", "/api/lcnc/run/rebuild", "re-execute a completed receipt's exact program version with its recorded inputs {runId} or {receiptCid}; the new receipt names rebuildOf and retires the old stale marker"),
            RouteEntry("GET", "/api/lcnc/council", "council case read-back: index fact + transcript/verdict from CAS (?caseId=<id>)"),
            RouteEntry("GET", "/api/mcp", "MCP server card: protocol versions, tools, resource URIs"),
            RouteEntry("POST", "/api/mcp", "MCP JSON-RPC: the LCNC Kanban board as tools and resources"),
        ),
        // -- GraalWire: console + terrain + ingest + capsule + occupy --
        "GraalWire" to listOf(
            RouteEntry("GET", "/graal", "console page"),
            RouteEntry("GET", "/futon", "couch-CRUD companion page"),
            RouteEntry("GET", "/graal.webmanifest", "PWA install manifest"),
            RouteEntry("GET", "/api/graal/vitals", "JVM vitals + pointcut summary"),
            RouteEntry("GET", "/api/graal/heap", "heap histogram"),
            RouteEntry("GET", "/api/graal/allocations", "bounded recent allocation sites"),
            RouteEntry("GET", "/api/graal/allocation-frame", "sampled frame classpath and bytecode projection"),
            RouteEntry("GET", "/api/graal/pointcuts", "pointcut route table"),
            RouteEntry("GET", "/api/graal/map", "full store as compact [id, bytes] rows"),
            RouteEntry("GET", "/api/graal/doc", "selected document detail sanitized for the Graal inspector"),
            RouteEntry("GET", "/api/graal/content", "selected attachment bytes through the Graal project-db resolver"),
            RouteEntry("GET", "/api/graal/zoom", "mid-zoom ring representatives per code ring"),
            RouteEntry("GET", "/api/graal/strength", "CAS-granting-strength proof between two cids"),
            RouteEntry("GET", "/api/graal/density", "per-region residual density at a zoom band"),
            RouteEntry("GET", "/api/graal/sheet", "live CursorSheet for a document"),
            RouteEntry("GET", "/api/graal/dag", "DAG arcs and cross-links"),
            RouteEntry("GET", "/api/graal/impact", "dependents of a node ringed by depth"),
            RouteEntry("GET", "/api/graal/classfile", "selected class attachment projection via JDK 25"),
            RouteEntry("GET", "/api/graal/decompile", "source + classpath mates via JDK 25"),
            RouteEntry("GET", "/api/graal/aot", "AOT flags and HotSpot cache metadata"),
            RouteEntry("GET", "/api/graal/aot/blob", "HotSpot AOT archive bytes"),
            RouteEntry("POST", "/api/graal/aot/capture", "land AOT archive into CAS"),
            RouteEntry("GET", "/api/graal/events", "SSE: compile/deopt/gc/cpu + store commits"),
            RouteEntry("POST", "/api/graal/ingest", "raw bytes through Tika/OCR to store citizen"),
            RouteEntry("GET", "/api/graal/capsule/list", "list hermes capsules"),
            RouteEntry("POST", "/api/graal/capsule/spawn", "spawn a hermes capsule"),
            RouteEntry("POST", "/api/graal/capsule/{id}/stdin", "type at captured shell"),
            RouteEntry("GET", "/api/graal/capsule/{id}/output", "VT scrollback (poll)"),
            RouteEntry("POST", "/api/graal/capsule/{id}/kill", "interrupt + close guest"),
            RouteEntry("GET", "/api/graal/occupy", "list occupied repos"),
            RouteEntry("POST", "/api/graal/occupy", "absorb a git repo"),
            RouteEntry("POST", "/api/graal/occupy/{id}/release", "stop watching"),
        ),
        // -- VmWire: metered sub-VMs + terminals --
        "VmWire" to listOf(
            RouteEntry("GET", "/vm-terminal", "VT220 web terminal page"),
            RouteEntry("GET", "/api/agents", "the coding-agent roster on this host: which CLIs exist, versions, enabled or why not"),
            RouteEntry("GET", "/api/agents/runs", "agent/run receipts, newest first (limit, jobId)"),
            RouteEntry("GET", "/api/vm", "VM sheet"),
            RouteEntry("POST", "/api/vm/spawn", "spawn a sub-VM"),
            RouteEntry("POST", "/api/vm/{id}/eval", "evaluate source in a VM"),
            RouteEntry("POST", "/api/vm/{id}/revoke", "revoke a VM"),
            RouteEntry("GET", "/api/vm/events", "SSE of VmEvent"),
            RouteEntry("GET", "/api/vm/terminals", "terminal snapshots"),
            RouteEntry("GET", "/api/vm/terminal/events", "global terminal patch SSE"),
            RouteEntry("GET", "/api/vm/{id}/terminal", "one terminal snapshot"),
            RouteEntry("POST", "/api/vm/{id}/terminal/input", "send input to terminal"),
            RouteEntry("POST", "/api/vm/{id}/terminal/resize", "resize terminal"),
        ),
        // -- BeliefWire: NARS curation loop --
        "BeliefWire" to listOf(
            RouteEntry("GET", "/api/beliefs", "top-k beliefs with budgets"),
            RouteEntry("GET", "/api/beliefs/render", "bounded MEMORY render"),
            RouteEntry("POST", "/api/beliefs/review", "facts to induction pass"),
            RouteEntry("POST", "/api/beliefs/tick", "one DecayTick"),
            RouteEntry("POST", "/api/beliefs/teach", "curator hindsight pass (W5.3)"),
            RouteEntry("POST", "/api/beliefs/query", "bank solver query (W5.3)"),
            RouteEntry("POST", "/api/beliefs/resonate", "solver proposal support and refutation"),
            RouteEntry("GET", "/api/beliefs/introspect", "NAL-9 introspection"),
            RouteEntry("POST", "/api/beliefs/kg", "Turtle/RDF/KIF to NAL beliefs"),
        ),
        // -- CouchWire: CouchDB 1.6/1.7 surface + CAS lanes --
        // Pattern families for {db}/* mounts; see couch-oroboros.openapi.yaml
        // for full request/response schemas on the couch/_cas surface.
        "CouchWire" to listOf(
            RouteEntry("GET", "/_all_dbs", "primary and project database names"),
            RouteEntry("GET", "/{db}", "database info"),
            RouteEntry("POST", "/{db}", "bare document put"),
            RouteEntry("GET", "/{db}/_all_docs", "all live document ids"),
            RouteEntry("POST", "/{db}/_all_docs", "restricted to keys"),
            RouteEntry("GET", "/{db}/_changes", "committed-frame log (streaming in CouchWire)"),
            RouteEntry("POST", "/{db}/_revs_diff", "which revisions node lacks"),
            RouteEntry("POST", "/{db}/_bulk_docs", "batch write"),
            RouteEntry("GET", "/{db}/_local/{id}", "read checkpoint"),
            RouteEntry("PUT", "/{db}/_local/{id}", "write checkpoint"),
            RouteEntry("DELETE", "/{db}/_local/{id}", "remove checkpoint"),
            RouteEntry("GET", "/{db}/_cas/{cid}", "get one raw block"),
            RouteEntry("POST", "/{db}/_cas", "put one raw block"),
            RouteEntry("POST", "/{db}/_cas/_bulk", "bulk block exchange"),
            RouteEntry("GET", "/{db}/_design/{ddoc}/_rewrite/{path}", "CouchApp rewrite"),
            RouteEntry("GET", "/{db}/_design/{ddoc}/_view/{view}", "incremental view"),
            RouteEntry("GET", "/{db}/…", "document JSON (id may contain slashes)"),
            RouteEntry("PUT", "/{db}/…", "create or update document"),
            RouteEntry("DELETE", "/{db}/…", "delete document"),
            RouteEntry("GET", "/{db}/…/content", "attachment bytes"),
            RouteEntry("POST", "/{db}/_replicate", "run or start replication"),
            RouteEntry("GET", "/{db}/_replicate", "list live replication jobs"),
            RouteEntry("GET", "/api/v0/block/get", "IPFS alias of _cas"),
            RouteEntry("POST", "/api/v0/block/put", "IPFS alias of _cas"),
        ),
        // -- BlackboardWire: ConfixBlackboard HTTP window --
        "BlackboardWire" to listOf(
            RouteEntry("GET", "/blackboard", "consolidated blackboard page"),
            RouteEntry("GET", "/blackboard/facts", "SSE delta feed"),
            RouteEntry("POST", "/blackboard/assert", "assert key-value pairs"),
            RouteEntry("GET", "/blackboard/sites", "pointcut site listing"),
            RouteEntry("GET", "/blackboard/board", "full board snapshot"),
            RouteEntry("GET", "/blackboard/neighbors", "read-only whole-board SUMO, lexical and reference neighbors for ?key=; optional revision, limit (default 32, clamped 1..256) and corpus=middle; stale revision returns 409; score is similarity, not confidence"),
            RouteEntry("GET", "/blackboard/sheet", "one fact (?key=) or one territory (?prefix=) as a grid-in-cell sheet family (CursorSheet); ?max= caps the family"),
        ),
        // -- HermesWire: supervised Hermes VM console --
        "HermesWire" to listOf(
            RouteEntry("GET", "/hermes", "Hermes console page"),
            RouteEntry("GET", "/api/hermes/terminal", "terminal snapshot"),
            RouteEntry("POST", "/api/hermes/terminal/open", "open terminal session"),
            RouteEntry("POST", "/api/hermes/terminal/input", "send input"),
            RouteEntry("POST", "/api/hermes/terminal/resize", "resize terminal"),
            RouteEntry("GET", "/api/hermes/terminal/events", "SSE terminal events"),
            RouteEntry("GET", "/api/sleeves", "polyglot agent sleeve roll-up"),
            RouteEntry("GET", "/api/sleeves/cards", "TDD-red cards generated by unresolved traps"),
            RouteEntry("GET", "/api/sleeves/{id}", "one sleeve manifest and its traps"),
        ),
        // -- JulesWire: session surface projection --
        "JulesWire" to listOf(
            RouteEntry("GET", "/api/jules/surface", "Jules session surface projection"),
            RouteEntry("GET", "/api/jules/events", "Jules event stream (retired)"),
        ),
        // -- WebhookWire: signed inbound webhooks --
        "WebhookWire" to listOf(
            RouteEntry("POST", "/hook/{program}/{node}/{port}", "signed inbound webhook"),
        ),
        // -- ProjectDbWire: browser-drop upload lane --
        "ProjectDbWire" to listOf(
            RouteEntry("POST", "/_project/{name}/begin", "begin browser-drop upload"),
            RouteEntry("POST", "/_project/{name}/putBatch", "batched file upload"),
            RouteEntry("POST", "/_project/{name}/put", "single file upload"),
            RouteEntry("DELETE", "/_project/{name}/doc", "remove an uploaded document with its twins, or a folder"),
        ),
        // -- IngestRoutes: drop-a-corpus entry points --
        "IngestRoutes" to listOf(
            RouteEntry("POST", "/api/submit", "document submit via Tika/OCR"),
            RouteEntry("POST", "/api/donor", "donor document submit"),
        ),
        // -- BuiltIn: daemon infrastructure --
        "BuiltIn" to listOf(
            RouteEntry("GET", "/api/health", "server health check"),
            RouteEntry("GET", "/api/cap", "server capabilities"),
            RouteEntry("GET", "/api/metrics", "flywheel metrics (retired)"),
            RouteEntry("GET", "/harness", "blackboard harness surface"),
            RouteEntry("GET", "/documents", "document surface: the first page drawn by commonMain through the Kotlin/JS bundle"),
            RouteEntry("GET", "/documents.html", "document surface (file name form)"),
            RouteEntry("GET", "/kotlin/{app}/…", "compiled Kotlin browser app bundles and chunks"),
        ),
    )

    /** Backward-compatible string map derived from [entries]. */
    val routes: Map<String, List<String>> = entries.mapValues { (_, v) -> v.map { it.toString() } }

    val all: List<String> = routes.values.flatten()

    private const val WILDCARD = "…"

    /** Longest-prefix manifest match with {param} segment support. */
    fun covers(method: String, path: String): Boolean {
        val exact = "$method $path"
        if (exact in all) return true
        return entries.values.flatten().any { entry ->
            entry.method == method && matchPath(entry.path, path)
        }
    }

    /** Match a manifest path pattern against an actual request path. */
    private fun matchPath(pattern: String, path: String): Boolean {
        // Wildcard prefix: ends with ellipsis
        if (pattern.endsWith(WILDCARD)) {
            val prefix = pattern.removeSuffix(WILDCARD).trimEnd('/')
            val prefixSegs = prefix.trim('/').split('/')
            val pathSegs = path.trim('/').split('/')
            if (pathSegs.size < prefixSegs.size) return false
            return prefixSegs.zip(pathSegs).all { (p, s) ->
                p == s || (p.startsWith("{") && p.endsWith("}"))
            }
        }
        // Segment-by-segment matching with {param} wildcards
        val patternSegs = pattern.trim('/').split('/')
        val pathSegs = path.trim('/').split('/')
        if (patternSegs.size != pathSegs.size) return false
        return patternSegs.zip(pathSegs).all { (p, s) ->
            p == s || (p.startsWith("{") && p.endsWith("}"))
        }
    }

    /** Serialize the manifest to a machine-readable JSON artifact. */
    fun toJson(): String {
        val sb = StringBuilder()
        sb.append("{\n  \"version\": \"1.0\",\n  \"routes\": {\n")
        var firstWire = true
        for ((wire, routeEntries) in entries) {
            if (!firstWire) sb.append(",\n")
            firstWire = false
            sb.append("    \"").append(wire).append("\": [\n")
            var first = true
            for (e in routeEntries) {
                if (!first) sb.append(",\n")
                first = false
                sb.append("      {\"method\":\"").append(e.method)
                sb.append("\",\"path\":\"").append(e.path)
                sb.append("\",\"summary\":\"").append(e.summary)
                sb.append("\"}")
            }
            sb.append("\n    ]")
        }
        sb.append("\n  }\n}")
        return sb.toString()
    }
}
