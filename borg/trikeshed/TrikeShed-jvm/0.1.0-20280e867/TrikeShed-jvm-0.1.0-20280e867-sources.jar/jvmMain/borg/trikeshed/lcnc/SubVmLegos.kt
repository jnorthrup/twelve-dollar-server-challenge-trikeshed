package borg.trikeshed.lcnc

import borg.trikeshed.parse.reify
import borg.trikeshed.parse.jsonOf
import borg.trikeshed.parse.reifyStrict
import borg.trikeshed.graal.subvm.VmLanguages
import borg.trikeshed.vm.*

import borg.trikeshed.lib.get
import borg.trikeshed.lib.j
import borg.trikeshed.lib.size
import borg.trikeshed.vm.Teleported
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.util.UUID

/**
 * Sub-VM module legos: tika / corenlp / camel / graalce hosted as [LcncNodeRunner]s
 * over [VmSupervisor.current] — the host's own hypervisor, so a lego run IS a
 * supervised guest eval riding [borg.trikeshed.vm.VmHandle], receipts and all.
 *
 * Low-code discipline: a lego's parameters are Strings authored in the surface; its
 * inputs are the ring's own node outputs; its outputs land back into the ring's warm
 * base. Every lego is declared in [LcncContracts] (the one vocabulary), so the
 * concentric surface renders it with zero bespoke UI.
 *
 * Facet spelling is the enum NAME (`JVM`, `GRAAL_JS`, …) — resolved through
 * [vmFacetOf], which accepts either id (`java`) or name (`JVM`). Trust is OWN by
 * default; a UNTRUSTED lego degrades to ProcessIsolate per the host's policy.
 * `world` params seed the guest workspace (OWN only).
 */
object SubVmLegos {
    const val TIKA = "vm.tika"
    const val CORENLP = "vm.corenlp"
    const val CORENLP_EXTRACT = "vm.corenlp.extract"
    const val CAMEL = "vm.camel"
    const val CAMEL_CATALOG = "vm.camel.catalog"
    const val GRAALCE = "vm.graalce"
    const val POLYGLOT = "vm.polyglot"
    const val MODULES = "vm.modules"

    /**
     * Register every lego into the daemon's [ModuleContext.lcncRunners]. Called from
     * the daemon after ModuleContext assembly; no other site registers vm.* runners.
     */
    fun register(ctx: borg.trikeshed.module.ModuleContext) {
        val host = borg.trikeshed.vm.VmSupervisor.current
        ctx.lcncRunners.putAll(VmRuntimeNodes.runners(host))
        ctx.lcncRunners[TIKA] = tika(host)
        ctx.lcncRunners[CORENLP] = corenlp(host)
        ctx.lcncRunners[CAMEL] = camel(host)
        ctx.lcncRunners[GRAALCE] = graalce(host)
        ctx.lcncRunners[POLYGLOT] = polyglot(host)
        ctx.lcncRunners["js"] = VmRuntimeNodes.expression(ctx.lcncRunners.getValue(POLYGLOT))
        ctx.lcncRunners[CORENLP_EXTRACT] = corenlpExtract(host)
        ctx.lcncRunners[MODULES] = modules()
        ctx.lcncRunners[CAMEL_CATALOG] = camelCatalog()
        // Only a host-supplied feed may bind document storage and ledger ownership.
        ctx.scope.coroutineContext[borg.trikeshed.graal.subvm.DocumentFeed]?.let { feed ->
            ctx.lcncRunners[DocumentCurationLegos.CURATE] = DocumentCurationLegos.curate(feed)
        }
    }

    // ── camel.catalog: what the mounted module can offer, read lazily ──

    /**
     * `vm.camel.catalog` — enumerate the mounted Camel module's own self-description.
     *
     * This is the lego behind the palette's LIVE picklists. `vm.camel`'s `from` and `to`
     * declare `optsFrom = "vm.camel.catalog#endpoints[]"`, so the editor fills them by
     * running THIS node with no params through the ordinary /api/lcnc/run lane — which is
     * why the default output has to be picklist-shaped and why it must never need a VM.
     * A palette that listed every endpoint statically would go stale the moment a module
     * was mounted or re-resolved; there is no list here to go stale.
     *
     * Read-only in the same structural sense as `vm.modules`: it takes no VM and declares
     * no port that could mount, install or execute anything. [CamelCatalog] only opens
     * zips. The worst a wrong `name` produces is a row saying that name is not there.
     */
    fun camelCatalog() = LcncNodeRunner { node, _ ->
        val module = node.params["module"]?.takeIf { it.isNotBlank() }
            ?: borg.trikeshed.graal.subvm.CamelCatalog.MODULE
        val kind = node.params["kind"]?.takeIf { it.isNotBlank() } ?: "endpoint"
        val name = node.params["name"]?.takeIf { it.isNotBlank() }
        val reach = when (node.params["reach"]?.trim()?.uppercase()) {
            "DEPARTMENT" -> borg.trikeshed.lcnc.CamelLinkage.Reach.DEPARTMENT
            else -> borg.trikeshed.lcnc.CamelLinkage.Reach.LOCAL
        }
        val catalog = borg.trikeshed.graal.subvm.CamelCatalog
        val installed = catalog.available(module)
        val chain = if (installed) catalog.mounted(module) else listOf(module)
        // `endpoints` is a real List<String>, not a JSON string: the picklist resolver walks
        // outputs.endpoints[] in the browser and a serialized array would arrive as text.
        //
        // Every kind here is SCOPED — by the mounted chain, and by reach. A picklist over
        // everything Camel ships would be a few hundred rows and unusable; a picklist over
        // one department is a dozen. That is the point of departments showing up as a
        // vocabulary rather than as a packaging detail.
        val names: List<String> = if (!installed) emptyList() else when (kind) {
            "eip" -> catalog.eips(module)
            "scheme" -> catalog.schemes(module)
            "linkage" -> borg.trikeshed.lcnc.CamelLinkage.admissible(reach, chain)
            "department" -> catalog.departments()
            else -> catalog.endpoints(module, reach)
        }
        val detail: String = when {
            !installed || name == null -> ""
            kind == "eip" -> catalog.eipJson(name, module) ?: ""
            kind == "scheme" -> catalog.componentJson(name, module) ?: ""
            else -> ""
        }
        mapOf(
            "endpoints" to names,
            "count" to names.size,
            "detail" to detail,
            "installed" to installed,
            // The chain a mount of this module actually sees, child first. An operator reading
            // a refusal needs to know what WAS mounted, not only what was missing.
            "mounted" to chain,
            // Schemes present on disk with no CamelLinkage row. Surfaced rather than logged:
            // drift between the mount and the admission table is exactly what an operator
            // needs to see before a route names something the gate will refuse.
            "unlisted" to if (installed) catalog.unlisted(module) else emptyList<String>(),
        )
    }

    // ── modules: what classpaths can this daemon execute from? ────────

    /**
     * `vm.modules` — enumerate every installed guest module, its mount state, and whether what is
     * on disk still matches the MANIFEST.tsv it was resolved from.
     *
     * This is the auditable half of the sub-VM. A mounted module is a classpath the daemon executes
     * code from, and until now the only account of which ones existed and whether they had drifted
     * lived in a KDoc. An operator could read the comment; they could not read the machine.
     *
     * It is deliberately READ-ONLY and takes no VM: it lists, hashes and reports. It cannot mount,
     * unmount, install or delete, and that is not enforced by a check inside the body — it is a
     * property of the lego having no such input and no such output in [LcncContracts]. A surface
     * whose capability is its declaration cannot be talked into doing something else; the worst a
     * wrong `module` param can produce is a row saying that module is not installed.
     */
    fun modules() = LcncNodeRunner { node, _ ->
        val only = node.params["module"]?.takeIf { it.isNotBlank() }
        val names = borg.trikeshed.graal.subvm.GuestModules.installed()
            .let { all -> if (only == null) all else all.filter { it == only } }
        val mounted = borg.trikeshed.graal.subvm.GuestModules.mounted().toSet()
        val rows = names.map { m ->
            val manifest = borg.trikeshed.graal.subvm.GuestModules.manifest(m)
            val jars = borg.trikeshed.graal.subvm.GuestModules.jars(m)
            val hasClasses = borg.trikeshed.graal.subvm.GuestModules.classesDir(m) != null
            // Verification hashes real bytes, so it is opt-in per call rather than on by default:
            // an audit of a 472MB module should be asked for, not incurred by listing.
            val verify = if (node.params["verify"] == "true") borg.trikeshed.graal.subvm.GuestModules.verify(m) else null
            buildString {
                append("{\"module\":\"").append(m).append("\"")
                append(",\"mounted\":").append(m in mounted)
                append(",\"classes\":").append(hasClasses)
                append(",\"jars\":").append(jars.size)
                append(",\"bytes\":").append(jars.sumOf { it.length() })
                append(",\"declared\":").append(manifest.declared.size)
                append(",\"manifest\":").append(manifest.entries.isNotEmpty())
                if (verify != null) {
                    append(",\"verified\":").append(verify.ok)
                    append(",\"checked\":").append(verify.checked)
                    append(",\"problems\":[")
                    append(verify.problems.joinToString(",") { p -> "\"" + p.replace("\\", "\\\\").replace("\"", "\\\"") + "\"" })
                    append("]")
                }
                append("}")
            }
        }
        val root = borg.trikeshed.graal.subvm.GuestModules.root()?.absolutePath ?: ""
        val payload = "{\"root\":\"${root.replace("\\", "\\\\").replace("\"", "\\\"")}\"," +
            "\"closed\":${borg.trikeshed.graal.subvm.GuestModules.closed.isCompleted}," +
            "\"modules\":[${rows.joinToString(",")}]}"
        mapOf("modules" to payload, "count" to names.size)
    }

    // ── tika: extract text + metadata from world-seeded files ─────────

    fun tika(host: borg.trikeshed.vm.VmHost) = boundLcnc(VmHostKey(host)) { service, node, inputs ->
        val facet = facetOf(node, default = "JVM")
        val files = inputStrings(node, inputs, key = "files")
            .ifEmpty { inputStrings(node, inputs, key = "text").let { if (it.isEmpty()) emptyList() else listOf("<text>") } }
        val script = buildString {
            appendLine("tika = Java.type('org.apache.tika.Tika')")
            for (f in files) appendLine("print(tika.parseToString(java.nio.file.Paths.get('/workspace/$f')))")
        }
        evalInVm(service.value, node, facet, script, inputs)
    }

    // ── corenlp: Stanford pipeline over a text lane ────────────────────

    fun corenlp(host: borg.trikeshed.vm.VmHost) = boundLcnc(VmHostKey(host)) { service, node, inputs ->
        val facet = facetOf(node, default = "JVM")
        val text = inputStrings(node, inputs, key = "text").joinToString("\n")
            .ifEmpty { node.params["text"] ?: "" }
        val annotators = node.params["annotators"] ?: "tokenize,ssplit,pos,lemma,depparse"
        val script = buildString {
            // GraalJS (not Groovy): Java.type for class literals, JSON.stringify for output.
            // Text rides as a global to avoid any quoting/escaping hazards.
            appendLine("var Properties = Java.type('java.util.Properties')")
            appendLine("var CoreNLP = Java.type('edu.stanford.nlp.pipeline.StanfordCoreNLP')")
            appendLine("var CoreDocument = Java.type('edu.stanford.nlp.pipeline.CoreDocument')")
            appendLine("var props = new Properties()")
            appendLine("props.setProperty('annotators', '${annotators.replace("'", "\\'")}')")
            appendLine("var pipeline = new CoreNLP(props)")
            appendLine("var doc = new CoreDocument(GUEST_TEXT)")
            appendLine("pipeline.annotate(doc)")
            appendLine("var out = []")
            appendLine("for (var i = 0; i < doc.tokens().size(); i++) {")
            appendLine("  var t = doc.tokens().get(i)")
            appendLine("  out.push(t.word() + '\\t' + t.tag() + '\\t' + t.lemma())")
            appendLine("}")
            // The joined payload is the eval VALUE (Teleported.Str) — print()
            // stays only as a human-readable terminal trace.
            appendLine("var RESULT = out.join('\\n')")
            appendLine("print(RESULT)")
            appendLine("RESULT")
        }
        evalInVmText(service.value, node, facet, script, text, inputs, defaultModule = "corenlp")
    }

    // ── corenlp.extract: NER + dependency + sentiment per sentence ───
    // Extends corenlp() to walk doc.sentences() and emit structured
    // JSON instead of flat token/tag/lemma lines.  The annotators string
    // defaults to include ner; sentiment is opt-in (param "sentiment"=true).

    fun corenlpExtract(host: borg.trikeshed.vm.VmHost) = boundLcnc(VmHostKey(host)) { service, node, inputs ->
        val facet = facetOf(node, default = "JVM")
        val text = inputStrings(node, inputs, key = "text").joinToString("\n")
            .ifEmpty { node.params["text"] ?: "" }
        val annotators = node.params["annotators"] ?: "tokenize,ssplit,pos,lemma,depparse,ner"
        val withSentiment = node.params["sentiment"] == "true"
        val effectiveAnnotators = if (withSentiment && !annotators.contains("sentiment")) {
            "$annotators,sentiment"
        } else annotators
        val script = buildString {
            // GraalJS: bare Java.type + plain object literals + JSON.stringify.
            // NER span begin/end annotations are CHAR offsets in CoreNLP; token
            // indexing is 1-based, so spans are recovered from the token list
            // rather than the (absent on CoreToken) begin/end annotations.
            appendLine("var Properties = Java.type('java.util.Properties')")
            appendLine("var CoreNLP = Java.type('edu.stanford.nlp.pipeline.StanfordCoreNLP')")
            appendLine("var CoreDocument = Java.type('edu.stanford.nlp.pipeline.CoreDocument')")
            appendLine("var CoreAnnotations = Java.type('edu.stanford.nlp.ling.CoreAnnotations')")
            appendLine("var props = new Properties()")
            appendLine("props.setProperty('annotators', '${effectiveAnnotators.replace("'", "\\'")}')")
            appendLine("var pipeline = new CoreNLP(props)")
            appendLine("var doc = new CoreDocument(GUEST_TEXT)")
            appendLine("pipeline.annotate(doc)")
            appendLine("var results = []")
            appendLine("for (var si = 0; si < doc.sentences().size(); si++) {")
            appendLine("  var sent = doc.sentences().get(si)")
            appendLine("  // CoreSentence typed accessors (not .get(annotation)): tokens(),")
            appendLine("  // dependencyParse(), sentiment() — direct, no annotation classes.")
            appendLine("  var tokens = []")
            appendLine("  var n = sent.tokens().size()")
            appendLine("  for (var i = 0; i < n; i++) {")
            appendLine("    var t = sent.tokens().get(i)")
            // charBegin/charEnd are UTF-16 char offsets into the source text
            // (CoreLabel.beginPosition/endPosition), distinct from and additive
            // to the existing 1-based token `index`.
            appendLine("    var tok = { word: t.word(), tag: t.tag(), lemma: t.lemma(), index: t.index(), charBegin: t.beginPosition(), charEnd: t.endPosition() }")
            appendLine("    var ner = t.ner()")
            appendLine("    if (ner !== null && ner !== 'O') tok.ner = ner")
            appendLine("    tokens.push(tok)")
            appendLine("  }")
            appendLine("  var deps = []")
            appendLine("  try {")
            appendLine("    var graph = sent.dependencyParse()")
            // Root edges are synthetic in CoreNLP's own typed-dependency notation:
            // govIndex 0 stands for the sentence root, mirroring CoreNlpRuntime's
            // NlpDependency(0, rootIndex, "root").
            appendLine("    var rootIter = graph.getRoots().iterator()")
            appendLine("    var roots = []")
            appendLine("    while (rootIter.hasNext()) { roots.push(rootIter.next()) }")
            appendLine("    roots.sort(function (a, b) { return a.index() - b.index() })")
            appendLine("    for (var ri = 0; ri < roots.length; ri++) {")
            appendLine("      deps.push({ gov: 'ROOT', dep: roots[ri].word(), rel: 'root', govIndex: 0, depIndex: roots[ri].index() })")
            appendLine("    }")
            appendLine("    var edges = graph.edgeListSorted()")
            appendLine("    for (var e = 0; e < edges.size(); e++) {")
            appendLine("      var edge = edges.get(e)")
            // govIndex/depIndex are the same 1-based sentence-token indices as
            // tokens[].index — indexed endpoints alongside the existing gov/dep
            // word strings, not a replacement for them.
            appendLine("      deps.push({ gov: edge.getGovernor().word(), dep: edge.getDependent().word(), rel: String(edge.getRelation()), govIndex: edge.getGovernor().index(), depIndex: edge.getDependent().index() })")
            appendLine("    }")
            appendLine("  } catch (depEx) { /* depparse not in the annotator set */ }")
            appendLine("  var sentObj = { text: String(sent.text()), tokens: tokens, deps: deps }")
            appendLine("  if ('$withSentiment' === 'true') {")
            appendLine("    try { sentObj.sentiment = String(sent.sentiment()) } catch (sEx) { }")
            appendLine("  }")
            appendLine("  // NER spans: contiguous runs of the same non-O tag over the 1-based tokens")
            appendLine("  var entities = []")
            appendLine("  var run = null")
            appendLine("  for (var i = 0; i < n; i++) {")
            appendLine("    var ner = tokens[i].ner || null")
            appendLine("    if (ner !== null && run !== null && run.ner === ner) { run.end = i + 1; }")
            appendLine("    else if (ner !== null) { if (run !== null) entities.push(run); run = { text: tokens[i].word, ner: ner, begin: i + 1, end: i + 1 }; }")
            appendLine("    else if (run !== null) { entities.push(run); run = null; }")
            appendLine("  }")
            appendLine("  if (run !== null) entities.push(run)")
            appendLine("  for (var r = 0; r < entities.length; r++) {")
            appendLine("    var words = []")
            appendLine("    for (var w = entities[r].begin - 1; w < entities[r].end; w++) words.push(tokens[w].word)")
            appendLine("    entities[r].text = words.join(' ')")
            // Entity spans are token-indexed (begin/end, 1-based inclusive,
            // unchanged); charBegin/charEnd add the UTF-16 offsets of the same
            // span, recovered from the run's first/last token like `text` is.
            appendLine("    entities[r].charBegin = tokens[entities[r].begin - 1].charBegin")
            appendLine("    entities[r].charEnd = tokens[entities[r].end - 1].charEnd")
            appendLine("  }")
            appendLine("  if (entities.length > 0) sentObj.entities = entities")
            appendLine("  results.push(sentObj)")
            appendLine("}")
            appendLine("var RESULT = JSON.stringify(results)")
            appendLine("print(RESULT)")
            appendLine("RESULT")
        }
        val result = evalInVmText(service.value, node, facet, script, text, inputs, defaultModule = "corenlp")
        // LcncContracts declares `sentences` (json) as this lego's output; the
        // guest eval only hands back the joined text/metadata (evalInVmText's
        // shared shape), so the promised port has to be parsed out of it here
        // rather than silently staying absent from scope.out wiring. A parse
        // failure is a real fault, not an empty/omitted `sentences` value.
        val raw = result["text"] as? String
            ?: throw IllegalStateException("vm lego '${node.id}': corenlp.extract produced no text output to parse 'sentences' from")
        val sentences = runCatching { reify(raw) }.getOrNull() as? List<*>
            ?: throw IllegalStateException("vm lego '${node.id}': corenlp.extract output was not a JSON array of sentences: $raw")
        result + ("sentences" to sentences)
    }

    // ── camel: route DSL over the lego's params ─────────────────────────

    fun camel(host: borg.trikeshed.vm.VmHost) = boundLcnc(VmHostKey(host)) { service, node, inputs ->
        val routeParam = (node.params["in:route"] ?: node.params["route"])?.takeIf(String::isNotBlank)
        val authoring = node.params["authoring"] ?: "declared"
        require(authoring in listOf("declared", "native-dsl")) { "Unknown Camel authoring mode '$authoring'" }
        val source = node.params["source"]
        if (authoring == "native-dsl") {
            require(!source.isNullOrBlank()) { "Native Camel source must be nonblank; no route fallback is executed" }
            require(routeParam == null && "route" !in inputs && "route?" !in inputs) { "Camel cannot use both source and a route plan" }
            require(VmRuntimeNodes.trust(node, inputs) == VmTrust.OWN) { "Native Camel source requires OWN trust; host code is not sandboxed" }
            val language = VmLanguage.of(node.params["language"].orEmpty())
            require(language in setOf(VmLanguage.JAVA, VmLanguage.GROOVY)) { "Native Camel source supports Java and Groovy DSL" }
            val budget = VmRuntimeNodes.budget(node, inputs)
            require(budget.statements == 0L && budget.wallMillis == 0L && budget.calls == 0L) {
                "Native Camel source has no statement, wall-clock or VM call-count enforcement"
            }
            require(VmRuntimeNodes.value(node, inputs, "keep") in listOf(null, "", "false", false) &&
                VmRuntimeNodes.value(node, inputs, "world") in listOf(null, "") &&
                VmRuntimeNodes.value(node, inputs, "vmId") in listOf(null, "")) {
                "Native Camel source owns one context; keep, world and vmId are not supported"
            }
            val input = VmRuntimeNodes.value(node, inputs, "messages")?.let { vmLanguageValue(it).languageValue() }
            val body = if ("messages" in inputs || "messages?" in inputs) jsonOf(input) else node.params["body"].orEmpty()
            currentCoroutineContext().ensureActive()
            val receipt = borg.trikeshed.graal.subvm.CamelRuntime.executeNative(requireNotNull(language), "lcnc:${UUID.randomUUID()}", source,
                node.params["from"] ?: "direct:lcnc", input, borg.trikeshed.graal.subvm.CamelRuntime.Request(body),
                node.params["module"]?.takeIf(String::isNotBlank) ?: CamelLinkage.SPINE,
                CamelLinkage.Reach.valueOf(node.params["reach"]?.uppercase() ?: "LOCAL"))
            currentCoroutineContext().ensureActive()
            return@boundLcnc mapOf("routed" to receipt["reply"], "ok" to true, "error" to "", "receipt" to receipt, "text" to jsonOf(receipt))
        }
        require(source.isNullOrBlank()) { "Camel source requires authoring=native-dsl" }
        if (routeParam != null || "route" in inputs || "route?" in inputs) {
            val authored = if ("route" in inputs || "route?" in inputs)
                VmRuntimeNodes.value(node, inputs, "route") else reifyStrict(requireNotNull(routeParam))
            require(VmRuntimeNodes.trust(node, inputs) == VmTrust.OWN) {
                "Camel executes host effects; a route requires OWN trust, not a sandbox claim"
            }
            require(VmRuntimeNodes.value(node, inputs, "keep") in listOf(null, "", "false", false) &&
                VmRuntimeNodes.value(node, inputs, "world") in listOf(null, "") &&
                VmRuntimeNodes.value(node, inputs, "vmId") in listOf(null, "")) {
                "An authored Camel route owns one context; keep, world and vmId are not supported"
            }
            val plan = CamelRoutePlan.parse(authored)
            val module = node.params["module"]?.takeIf(String::isNotBlank) ?: CamelLinkage.SPINE
            val reach = CamelLinkage.Reach.valueOf(node.params["reach"]?.uppercase() ?: "LOCAL")
            val hasMessages = "messages" in inputs || "messages?" in inputs
            val body = if (hasMessages) jsonOf(vmLanguageValue(VmRuntimeNodes.value(node, inputs, "messages")).languageValue())
                else node.params["body"]?.takeIf(String::isNotEmpty)
            currentCoroutineContext().ensureActive()
            val receipt = borg.trikeshed.graal.subvm.CamelRuntime.execute(
                "lcnc:${UUID.randomUUID()}", plan,
                body?.let { borg.trikeshed.graal.subvm.CamelRuntime.Request(it) }, module, reach)
            currentCoroutineContext().ensureActive()
            return@boundLcnc mapOf("routed" to (receipt["reply"] ?: ""), "ok" to true,
                "error" to "", "receipt" to receipt, "text" to jsonOf(receipt))
        }
        val facet = facetOf(node, default = "JVM")
        val from = node.params["from"] ?: "direct:lcnc"
        val to = node.params["to"] ?: "log:lcnc"
        // LOCAL LINKAGES ONLY, refused HERE rather than inside the guest.
        //
        // `from` and `to` are the entire reachable surface of this route — the EIPs between
        // them only move an Exchange around inside one context. Checking the two declared
        // URIs therefore checks everything the route can touch, which is the same argument
        // `vm.modules` makes about its own capability being its declaration.
        //
        // At the boundary, for the reason CamelLegoExecutionTest already asserts about an
        // absent module: a refusal the lego states is an error an operator can read, while
        // the same refusal taken inside GraalJS is a stack trace about a class it could not
        // resolve. Egress policy also cannot be enforced once Camel has opened its own
        // socket on its own thread pool — the only place to decline is before the eval.
        // The mount chain decides what is even nameable: with only the spine, `smtp:` has no
        // MailComponent to resolve, so provision answers the question before policy does.
        // `reach` is the second, narrower gate — see CamelLinkage.
        val moduleName = node.params["module"]?.takeIf { it.isNotBlank() }
            ?: borg.trikeshed.lcnc.CamelLinkage.SPINE
        val mountedChain = borg.trikeshed.graal.subvm.GuestModules.chain(moduleName)
        val reach = when (node.params["reach"]?.trim()?.uppercase()) {
            "DEPARTMENT" -> borg.trikeshed.lcnc.CamelLinkage.Reach.DEPARTMENT
            else -> borg.trikeshed.lcnc.CamelLinkage.Reach.LOCAL
        }
        // A module that is not installed AT ALL is a different fault from a scheme that is not
        // provisioned, and it has a better error waiting for it downstream ("not installed",
        // naming the install command). Running the provision gate first would answer a typo in
        // `module` with "mount 'camel'", which is confusing and points at the wrong thing.
        val gateApplies = borg.trikeshed.graal.subvm.GuestModules.isInstalled(moduleName)
        for ((port, uri) in if (gateApplies) listOf("from" to from, "to" to to) else emptyList()) {
            borg.trikeshed.lcnc.CamelLinkage.refusal(uri, reach, mountedChain)?.let { why ->
                return@boundLcnc mapOf(
                    "routed" to "",
                    "ok" to false,
                    "error" to "vm.camel refuses $port='$uri': $why",
                )
            }
        }
        // Body to dispatch through the route. Without one the lego only proves the context
        // starts; with one it proves the route actually carries a message end to end.
        val hasMessages = "messages" in inputs || "messages?" in inputs
        val body = if (hasMessages) jsonOf(vmLanguageValue(VmRuntimeNodes.value(node, inputs, "messages")).languageValue())
            else inputStrings(node, inputs, key = "body").joinToString("\n")
                .ifEmpty { node.params["body"] ?: "" }
        fun q(s: String) = jsonOf(s)
        val script = buildString {
            // GraalJS, not Groovy. The previous body was Java/Groovy source — bare `new
            // org.apache.camel...` and an anonymous `RouteBuilder(){ void configure() }` subclass —
            // which GraalJS cannot parse, so this lego could never have run even with Camel present.
            //
            // The corenlp legos above were converted out of that same Groovy shape by jnorthrup in
            // `wip` 49c94c868 (144+/64- here), which is where the "GraalJS (not Groovy)" note on
            // vm.corenlp comes from and why that lego runs. Camel was the one left behind — it had
            // no dependency to run against, so nothing forced the issue.
            // RouteBuilder is abstract and JS cannot subclass it, but Camel 4 exposes the static
            // RouteBuilder.addRoutes(CamelContext, LambdaRouteBuilder); LambdaRouteBuilder is a
            // functional interface, and GraalJS coerces a plain JS function to one.
            appendLine("var DefaultCamelContext = Java.type('org.apache.camel.impl.DefaultCamelContext')")
            appendLine("var RouteBuilder = Java.type('org.apache.camel.builder.RouteBuilder')")
            appendLine("var ctx = new DefaultCamelContext()")
            appendLine("var tpl = null")
            appendLine("var reply = null")
            appendLine("var RESULT")
            appendLine("try {")
            appendLine("RouteBuilder.addRoutes(ctx, function (rb) { rb.from(${q(from)}).to(${q(to)}) })")
            appendLine("ctx.start()")
            if (hasMessages || body.isNotEmpty()) {
                // GUEST_TEXT carries the body as a JSON-quoted literal (see evalInVmText).
                appendLine("tpl = ctx.createProducerTemplate()")
                appendLine("reply = String(tpl.requestBody(${q(from)}, GUEST_TEXT, Java.type('java.lang.String').class))")
            }
            appendLine("var names = []")
            appendLine("for (var i = 0; i < ctx.getRoutes().size(); i++) names.push(ctx.getRoutes().get(i).getId())")
            appendLine("RESULT = JSON.stringify({ status: String(ctx.getStatus()), routes: names, from: ${q(from)}, to: ${q(to)}, reply: reply })")
            appendLine("} finally { try { if (tpl !== null) tpl.stop() } finally { ctx.stop() } }")
            appendLine("print(RESULT)")
            appendLine("RESULT")
        }
        val result = evalInVmText(service.value, node, facet, script, body, inputs, defaultModule = "camel")
        val receipt = requireNotNull(reifyStrict(result.getValue("text") as String) as? Map<*, *>) {
            "Camel did not return a route receipt"
        }
        result + mapOf("routed" to (receipt["reply"] ?: ""), "ok" to true, "error" to "", "receipt" to receipt)
    }

    // ── graalce: any Graal language, source spelled inline ──────────────

    fun graalce(host: borg.trikeshed.vm.VmHost) = boundLcnc(VmHostKey(host)) { service, node, inputs ->
        val facet = facetOf(node, default = "GRAAL_JS")
        val source = VmRuntimeNodes.string(node, inputs, "source", allowBlank = true)
        evalInVm(service.value, node, facet, source, inputs)
    }

    /** A typed function invocation owns its guest; reusable workspaces use the vm.* lifecycle nodes. */
    fun polyglot(host: VmHost) = boundLcnc(VmHostKey(host), object : LcncNodeRunner {
        override suspend fun sourceDebugging(node: LcncNode, inputs: Map<String, Any?>): Boolean {
            // Invalid selectors remain inspectable at the node hold; execute reports their error.
            val spec = try {
                val language = VmLanguage.of(VmRuntimeNodes.string(node, inputs, "language", "js")) ?: return false
                if (language.runtime != VmLanguageRuntime.TRUFFLE) return false
                VmSpec(node.id, requireNotNull(language.facet), trust = VmRuntimeNodes.trust(node, inputs), module = language.module)
            } catch (_: IllegalArgumentException) { return false }
            return VmHostKey.require().sourceDebugging(spec)
        }

        override suspend fun execute(node: LcncNode, inputs: Map<String, Any?>): Map<String, Any?> =
            polyglot(VmHostKey.require(), node, inputs)
    })

    private suspend fun polyglot(host: VmHost, node: LcncNode, inputs: Map<String, Any?>): Map<String, Any?> {
        require(listOf("vmId", "keep").none { key ->
            key in inputs || "$key?" in inputs || key in node.params || "in:$key" in node.params
        }) { "$POLYGLOT owns a temporary guest; vmId and keep are not supported" }
        val language = requireNotNull(VmLanguage.of(VmRuntimeNodes.string(node, inputs, "language", "js"))) {
            "Unknown VM language"
        }
        VmLanguages.require(host, language)
        val program = VmLanguageProgram(language, VmRuntimeNodes.string(node, inputs, "source"),
            VmValueKind.of(VmRuntimeNodes.string(node, inputs, "inputKind", "JSON")),
            VmValueKind.of(VmRuntimeNodes.string(node, inputs, "outputKind", "JSON")))
        val trust = VmRuntimeNodes.trust(node, inputs)
        val budget = VmRuntimeNodes.budget(node, inputs)
        language.validate(trust, budget)
        program.declaration(budget, node.id)
        val raw = if ("input" in inputs || "input?" in inputs) VmRuntimeNodes.value(node, inputs, "input")
            else (node.params["in:input"] ?: node.params["input"])?.let(::reifyStrict)
        val input = program.inputKind.validate(vmLanguageValue(raw))
        val spec = VmSpec("lcnc:${UUID.randomUUID()}", requireNotNull(language.facet),
            trust = trust, budget = budget, module = language.module)
        currentCoroutineContext().ensureActive()
        var failure: Throwable? = null
        var handle: VmHandle? = null
        val invocation = currentCoroutineContext()[LcncInvocationLedger.Invocation]
        return try {
            val guest = host.spawn(spec).also { handle = it }
            val result = program.evaluate(guest, input, node.id, budget, currentCoroutineContext()[borg.trikeshed.vm.VmDebugRequest])
            currentCoroutineContext().ensureActive()
            mapOf("value" to result.languageValue(), "text" to result.canonical(),
                "language" to language.id, "facet" to guest.facet.id, "vmId" to spec.id, "cid" to result.cid.value)
        } catch (t: Throwable) {
            failure = t
            currentCoroutineContext().ensureActive()
            throw t
        } finally {
            handle?.let { guest -> invocation?.runtime {
                val stats = guest.stats()
                mapOf("vmId" to spec.id, "language" to language.id, "facet" to guest.facet.id,
                    "tier" to guest.tier, "capture" to "before-release",
                    "sourceScope" to if (language.facet == borg.trikeshed.pointcut.VmFacet.JVM) "graal-wrapper" else "guest-function",
                    "stats" to mapOf("evals" to stats.evals, "calls" to stats.calls, "hostCalls" to stats.hostCalls,
                        "refutations" to stats.refutations, "interrupted" to stats.interrupted),
                    "pointcuts" to guest.pointcuts()?.toMap())
            } }
            try { host.revoke(spec.id, "lcnc invocation closed") }
            catch (cleanup: Throwable) {
                val original = failure
                if (original == null) throw cleanup
                if (cleanup !== original) original.addSuppressed(cleanup)
            }
        }
    }

    // ── shared eval path ────────────────────────────────────────────────

    /**
     * Eval with an untrusted-length TEXT payload bound as the guest global
     * `GUEST_TEXT` (a `var` statement prepended to the source) instead of
     * string-literal-splicing it into the script. Documents contain quotes,
     * newlines, backslashes — splicing them into generated source is how the
     * old corenlp scripts broke; binding as a global leaves the script static
     * and the data as data.
     */
    private suspend fun evalInVmText(
        host: borg.trikeshed.vm.VmHost,
        node: LcncNode,
        facetName: String,
        script: String,
        text: String,
        inputs: Map<String, Any?>,
        defaultModule: String? = null,
    ): Map<String, Any?> {
        // JSON.stringify of the text is the one safe JS string literal form;
        // GraalJS parses it with no further interpretation.
        val literal = jsonOf(text)
        return evalInVm(host, node, facetName, "var GUEST_TEXT = $literal;\n$script", inputs, defaultModule)
    }

    private suspend fun evalInVm(
        host: borg.trikeshed.vm.VmHost,
        node: LcncNode,
        facetName: String,
        source: String,
        inputs: Map<String, Any?>,
        defaultModule: String? = null,
    ): Map<String, Any?> {
        val facet = borg.trikeshed.vm.vmFacetOf(facetName)
            ?: throw IllegalArgumentException("vm lego '${node.id}': unknown facet '$facetName' (use JVM, GRAAL_JS, …)")
        val world = VmRuntimeNodes.strings(node, inputs, "world")
        // `module` names the guest classpath this lego needs (utils/subvm/<module>). An explicit
        // param wins so a canvas can point a lego at a different build of the same library.
        val module = node.params["module"]?.takeIf { it.isNotBlank() } ?: defaultModule
        if (module != null && !borg.trikeshed.graal.subvm.GuestModules.isInstalled(module)) {
            // Fail HERE, with the command that fixes it, rather than as a ClassNotFoundException
            // thrown from inside a guest script where the cause is invisible.
            throw IllegalStateException(
                "vm lego '${node.id}': guest module '$module' is not installed. " +
                    "Run: ./gradlew -p utils/subvm install${module.replaceFirstChar { it.uppercase() }}" +
                    (borg.trikeshed.graal.subvm.GuestModules.root()?.let { " (modules root: $it)" }
                        ?: " (no utils/subvm directory found from ${System.getProperty("user.dir")})"),
            )
        }
        val keep = node.params["keep"]?.let {
            requireNotNull(it.toBooleanStrictOrNull()) { "keep must be true or false" }
        } ?: false
        val id = VmRuntimeNodes.value(node, inputs, "vmId")?.let {
            VmRuntimeNodes.id(VmRuntimeNodes.string(node, inputs, "vmId"))
        } ?: if (keep) VmRuntimeNodes.id("lcnc:${node.id}") else "lcnc:${UUID.randomUUID()}"
        val trust = VmRuntimeNodes.trust(node, inputs)
        require(world.isEmpty() || trust == borg.trikeshed.vm.VmTrust.OWN) { "VM world requires OWN trust" }
        require(module == null || trust == borg.trikeshed.vm.VmTrust.OWN) { "VM module requires OWN trust" }
        val spec = borg.trikeshed.vm.VmSpec(
            id = id,
            facet = facet,
            trust = trust,
            budget = VmRuntimeNodes.budget(node, inputs),
            world = world,
            module = module,
        )
        currentCoroutineContext().ensureActive()
        val existing = host.get(spec.id)
        require(existing == null || existing.facet == facet) { "VM '${spec.id}' has a different facet" }
        check(existing == null || existing.isAlive) { "VM '${spec.id}' is not alive" }
        val handle = existing ?: host.spawn(spec)
        var failure: Throwable? = null
        var succeeded = false
        return try {
            val tele = handle.eval(source, node.id)
            currentCoroutineContext().ensureActive()
            // The eval VALUE is the lego's structured result — the scripts end
            // with the payload expression (print() is only a human trace on the
            // VM's xterm, lossy past 28 rows). Terminal text is the FALLBACK for
            // legacy scripts whose last expression is null.
            val terminalText = runCatching {
                val session = hostTerminalSession(host, spec.id) ?: return@runCatching null
                // Screen (28 rows) + scrollback (up to 200): a token dump longer
                // than the screen scrolls, so the head of the output lives in
                // scrollback. Reconstruct print order scrollback→screen.
                val term = session.panel.terminal
                val snap = term.snapshot(500)
                val sb = (0 until snap.scrollback.size).joinToString("\n") { r ->
                    val line = snap.scrollback[r]
                    (0 until line.size).joinToString("") { cIdx -> line[cIdx].text }
                }
                sb + "\n" + term.plainText()
            }.getOrNull()
            val output = mapOf(
                "facet" to facet.id,
                "vmId" to spec.id,
                "cid" to tele.cid.value,
                "text" to when {
                    tele is Teleported.Str -> tele.v
                    tele is Teleported.Bytes -> tele.v.decodeToString()
                    else -> extractPrintedOutput(terminalText, spec.id) ?: tele.toString()
                },
                "inputs" to inputs.keys.toList(),
            )
            succeeded = true
            output
        } catch (t: Throwable) {
            failure = t
            throw t
        } finally {
            if (existing == null && (!keep || !succeeded)) {
                try {
                    host.revoke(spec.id, "lcnc invocation closed")
                } catch (cleanup: Throwable) {
                    val original = failure
                    if (original == null) throw cleanup
                    if (cleanup !== original) original.addSuppressed(cleanup)
                }
            }
        }
    }

    /** The terminal session a spawn opened for this vm id — where guest print() lands. */
    private fun hostTerminalSession(host: borg.trikeshed.vm.VmHost, vmId: String): borg.trikeshed.vm.VmTerminalSession? {
        val terminals = (host as? borg.trikeshed.vm.HypervisorVmHost)?.terminals ?: return null
        return terminals[vmId]
    }

    /**
     * Peel the printed output off the terminal screen: everything after the
     * last line that looks like the session's echo of our eval (the prompt /
     * banner prefaces it). When nothing printed, null → fall back to the
     * eval's Teleported value.
     */
    private fun extractPrintedOutput(terminalText: String?, vmId: String): String? {
        if (terminalText.isNullOrBlank()) return null
        val lines = terminalText.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return null
        // The banner line contains the vm id ("lcnc:n1 · js · in-process").
        val bannerIdx = lines.indexOfFirst { it.contains(vmId) }
        val body = if (bannerIdx >= 0) lines.drop(bannerIdx + 1) else lines
        val cleaned = body
            .filterNot { it.startsWith("lcnc:") }
            .joinToString("\n")
            .trim()
        return cleaned.ifEmpty { null }
    }

    // ── param/input spelling helpers ────────────────────────────────────

    private fun facetOf(node: LcncNode, default: String): String = node.params["facet"] ?: default

    /** Input lane: wire-carried values win; the `in:`-prefixed param is the fallback spelling. */
    private fun inputStrings(node: LcncNode, inputs: Map<String, Any?>, key: String): List<String> {
        if (key == "files" || key == "world") return VmRuntimeNodes.strings(node, inputs, key)
        return when (val value = VmRuntimeNodes.value(node, inputs, key)) {
            null -> emptyList()
            is String -> listOf(value)
            is List<*> -> value.map { require(it is String) { "$key must contain text" }; it }
            else -> throw IllegalArgumentException("$key must be text or a list of text")
        }
    }
}
