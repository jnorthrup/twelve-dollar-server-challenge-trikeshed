package borg.trikeshed.module

import borg.trikeshed.couch.Couch
import borg.trikeshed.dag.ReteNetwork
import borg.trikeshed.dag.ReteProductionRegistry
import borg.trikeshed.graal.ConfixBlackboard
import borg.trikeshed.job.CasStore
import borg.trikeshed.narsese.BeliefBagElement
import borg.trikeshed.narsese.TurnReviewElement
import borg.trikeshed.util.oroboros.CouchAttachmentGateway
import kotlinx.coroutines.CoroutineScope
import java.io.File
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

/**
 * ForgeModule — oroboros as a HOST for dynamic modules. A module is a unit of
 * daemon capability with a no-arg PROXY CONSTRUCTOR (so it can be instantiated
 * reflectively by FQCN — including classes that arrived via hotswapFeed after
 * boot) that assembles its own CCEK elements against a [ModuleContext] and
 * hands back an opaque [ModuleHandle].
 *
 * The god-object prohibition (PRELOAD "Reactor decomposition rules") is the
 * point: the server grows a route REGISTRY consultation, never module logic.
 * Module upgrades are detach → attach with a fresh instance — safe exactly when
 * the module's state is WAL-rebuildable, which is the module author's contract.
 */
interface ForgeModule {
    val id: String

    /** Suspend: modules replay WALs / open CCEK elements here. Claims made before a throw are rolled back by the supervisor. */
    suspend fun open(ctx: ModuleContext): ModuleHandle
}

/**
 * Everything a module may compose against. Nullable planes degrade gracefully:
 * a module MUST function (possibly reduced) when [beliefBag]/[turnReview] are
 * absent — coherence is garnish, never load-bearing.
 */
class ModuleContext(
    val couch: Couch,
    val rete: ReteNetwork,
    val productions: ReteProductionRegistry,
    val beliefBag: BeliefBagElement?,
    val turnReview: TurnReviewElement?,
    val blackboard: ConfixBlackboard,
    val casStore: CasStore,
    val attachments: CouchAttachmentGateway,
    val routes: ModuleRouteRegistry,
    /** SupervisorJob child of the daemon root — module coroutines die with the daemon, not vice versa. */
    val scope: CoroutineScope,
    /** Injected clock seam — modules never call wall-clock APIs directly (commonMain rule). */
    val clock: () -> Long,
    /** Module-owned state root (forge home). NEVER a worktree, NEVER /tmp. */
    val stateDir: File,
    /** HtxKey + mux reactor for provider calls. */
    val muxContext: CoroutineContext = EmptyCoroutineContext,
    /**
     * P1: live CCEK control-plane binding. When present, whole LCNC program runs
     * launch as structured CCEK assemblies; null preserves reduced/test contexts.
     */
    val ccekBinding: borg.trikeshed.lcnc.ccek.CcekReactorBinding? = null,
    /**
     * Modules publish their LCNC runner registries here (additive); the host composes
     * them — webhook node dispatch resolves `program/node/port` against this map.
     */
    val lcncRunners: MutableMap<String, borg.trikeshed.lcnc.LcncNodeRunner> = linkedMapOf(),
    /**
     * Stored-program resolver for whole-program runs and scope recursion (spec
     * §3.1): production wiring is `panels/<name>` attachments ∪ the offered
     * [borg.trikeshed.lcnc.LcncPresets]; the default resolves presets only, so
     * a bare context still runs them.
     */
    val programLoader: suspend (String) -> borg.trikeshed.lcnc.LcncProgram? = { name ->
        borg.trikeshed.lcnc.LcncPresets.all()[name]
            ?.let { borg.trikeshed.lcnc.LcncProgramConfix.fromJson(name, it) }
    },
    /**
     * The daemon's ONE KIF bank (the tuple plane every Rete fact projects into
     * and the LCNC vocabulary is told to). A module's [borg.trikeshed.lcnc.LcncPublisher]
     * must tell the same bank the daemon's publisher tells; null (tests, reduced
     * contexts) means each publisher keeps a private bank, as before.
     */
    val kifBank: borg.trikeshed.kif.KifKnowledgeBase? = null,
    /** The coding-agent lane (Forge genesis, Cut A): filled by the daemon after attach, read by the claim worker at claim time. */
    @Volatile var agentRuns: borg.trikeshed.lcnc.AgentRuns? = null,
    /** The daemon's live NARS Rete; document ingest registers parser/model terms here when present. */
    val narsRete: borg.trikeshed.narsese.CausalityReteElement? = null,
    /** Host-owned dense inspection; either primary revisions or an explicit projection, never a second writer. */
    val confixIsam: borg.trikeshed.couch.isam.ConfixIsamElement? = null,
) {
    /** Host-owned persistent Camel commands and publications; never closed by an LCNC invocation. */
    @Volatile var camelRoutes: borg.trikeshed.lcnc.CamelRouteElement? = null
    /** Shared document authority; the root owns its WAL and drain, modules only borrow it. */
    @Volatile var documentReview: borg.trikeshed.lcnc.CurationReview? = null

    private val councilCasesLock = Any()
    private var councilCasesStopped = false
    private val councilCasesRef = lazy { borg.trikeshed.lcnc.councilCaseRegistry(scope, casStore, couch) }

    /** Shared root-owned case registry. Modules borrow it and never close it on detach. */
    val councilCases: borg.trikeshed.lcnc.CouncilCaseRegistry get() = synchronized(councilCasesLock) {
        check(!councilCasesStopped) { "Council case owner stopped" }
        councilCasesRef.value
    }

    /** The root awaits admitted module work before draining this shared owner and its children. */
    suspend fun drainCouncilCases() {
        val owner = synchronized(councilCasesLock) {
            councilCasesStopped = true
            if (councilCasesRef.isInitialized()) councilCasesRef.value else null
        }
        owner?.drain()
    }
}

/** The grip the supervisor holds: describe for /api/modules, drain-then-close on detach. */
interface ModuleHandle {
    val id: String
    fun describe(): Map<String, Any?>
    suspend fun drain()
    suspend fun close()
}
