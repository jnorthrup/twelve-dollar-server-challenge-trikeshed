/*
 * Copyright (C) 2024-2026 TrikeShed
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package borg.trikeshed.sctp

import borg.trikeshed.lib.Series

class JvmLiburingFacadeSeam : LiburingFacadeSeam {
    override fun submitBatch(batch: Series<ByteArray>) {
        // Implementation stub for JVM
    }

    override fun completeBatch(): Int {
        // Implementation stub for JVM
        return 0
    }
}
