package borg.trikeshed.userspace

import borg.trikeshed.platform.loadPlatformHost
import java.nio.file.Files
import java.nio.file.Path

/**
 * Compile-time native-depth gate for the JVM actual.
 *
 * 0 = emulation only (POSIX-shaped JDK primitives servicing SQEs)
 * 1 = JNI bridge to the kernel ring (probe still validates ELF/ABI/NOP)
 * 2 = with no JNI module, the FFM ring (PanamauRing.kt): sockets and descriptors as SQEs, probe-confirmed
 *
 * The facade surface is byte-identical above either level; going more native
 * means raising this const, never adding a second API. The runtime probe
 * cannot exceed the level pinned here — the const is the ceiling.
 */
internal const val JVM_NATIVE_URING_LEVEL: Int = 2

/**
 * Discovery of the repo's JNI execution module for [requested], by default the process's (the trikeshed.uring.mode
 * property, else TRIKESHED_URING_MODE). No process or IO CLI bridge.
 */
fun discoverJvmUringBackend(entries: Int, requested: UringBackendMode? = null): UringBackendDiscovery {
    val mode = requested ?: UringBackendMode.parse(System.getProperty("trikeshed.uring.mode") ?: System.getenv("TRIKESHED_URING_MODE"))
    val discovery = probeJvmUringBackend(entries, mode)
    check(mode != UringBackendMode.NATIVE || discovery.backend != null) {
        "Native JVM io_uring required: ${discovery.report.description}"
    }
    return discovery
}

private fun probeJvmUringBackend(entries: Int, mode: UringBackendMode): UringBackendDiscovery {
    require(entries > 0)
    val host = loadPlatformHost().descriptor
    if (JVM_NATIVE_URING_LEVEL < 1 || mode == UringBackendMode.EMULATED) {
        return UringBackendDiscovery(UringProbeReport(host, UringProbeState.MODULE_ABSENT,
            UringProbePhase.DISCOVERY, null,
            if (mode == UringBackendMode.EMULATED) "TRIKESHED_URING_MODE=emulated requested; native setup bypassed"
            else "JVM_NATIVE_URING_LEVEL=$JVM_NATIVE_URING_LEVEL pins the actual to emulation"))
    }
    fun unavailable(state: UringProbeState, detail: String, module: String? = null,
                    phase: UringProbePhase = UringProbePhase.DISCOVERY, errno: Int? = null) =
        UringBackendDiscovery(UringProbeReport(host, state, phase, module, detail, errno))
    uringHostConstraint(host)?.let { return unavailable(it, "JNI io_uring requires a known Linux arm64 or x86_64 host") }
    var module: String? = null
    var phase = UringProbePhase.DISCOVERY
    try {
        val configured = System.getProperty("trikeshed.uring.library")?.takeIf { it.isNotBlank() }
        val candidate = if (configured != null) Path.of(configured).toAbsolutePath() else {
            val filename = System.mapLibraryName("trikeshed_uring")
            System.getProperty("java.library.path", "").split(java.io.File.pathSeparatorChar)
                .asSequence().filter { it.isNotBlank() }.map { Path.of(it, filename).toAbsolutePath() }
                .firstOrNull { Files.isRegularFile(it) }
        }
        module = candidate?.toString()
        if (candidate == null || !Files.exists(candidate)) {
            if (JVM_NATIVE_URING_LEVEL < 2)
                return unavailable(UringProbeState.MODULE_ABSENT, "No trikeshed_uring JNI module found", module)
            // Level 2: the FFM ring needs no module. It must set up here and confirm its operations by probe.
            val ffm = "ffm:io_uring"
            phase = UringProbePhase.SETUP
            val ring = try { openPanamaRing(entries) } catch (failure: PanamaRingException) {
                return unavailable(uringErrnoState(failure.errno), failure.message ?: "io_uring_setup failed", ffm, phase, failure.errno)
            }
            phase = UringProbePhase.OPERATIONS
            if (ring.features and PanamaRing.FEAT_EXT_ARG == 0) {
                ring.close()
                return unavailable(UringProbeState.KERNEL_UNSUPPORTED, "io_uring lacks IORING_FEAT_EXT_ARG (Linux 5.11)", ffm, phase)
            }
            val backend = PanamauChannelBackend(ring)
            return probeUringBackend(host, ffm, backend).also { if (it.backend == null) backend.close() }
        }
        val header = Files.newInputStream(candidate).use { it.readNBytes(20) }
        uringElfCompatibility(header, host.architecture)?.let {
            return unavailable(it, "JNI module ELF class, byte order or machine does not match ${host.architecture}", module)
        }
        phase = UringProbePhase.LOAD
        System.load(candidate.toString())
        if (JvmUring.abiVersion() != 6)
            return unavailable(UringProbeState.ABI_MISMATCH, "JNI bridge protocol must be version 6 (retained asynchronous batches, CQ reaping and cancellable readiness)", module, phase)
        phase = UringProbePhase.SETUP
        val handle = JvmUring.open(entries)
        if (handle <= 0L) {
            val errno = if (handle in -4095L..-1L) -handle.toInt() else null
            return unavailable(errno?.let(::uringErrnoState) ?: UringProbeState.PROBE_FAILED,
                "io_uring setup/operation probe returned $handle", module, phase, errno)
        }
        phase = UringProbePhase.OPERATIONS
        val backend = try { jvmNativeChannelBackend(handle) } catch (failure: Throwable) {
            try { JvmUring.close(handle) } catch (cleanup: Throwable) {
                return unavailable(UringProbeState.PROBE_FAILED,
                    "${failure.message}; module cleanup failed: ${cleanup.message}", module, phase)
            }
            throw failure
        }
        return probeUringBackend(host, candidate.toString(), backend)
    } catch (failure: SecurityException) {
        return unavailable(UringProbeState.RUNTIME_RESTRICTED, failure.message ?: "Runtime denied module access", module, phase)
    } catch (failure: UnsatisfiedLinkError) {
        return unavailable(UringProbeState.ABI_MISMATCH, failure.message ?: "JNI module or symbol is incompatible", module, phase)
    } catch (failure: LinkageError) {
        return unavailable(UringProbeState.ABI_MISMATCH, failure.message ?: "JNI linkage failed", module, phase)
    } catch (failure: Exception) {
        return unavailable(if (phase == UringProbePhase.DISCOVERY || phase == UringProbePhase.LOAD)
            UringProbeState.MODULE_LOAD_FAILED else UringProbeState.PROBE_FAILED,
            failure.message ?: failure.toString(), module, phase)
    }
}
