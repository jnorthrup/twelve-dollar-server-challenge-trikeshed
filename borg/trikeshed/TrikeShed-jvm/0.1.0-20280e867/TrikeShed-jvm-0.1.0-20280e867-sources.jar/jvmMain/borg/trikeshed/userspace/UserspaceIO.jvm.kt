package borg.trikeshed.userspace

import borg.trikeshed.lib.Series
import borg.trikeshed.lib.get
import borg.trikeshed.lib.j
import borg.trikeshed.lib.size
import borg.trikeshed.userspace.UringOp.Companion.UringSubmission
import borg.trikeshed.userspace.nio.ByteBuffer
import java.nio.channels.*
import java.nio.file.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** POSIX_FADV_WILLNEED / MADV_WILLNEED. The one advice this backend can actually act on. */
private const val ADVICE_WILLNEED = 3

internal val jvmUringOperations = UringOp.caps(
    UringOp.NOP, UringOp.OPENAT, UringOp.READ, UringOp.WRITE, UringOp.READ_FIXED, UringOp.WRITE_FIXED,
    UringOp.FSYNC, UringOp.FTRUNCATE, UringOp.CLOSE,
    // The socket half of the emulation: the vocabulary already names these, and a stream fd
    // reaches them through the same table a file does. SOCKET/BIND/LISTEN/ACCEPT settle
    // the lifecycle SQEs; their CQEs carry the new fd or 0/-errno like the kernel's.
    UringOp.SOCKET, UringOp.BIND, UringOp.LISTEN, UringOp.ACCEPT,
    UringOp.SEND, UringOp.RECV, UringOp.CONNECT, UringOp.SHUTDOWN,
    UringOp.POLL_ADD, UringOp.POLL_REMOVE, UringOp.ASYNC_CANCEL, UringOp.URING_CMD,
    // Mapping and the metadata syscalls. Every one of these was previously reached by calling
    // java.nio directly from wherever needed it -- which is the JVM creep: each call site grows
    // its own platform assumptions and the single vocabulary stops being the only way in.
    UringOp.STATX, UringOp.FALLOCATE,
    // Advisory, and answered rather than refused: the emulation must not differ from a native
    // ring in what it CAN do, only in how fast it does it.
    UringOp.FADVISE, UringOp.MADVISE,
    UringOp.UNLINKAT, UringOp.MKDIRAT, UringOp.RENAMEAT, UringOp.GETDENTS,
)

/** One descriptor record shared by FileImpl and submission execution. */
internal sealed interface JvmDescriptor {
    fun close()
    fun size(): Long
    fun isOpen(): Boolean
}

/**
 * A stream socket, addressed through the same table as a file.
 *
 * The point of the uring waist is that commonMain speaks ONE submission vocabulary and the
 * backend varies underneath -- a real ring on Linux, emulation elsewhere. That only holds if
 * every kind of fd is reachable through the same table, so a socket is a descriptor here rather
 * than a second mechanism beside it. READ/RECV and WRITE/SEND land on the same ops a file uses;
 * the descriptor decides what they mean.
 */
internal class JvmSocketDescriptor(val fd: Int) : JvmDescriptor {
    @Volatile private var open = true
    @Synchronized
    fun closeResult(): Int {
        if (!open) return -9
        open = false
        return JvmSocketSyscalls.close(fd)
    }
    override fun close() { closeResult() }
    override fun isOpen(): Boolean = open
    /** A stream has no size; -1 is what the file path returns for an unknown extent. */
    override fun size(): Long = -1L
}

internal class JvmChannelDescriptor(val channel: FileChannel) : JvmDescriptor {
    override fun close() = channel.close()
    override fun size(): Long = channel.size()
    override fun isOpen(): Boolean = channel.isOpen
}

internal object JvmFileTable {
    private val nextId = AtomicInteger(1 shl 20)
    private val files = ConcurrentHashMap<Int, JvmDescriptor>()
    fun register(descriptor: JvmDescriptor): Int = nextId.getAndIncrement().also { files[it] = descriptor }
    fun descriptor(fd: Int): JvmDescriptor? = files[fd]
    fun close(fd: Int): Int {
        val descriptor = files.remove(fd) ?: return -9
        if (descriptor is JvmSocketDescriptor) return descriptor.closeResult()
        return try { descriptor.close(); 0 } catch (failure: Exception) { jvmIoError(failure) }
    }
}

internal fun jvmIoError(failure: Exception): Int = when (failure) {
    is NoSuchFileException -> -2
    is AccessDeniedException, is SecurityException -> -13
    is FileAlreadyExistsException -> -17
    is java.net.BindException -> -98
    is java.net.ConnectException -> -111
    is java.net.NoRouteToHostException -> -113
    is java.net.SocketTimeoutException -> -110
    is ClosedChannelException, is NonReadableChannelException, is NonWritableChannelException -> -9
    is AlreadyBoundException -> -22
    is AlreadyConnectedException -> -106
    is ConnectionPendingException -> -114
    is NotYetConnectedException -> -107
    is UnresolvedAddressException -> -22
    is UnsupportedAddressTypeException -> -97
    is IllegalArgumentException -> -22
    is UnsupportedOperationException -> -95
    else -> -5
}

internal fun UringSubmission.path(): String {
    val bytes = requireNotNull(buffer)
    require(len > 0 && len <= bytes.remaining())
    return bytes.array().decodeToString(bytes.arrayOffset() + bytes.position(),
        bytes.arrayOffset() + bytes.position() + len, throwOnInvalidSequence = true).also {
        require('\u0000' !in it)
    }
}

/**
 * SOCKET SQE execution. Encoding follows io_uring_prep_socket: the SQE carries
 * domain in the fd field, protocol in len, type in offset; res = new fd or
 * -errno. AF_INET yields a stream descriptor; AF_UNIX yields a UNIX stream.
 */
internal fun jvmSocket(domain: Int, protocol: Int, type: Int): Int {
    val fd = JvmSocketSyscalls.socket(domain, type, protocol)
    return if (fd < 0) fd else JvmFileTable.register(JvmSocketDescriptor(fd))
}

/**
 * OPENAT. On Linux and Darwin the descriptor is the operating system's, opened with every Linux O_*
 * flag the facade carries; elsewhere a JDK channel serves READ, WRITE, CREAT, EXCL and TRUNC.
 */
internal fun jvmOpen(path: String, flags: Long, permissions: Int = 438): Int {
    if (JvmFileSyscalls.posix) {
        if (flags < 0 || flags > Int.MAX_VALUE || permissions !in 0..4095) return -22
        val fd = JvmFileSyscalls.openat(UringOp.AT_FDCWD, path, flags.toInt(), permissions)
        return if (fd < 0) fd else JvmFileTable.register(JvmNativeDescriptor(fd))
    }
    require(flags >= 0 && flags and (3L or 64L or 128L or 512L).inv() == 0L)
    val mode = flags.toInt() and 3
    require(mode != 3)
    val options = mutableSetOf<StandardOpenOption>()
    if (mode != 1) options.add(StandardOpenOption.READ)
    if (mode != 0) options.add(StandardOpenOption.WRITE)
    if (flags and 64L != 0L) {
        // FileChannel ignores CREATE without WRITE; do not silently claim an open that created nothing.
        require(mode != 0)
        options.add(if (flags and 128L != 0L) StandardOpenOption.CREATE_NEW else StandardOpenOption.CREATE)
    }
    if (flags and 512L != 0L) { require(mode != 0); options.add(StandardOpenOption.TRUNCATE_EXISTING) }
    require(permissions in 0..511)
    val permissionSet = java.nio.file.attribute.PosixFilePermission.values().filterIndexed { index, _ ->
        permissions and (1 shl (8 - index)) != 0
    }.toSet()
    val target = Paths.get(path)
    val creating = flags and 64L != 0L
    val posix = target.fileSystem.supportedFileAttributeViews().contains("posix")
    require(!creating || posix || permissions == 438) { "Cannot enforce POSIX creation permissions on this provider" }
    val channel = if (creating && posix) FileChannel.open(target, options,
        java.nio.file.attribute.PosixFilePermissions.asFileAttribute(permissionSet)) else FileChannel.open(target, options)
    return JvmFileTable.register(JvmChannelDescriptor(channel))
}

/** The longest single readiness wait while holding the backend monitor; longer waits repeat it. */
private const val WAIT_SLICE_MILLIS = 10

/** Blocking OS primitives servicing commonMain uring submissions; this is emulation. */
internal class JvmUserspaceChannelBackend(
    override val availability: String = "emulated: JVM file and POSIX socket effects; kernel ring not selected",
    private val readiness: JvmReadiness = JvmReadiness(),
) : UserspaceChannelBackend, JvmReadiness.Sink {
    override val capabilities: Long get() = jvmUringOperations
    override val deferredCapabilities: Long
        get() = if (connectWatches > 0) UringOp.caps(UringOp.POLL_ADD, UringOp.CONNECT) or
            UringOp.caps(UringOp.WRITE, UringOp.SEND, UringOp.READ, UringOp.RECV)
        else UringOp.caps(UringOp.POLL_ADD, UringOp.CONNECT)

    /** Unsettled CONNECT watches: while any is held, io on their descriptors waits behind them. */
    @Volatile private var connectWatches = 0
    /** POLL_ADD watches on JDK channels whose mask asks for neither POLLIN nor POLLOUT: they never fire. */
    private val parked = HashSet<Long>()
    private val completions = ArrayDeque<SelectionResult>()
    private var closed = false
    private var draining = false

    @Synchronized
    override fun submitBatch(submissions: List<UringSubmission>): List<SelectionResult> {
        val results = ArrayList<SelectionResult>(submissions.size)
        for (sub in submissions) {
            val result = when (sub.opcode) {
                UringOp.POLL_ADD -> pollAdd(sub)
                UringOp.CONNECT -> connect(sub)
                // Execution dependency: io on an fd with an unsettled CONNECT waits
                // for the CONNECT CQE; it is re-executed on the following reap.
                UringOp.WRITE, UringOp.SEND, UringOp.READ, UringOp.RECV ->
                    if (connectWatches > 0 && connectPendingOn(sub.fd)) {
                        heldBehindConnect[sub.userData] = sub
                        null
                    } else execute(sub)
                else -> execute(sub)
            }
            if (result != null) results.add(SelectionResult(result, sub.userData))
        }
        return results
    }

    /** io deferred behind an unsettled CONNECT on the same fd. */
    private val heldBehindConnect = LinkedHashMap<Long, UringSubmission>()

    private fun connectPendingOn(fd: Int): Boolean = synchronized(this) {
        val descriptor = JvmFileTable.descriptor(fd) ?: return false
        readiness.connectPending(descriptor)
    }

    private fun watching(token: Long): Boolean = readiness.watching(token) || token in parked

    private fun pollAdd(sub: UringSubmission): Int? {
        if (closed) return -9
        if (draining) return -125
        if (sub.flags != 0 || sub.len != 0 || sub.operationFlags and 0x3f.inv() != 0) return -95
        val descriptor = JvmFileTable.descriptor(sub.fd) ?: return -9
        if (!descriptor.isOpen()) return -9
        if (watching(sub.userData)) return -17
        val fd = when (descriptor) {
            is JvmSocketDescriptor -> descriptor.fd
            is JvmNativeDescriptor -> descriptor.fd
            else -> -1
        }
        if (fd < 0) {
            // A JDK channel is always ready for what it can do, as poll(2) answers for a regular file.
            val ready = sub.operationFlags and (1 or 4)
            if (ready != 0) completions.addLast(SelectionResult(ready, sub.userData)) else parked.add(sub.userData)
            return null
        }
        readiness.watch(sub.userData, descriptor, fd, sub.operationFlags, connect = false, sink = this)
        return null
    }

    private fun connect(sub: UringSubmission): Int? {
        if (closed) return -9
        if (draining) return -125
        if (sub.flags != 0 || sub.operationFlags != 0) return -95
        val descriptor = JvmFileTable.descriptor(sub.fd) ?: return -9
        if (descriptor !is JvmSocketDescriptor) return -88
        if (watching(sub.userData)) return -17
        return synchronized(descriptor) {
            if (!descriptor.isOpen()) return -9
            val result = JvmSocketSyscalls.connectStart(descriptor.fd, sub.buffer, sub.len, sub.addr)
            if (result != -115) result else {
                readiness.watch(sub.userData, descriptor, descriptor.fd, 4, connect = true, sink = this)
                connectWatches++
                null
            }
        }
    }

    /** [JvmReadiness.Sink]: a POLL_ADD reports its revents; a CONNECT reports SO_ERROR once POLLOUT arrives. */
    override fun ready(token: Long, revents: Int, connect: Boolean, descriptor: JvmDescriptor): Boolean {
        if (!connect) {
            completions.addLast(SelectionResult(revents, token))
            return true
        }
        val socket = descriptor as JvmSocketDescriptor
        val result = synchronized(socket) {
            if (!socket.isOpen() || revents and 0x20 != 0) -9 else JvmSocketSyscalls.connectFinish(socket.fd)
        }
        if (result == -115 || result == -114) return false
        connectWatches--
        completions.addLast(SelectionResult(result, token))
        return true
    }

    override fun ended(token: Long, res: Int, connect: Boolean) {
        if (connect) connectWatches--
        completions.addLast(SelectionResult(res, token))
    }

    override fun reapCompletions(minComplete: Int): List<SelectionResult> = reapCompletions(minComplete, -1L)

    override fun reapCompletions(minComplete: Int, timeoutNanos: Long): List<SelectionResult> {
        require(minComplete >= 0)
        val results = ArrayList<SelectionResult>()
        val deadline = if (timeoutNanos < 0L) Long.MAX_VALUE else System.nanoTime() + timeoutNanos
        // A settled CONNECT unblocks the io it held back: execute it now.
        releaseHeld(results)
        // Each wait holds the monitor for one bounded slice, so cancelPending/drain can make progress between slices.
        while (true) {
            val more = synchronized(this) {
                while (completions.isNotEmpty()) results.add(completions.removeFirst())
                if (readiness.watches == 0) return@synchronized false
                val remaining = deadline - System.nanoTime()
                val slice = if (results.size >= minComplete || remaining <= 0L) 0
                    else minOf(WAIT_SLICE_MILLIS.toLong(), (remaining + 999_999L) / 1_000_000L).toInt()
                readiness.wait(slice, this)
                while (completions.isNotEmpty()) results.add(completions.removeFirst())
                results.size < minComplete && readiness.watches > 0 && System.nanoTime() < deadline
            }
            if (!more) break
        }
        // A CONNECT that settled during the wait releases io deferred behind it.
        releaseHeld(results)
        return results
    }

    /** After one readiness wait of at most [millis], whether a completion is queued; with nothing watched it does not wait. */
    internal fun queuedAfter(millis: Int): Boolean = synchronized(this) {
        if (completions.isEmpty() && readiness.watches > 0) readiness.wait(millis, this)
        completions.isNotEmpty()
    }

    internal val watching: Boolean get() = synchronized(this) { readiness.watches > 0 }

    /** A completion is queued, or nothing is watched: a reap would not wait on readiness. */
    internal fun completionReady(): Boolean = synchronized(this) { completions.isNotEmpty() || readiness.watches == 0 }

    /** The descriptors and events readiness waits on, for a waiter that polls them beside its own ring. */
    internal fun completionPollSet(): Pair<IntArray, IntArray> = synchronized(this) { readiness.pollSet() }

    /**
     * Readiness waits in bounded slices on IO threads, each holding the monitor as [reapCompletions] does; a slice's
     * events land in [completions], unconsumed. Returns once one is queued or nothing is watched; cancellation takes
     * effect between slices.
     */
    override suspend fun awaitCompletions() {
        while (kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { !queuedAfter(WAIT_SLICE_MILLIS) && watching }) Unit
    }

    private fun releaseHeld(results: MutableList<SelectionResult>) = synchronized(this) {
        if (heldBehindConnect.isEmpty()) return@synchronized
        val stillHeld = LinkedHashMap<Long, UringSubmission>()
        for ((token, sub) in heldBehindConnect) {
            if (!connectPendingOn(sub.fd)) execute(sub).let { results.add(SelectionResult(it, token)) }
            else stillHeld[token] = sub
        }
        heldBehindConnect.clear()
        heldBehindConnect.putAll(stillHeld)
    }

    @Synchronized
    override fun cancelPending() {
        draining = true
        // Cancel observation, retaining socket identity until CLOSE/backend close. The peer may
        // already have accepted the connection; no backend effect can still access the sockaddr.
        readiness.endAll(this, -125)
        for (token in parked) completions.addLast(SelectionResult(-125, token))
        parked.clear()
        // io deferred behind a CONNECT cannot proceed once the ring is cancelling.
        for ((token, _) in heldBehindConnect) completions.addLast(SelectionResult(-125, token))
        heldBehindConnect.clear()
    }

    @Synchronized
    override fun counters(): Map<String, Long> = readiness.counters() + mapOf(
        "backend.held" to heldBehindConnect.size.toLong(), "backend.connects" to connectWatches.toLong(),
    )

    internal fun execute(sub: UringSubmission): Int {
        val preflight = synchronized(this) {
            if (closed) -9
            else if (sub.flags != 0) -95
            else if (capabilities and sub.opcode.mask == 0L) -95
            else null
        }
        if (preflight != null) return preflight
        return try {
            when (sub.opcode) {
                UringOp.NOP -> 0
                // Socket lifecycle as SQEs: creation, bind, listen and accept each
                // settle one CQE. res carries the new fd (SOCKET/ACCEPT), 0 or
                // -errno (BIND/LISTEN) — the same result the kernel ring reports.
                UringOp.SOCKET -> jvmSocket(sub.fd, sub.len, sub.offset.toInt())
                UringOp.POLL_REMOVE -> synchronized(this) {
                    if (parked.remove(sub.addr)) {
                        completions.addLast(SelectionResult(-125, sub.addr))
                        return 0
                    }
                    if (readiness.kind(sub.addr) != 0) return -2
                    readiness.unwatch(sub.addr, this)
                    completions.addLast(SelectionResult(-125, sub.addr))
                    0
                }
                // io_uring_prep_cancel64 with flags=0: cancel one admission by userData.
                // No ring-wide draining and no descriptor close; the original request
                // and the cancellation each retain their own terminal completion.
                UringOp.ASYNC_CANCEL -> synchronized(this) {
                    if (sub.operationFlags != 0) return -95
                    if (sub.len != 0 || sub.offset != 0L) return -22
                    val kind = readiness.kind(sub.addr)
                    if (kind >= 0) {
                        readiness.unwatch(sub.addr, this)
                        if (kind == 1) connectWatches--
                    } else if (!parked.remove(sub.addr) && heldBehindConnect.remove(sub.addr) == null) return -2
                    completions.addLast(SelectionResult(-125, sub.addr))
                    0
                }
                UringOp.MADVISE -> if (sub.len < 0) -22 else adviseMemory(sub.addr, sub.len.toLong(), sub.operationFlags)
                UringOp.OPENAT -> {
                    if (sub.fd != -100) return -95
                    jvmOpen(sub.path(), sub.offset, sub.operationFlags)
                }
                // Path syscalls. The path rides in the submission buffer, and renameat carries
                // both halves NUL-separated -- one buffer, because an SQE has one address field
                // and inventing a second channel for the second path would be a shape only this
                // backend understands. Paths resolve from the working directory (AT_FDCWD).
                UringOp.UNLINKAT -> when {
                    sub.fd != UringOp.AT_FDCWD -> -95
                    JvmFileSyscalls.posix -> JvmFileSyscalls.unlinkat(sub.fd, sub.path(), sub.operationFlags)
                    else -> { Files.delete(Paths.get(sub.path())); 0 }
                }
                UringOp.MKDIRAT -> when {
                    sub.fd != UringOp.AT_FDCWD -> -95
                    sub.operationFlags !in 0..4095 -> -22
                    JvmFileSyscalls.posix -> JvmFileSyscalls.mkdirat(sub.fd, sub.path(), sub.operationFlags)
                    else -> { Files.createDirectory(Paths.get(sub.path())); 0 }
                }
                UringOp.RENAMEAT -> {
                    val bytes = sub.buffer ?: return -22
                    if (sub.len <= 0 || sub.len > bytes.remaining()) return -22
                    val both = bytes.array().decodeToString(bytes.arrayOffset() + bytes.position(),
                        bytes.arrayOffset() + bytes.position() + sub.len, throwOnInvalidSequence = true)
                    val split = both.indexOf('\u0000')
                    if (both.indexOf('\u0000', split + 1) >= 0) return -22
                    if (split <= 0 || split == both.length - 1) return -22
                    if (sub.fd != UringOp.AT_FDCWD || sub.offset != UringOp.AT_FDCWD.toLong()) return -95
                    if (sub.operationFlags != 0) return -22
                    if (JvmFileSyscalls.posix) return JvmFileSyscalls.renameat(sub.fd, both.substring(0, split), sub.offset.toInt(), both.substring(split + 1))
                    Files.move(
                        Paths.get(both.substring(0, split)), Paths.get(both.substring(split + 1)),
                        StandardCopyOption.REPLACE_EXISTING,
                    )
                    0
                }
                UringOp.STATX -> statx(sub)
                UringOp.CLOSE -> {
                    // Watches on the descriptor end with EBADF before its number can be reused.
                    JvmFileTable.descriptor(sub.fd)?.let { descriptor -> synchronized(this) { readiness.closing(descriptor, this) } }
                    JvmFileTable.close(sub.fd)
                }
                else -> {
                    val descriptor = JvmFileTable.descriptor(sub.fd) ?: return -9
                    if (descriptor is JvmSocketDescriptor) return synchronized(descriptor) {
                        if (!descriptor.isOpen()) -9
                        // CONNECT shares the batch path's deferred contract: immediate results
                        // return directly; a registered deferral (EINPROGRESS watch) reports 0 —
                        // the caller settles the outcome through the CQE stream.
                        else if (sub.opcode == UringOp.CONNECT) {
                            // Direct contract: immediate results return directly; an EINPROGRESS
                            // deferral settles synchronously by reaping its registered watch
                            // (bounded), so the caller receives a settled res like the batch
                            // path's CQE.
                            val direct = connect(sub)
                            if (direct == null) {
                                // Own the completion by token: reap until this CONNECT's
                                // CQE arrives; re-queue any foreign CQEs for their owners.
                                // Arrival tracking is nullable: -95 is a valid terminal
                                // error, not a "still waiting" sentinel.
                                var settled: Int? = null
                                while (settled == null) {
                                    reapCompletions(minComplete = 1).forEach { cqe ->
                                        if (cqe.userData == sub.userData) settled = cqe.res
                                        else synchronized(this@JvmUserspaceChannelBackend) {
                                            completions.addLast(cqe)
                                        }
                                    }
                                }
                                settled!!
                            } else direct
                        }
                        else socketExecute(descriptor.fd, sub)
                    }
                    if (sub.opcode in setOf(UringOp.BIND, UringOp.LISTEN, UringOp.ACCEPT, UringOp.CONNECT, UringOp.SHUTDOWN, UringOp.URING_CMD)) return -88
                    if (descriptor is JvmNativeDescriptor) return synchronized(descriptor) {
                        if (!descriptor.isOpen()) -9 else descriptorExecute(descriptor.fd, sub)
                    }
                    val channel = (descriptor as? JvmChannelDescriptor)?.channel ?: return -95
                    when (sub.opcode) {
                        UringOp.READ, UringOp.WRITE -> transfer(channel, sub)
                        UringOp.READ_FIXED, UringOp.WRITE_FIXED -> transfer(channel,
                            sub.copy(opcode = if (sub.opcode == UringOp.READ_FIXED) UringOp.READ else UringOp.WRITE))
                        UringOp.FALLOCATE -> {
                            // Grow to offset+len without writing the interior; a hole is the point.
                            val want = sub.offset + sub.len
                            if (want > channel.size()) channel.write(java.nio.ByteBuffer.wrap(byteArrayOf(0)), want - 1)
                            0
                        }
                        UringOp.FADVISE -> advise(channel, sub)
                        UringOp.FSYNC -> {
                            if (sub.operationFlags and 1.inv() != 0) return -22
                            channel.force(sub.operationFlags and 1 == 0); 0
                        }
                        UringOp.FTRUNCATE -> {
                            require(sub.offset >= 0)
                            if (sub.offset <= channel.size()) channel.truncate(sub.offset)
                            else if (channel.write(java.nio.ByteBuffer.wrap(byteArrayOf(0)), sub.offset - 1) != 1) return -5
                            0
                        }
                        else -> -95
                    }
                }
            }
        } catch (failure: Exception) { jvmIoError(failure) }
    }

    /** Socket effects retain the same OS descriptor from SOCKET through CLOSE. */
    private fun socketExecute(fd: Int, sub: UringSubmission): Int = when (sub.opcode) {
        UringOp.READ, UringOp.RECV, UringOp.WRITE, UringOp.SEND -> {
            if (sub.offset != -1L && sub.offset != 0L) -29
            else if (sub.buffer == null && sub.addr != 0L) JvmSocketSyscalls.transferAt(fd, sub.addr, sub.len,
                sub.opcode == UringOp.READ || sub.opcode == UringOp.RECV, sub.operationFlags)
            else JvmSocketSyscalls.transfer(fd, sub.buffer, sub.len,
                sub.opcode == UringOp.READ || sub.opcode == UringOp.RECV, sub.operationFlags)
        }
        UringOp.BIND -> JvmSocketSyscalls.bind(fd, sub.buffer, sub.len, sub.addr)
        UringOp.LISTEN -> JvmSocketSyscalls.listen(fd, sub.len)
        UringOp.SHUTDOWN -> JvmSocketSyscalls.shutdown(fd, sub.len)
        UringOp.URING_CMD -> when (sub.offset) {
            UringOp.SOCKET_URING_OP_SETSOCKOPT.toLong() ->
                JvmSocketSyscalls.setOption(fd, sub.buffer, sub.len, (sub.addr and 0xffffffffL).toInt(),
                    (sub.addr ushr 32).toInt(), sub.operationFlags)
            UringOp.SOCKET_URING_OP_GETSOCKNAME.toLong() ->
                JvmSocketSyscalls.name(fd, sub.buffer, sub.len, sub.operationFlags)
            // SETSOCKOPT with level and optname in addr's halves and one native-order int in the window, as the posix emulation reads it.
            UringOp.SOCKET_URING_OP_SETSOCKOPT.toLong() -> {
                val level = (sub.addr and 0xffffffffL).toInt()
                val name = (sub.addr ushr 32).toInt()
                val window = sub.buffer
                if (window == null || sub.len != 4) -22
                else if (!(level == UringOp.SOL_SOCKET && name == UringOp.SO_REUSEADDR || level == 6 && name == 1)) -92
                else intOption(sub.fd, level, name, java.nio.ByteBuffer.wrap(window.array(), window.arrayOffset() + window.position(), 4).order(java.nio.ByteOrder.nativeOrder()).int)
            }
            else -> -95
        }
        UringOp.ACCEPT -> {
            val accepted = JvmSocketSyscalls.accept(fd)
            if (accepted < 0) accepted
            else JvmFileTable.register(JvmSocketDescriptor(accepted))
        }
        else -> -95
    }

    /**
     * statx(dfd, path, flags, mask): the path's len bytes, its NUL, then the struct statx the call
     * writes. An empty path with AT_EMPTY_PATH reads the descriptor; a path resolves from AT_FDCWD.
     */
    private fun statx(sub: UringSubmission): Int {
        val buffer = sub.buffer ?: return -22
        val start = buffer.arrayOffset() + buffer.position()
        if (buffer.isReadOnly() || sub.len < 0 || sub.addr != 0L || sub.offset !in 0..0xffffffffL ||
            buffer.remaining() - sub.len < 1 + UringOp.STATX_SIZE || buffer.array()[start + sub.len] != 0.toByte()) return -22
        if (!JvmFileSyscalls.posix) return -95
        if (sub.operationFlags and (UringOp.AT_SYMLINK_NOFOLLOW or UringOp.AT_EMPTY_PATH or 0x800).inv() != 0) return -22
        val out = start + sub.len + 1
        if (sub.len == 0) {
            if (sub.operationFlags and UringOp.AT_EMPTY_PATH == 0) return -2
            val descriptor = JvmFileTable.descriptor(sub.fd) as? JvmNativeDescriptor ?: return -9
            return synchronized(descriptor) {
                if (!descriptor.isOpen()) -9
                else JvmFileSyscalls.statx(descriptor.fd, "", sub.operationFlags, sub.offset.toInt(), buffer.array(), out)
            }
        }
        if (sub.fd != UringOp.AT_FDCWD) return -95
        return JvmFileSyscalls.statx(sub.fd, sub.path(), sub.operationFlags, sub.offset.toInt(), buffer.array(), out)
    }

    /** File effects on an operating-system descriptor: the same results the kernel ring reports. */
    private fun descriptorExecute(fd: Int, sub: UringSubmission): Int = when (sub.opcode) {
        UringOp.READ, UringOp.WRITE, UringOp.READ_FIXED, UringOp.WRITE_FIXED -> {
            val read = sub.opcode == UringOp.READ || sub.opcode == UringOp.READ_FIXED
            val buffer = sub.buffer
            when {
                sub.len < 0 || sub.offset < -1L -> -22
                buffer != null -> if (sub.len > buffer.remaining() || read && buffer.isReadOnly()) -22
                    else JvmFileSyscalls.transfer(fd, buffer.array(), buffer.arrayOffset() + buffer.position(), sub.len, sub.offset, read)
                        .also { if (it > 0) buffer.position(buffer.position() + it) }
                sub.addr == 0L && sub.len != 0 -> -14
                sub.memory?.let { !it.isOpen || sub.addr < it.address || sub.addr - it.address > it.length - sub.len } == true -> -22
                else -> JvmFileSyscalls.transfer(fd, java.lang.foreign.MemorySegment.ofAddress(sub.addr).reinterpret(sub.len.toLong()), sub.len, sub.offset, read)
            }
        }
        UringOp.GETDENTS -> {
            val buffer = sub.buffer
            if (buffer == null || buffer.isReadOnly() || sub.len < 0 || sub.len > buffer.remaining()) -22
            else JvmFileSyscalls.getdents(fd, buffer.array(), buffer.arrayOffset() + buffer.position(), sub.len)
                .also { if (it > 0) buffer.position(buffer.position() + it) }
        }
        UringOp.FSYNC -> if (sub.operationFlags and 1.inv() != 0) -22 else JvmFileSyscalls.fsync(fd, sub.operationFlags and 1 != 0)
        UringOp.FTRUNCATE -> if (sub.offset < 0) -22 else JvmFileSyscalls.ftruncate(fd, sub.offset)
        UringOp.FALLOCATE -> {
            // Grow to offset+len without writing the interior, as the JDK-channel path does.
            val want = sub.offset + sub.len
            if (sub.offset < 0 || sub.len < 0) -22
            else JvmFileSyscalls.size(fd).let { size ->
                if (size < 0) size.toInt()
                else if (want > size) JvmFileSyscalls.transfer(fd, byteArrayOf(0), 0, 1, want - 1, false).coerceAtMost(0)
                else 0
            }
        }
        UringOp.FADVISE -> when {
            sub.offset < 0 || sub.len < 0 || sub.operationFlags !in 0..5 -> -22
            sub.operationFlags != ADVICE_WILLNEED -> 0
            else -> {
                // WILLNEED reads the range through, as the JDK-channel path does; no residency is claimed. The bytes land
                // in the thread's native window and stay there: no heap scratch is allocated (and cleared) per advice.
                val end = if (sub.len == 0) JvmFileSyscalls.size(fd) else sub.offset + sub.len
                val window = JvmFileSyscalls.window(4096)
                var at = sub.offset
                while (at < end) {
                    val n = JvmFileSyscalls.transfer(fd, window, minOf(4096L, end - at).toInt(), at, true)
                    if (n <= 0) break
                    at += n
                }
                0
            }
        }
        else -> -95
    }

    /** JDK fallback: valid cache-policy hints are accepted; WILLNEED reads the requested range.
     * It makes no residency guarantee and is reported as emulation in nativeCapabilities.
     */
    private fun advise(channel: FileChannel, sub: UringSubmission): Int {
        if (sub.offset < 0 || sub.len < 0 || sub.operationFlags !in 0..5) return -22
        if (sub.operationFlags != ADVICE_WILLNEED) return 0
        val length = if (sub.len == 0) (channel.size() - sub.offset) else sub.len.toLong()
        if (length <= 0L) return 0
        // A page-sized touch per page is enough to fault the range in; the bytes are discarded into a direct view of the
        // thread's native window, which the channel reads into without a temporary buffer of its own.
        val scratch = JvmFileSyscalls.window(4096).asSlice(0, 4096).asByteBuffer()
        var at = sub.offset
        val end = sub.offset + length
        while (at < end) {
            scratch.clear()
            scratch.limit(minOf(scratch.capacity().toLong(), end - at).toInt())
            val n = channel.read(scratch, at)
            if (n <= 0) break
            at += n
        }
        return 0
    }

    private fun transfer(channel: FileChannel, sub: UringSubmission): Int {
        val buffer = sub.buffer
        if (sub.len < 0 || sub.offset < -1L) return -22
        if (buffer != null && (sub.len > buffer.remaining() || sub.opcode == UringOp.READ && buffer.isReadOnly())) return -22
        val position = buffer?.position() ?: 0
        val nio = if (buffer != null) java.nio.ByteBuffer.wrap(buffer.array(), buffer.arrayOffset() + position, sub.len)
        else {
            if (sub.addr == 0L && sub.len != 0) return -14
            sub.memory?.let { memory ->
                if (!memory.isOpen || sub.addr < memory.address || sub.addr - memory.address > memory.length - sub.len) return -22
            }
            java.lang.foreign.MemorySegment.ofAddress(sub.addr).reinterpret(sub.len.toLong()).asByteBuffer()
        }
        val count = if (sub.opcode == UringOp.READ) {
            if (sub.offset == -1L) channel.read(nio) else channel.read(nio, sub.offset)
        } else {
            if (sub.offset == -1L) channel.write(nio) else channel.write(nio, sub.offset)
        }
        if (count > 0) buffer?.position(position + count)
        return count.coerceAtLeast(0) // io_uring EOF is a successful zero-byte completion.
    }

    override suspend fun batchEnqueue(submissions: Series<UringSubmission>): Series<UringCompletion> {
        // Submission order is the completion contract: deferred ops (CONNECT watches,
        // POLL_ADD) settle later via reap, but the caller observes CQEs in the order
        // the SQEs were queued.
        val order = List(submissions.size) { index -> submissions[index].userData }
        val outstanding = order.toHashSet()
        val byToken = HashMap<Long, Int>()
        fun take(result: SelectionResult) {
            val token = result.userData
            if (token !in outstanding) error("foreign or duplicate CQE for token $token")
            outstanding.remove(token)
            check(byToken.put(token, result.res) == null) { "duplicate CQE for token $token" }
        }
        submitBatch(List(submissions.size) { submissions[it] }).forEach(::take)
        while (outstanding.isNotEmpty()) {
            reapCompletions(0).forEach(::take)
            if (outstanding.isNotEmpty()) awaitCompletions()
        }
        return order.size j { index -> UringCompletion(order[index], byToken.getValue(order[index]), 0) }
    }

    @Synchronized
    override fun close() {
        if (closed) return
        cancelPending()
        closed = true
        readiness.close()
        // Returned descriptors belong to their callers and outlive the ring, as on Linux.
    }
}

internal fun openJvmEmulatedChannelBackend(): UserspaceChannelBackend = JvmUserspaceChannelBackend()

actual fun openUserspaceChannelBackend(entries: Int, mode: UringBackendMode?): UserspaceChannelBackend {
    require(entries > 0)
    val discovery = discoverJvmUringBackend(entries, mode)
    val selected = discovery.backend ?: JvmUserspaceChannelBackend(discovery.report.description)
    // The probe's verdict and what was actually selected (the FFM ring, the JNI module, or emulation) with the
    // operations its kernel executes: a native label or a kernel NOP alone does not show native network I/O.
    val report = discovery.report
    val described = "${report.description}; probe module=${report.module ?: "none"} phase=${report.phase}; " +
        "selected: ${selected.availability}; kernel ops 0x${selected.nativeCapabilities.toString(16)}"
    return object : UserspaceChannelBackend by selected {
        override val probeReport = report
        override val availability = described
    }
}

actual class FileImpl actual constructor(actual val id: Int) {
    actual fun isOpen(): Boolean = JvmFileTable.descriptor(id)?.isOpen() ?: false
    actual fun close() { JvmFileTable.close(id) }
    actual fun size(): Long = JvmFileTable.descriptor(id)?.size() ?: -1L
}

internal actual object FilesImpl {
    actual fun open(path: String, readOnly: Boolean): FileImpl {
        val fd = jvmOpen(path, if (readOnly) 0L else 2L)
        check(fd >= 0) { "open failed: $fd" }
        return FileImpl(fd)
    }
}

internal actual object ChannelsImpl {
    /**
     * A stream socket in the shared fd table. Non-blocking, because the waist is a
     * submission/completion model and a blocking read would stall the whole ring.
     * domain/type/protocol are the POSIX triple; only AF_INET/SOCK_STREAM is emulated here,
     * and anything else is refused rather than silently downgraded.
     */
    actual fun socket(domain: Int, type: Int, protocol: Int): FileImpl {
        val fd = jvmSocket(domain, protocol, type)
        check(fd >= 0) { "SOCKET failed: $fd" }
        return FileImpl(fd)
    }
}
