package borg.trikeshed.util.oroboros

import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CompletableJob
import borg.trikeshed.context.Drain
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.launch
import java.nio.file.ClosedWatchServiceException
import java.nio.file.FileSystems
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardWatchEventKinds
import java.nio.file.WatchKey
import java.nio.file.WatchService
import java.util.concurrent.TimeUnit
import kotlin.coroutines.CoroutineContext

/** JVM bind for the Oroboros file-event reactor. WatchService blocks only on Dispatchers.IO. */
class JvmFileWatchReactorElement(
    root: String,
    parentJob: Job? = null,
    capacity: Int = 64,
    /**
     * Inclusive globs (relative to [root]) whose events are forwarded.
     *
     * Default: `.git` plus everything under it — mirrors everything under the embedded git DB
     * (loose objects, packs, refs).
     */
    includeGlobs: List<String> = listOf(".git/**"),
    /**
     * Exclusive globs (relative to [root]) whose events are dropped IF they also
     * pass an include glob.
     *
     * Default: every `.kt` path — drops Kotlin source ("the code checked in").
     */
    excludeGlobs: List<String> = listOf("**" + "/" + "*.kt"),
    /**
     * Directory names pruned during the initial walk, at any depth — the OS watch is never
     * registered for them, so they cost nothing to walk and deliver no events.
     *
     * Per-instance rather than global, because instances disagree on what is noise: the git
     * watcher exists to see everything under `.git`, which the worktree watcher must never
     * descend into. A global constant cannot express that, and the global it replaced omitted
     * `.git` AND `.claude/worktrees` — so the worktree watcher registered a watch on every
     * directory of the git object store and of every agent worktree checkout, minutes of
     * walking and a large permanent watch set, on a daemon that only cares about tracked source.
     */
    private val walkerBlockedSegments: Set<String> = DEFAULT_WALKER_BLOCKED_SEGMENTS,
    /** Root-relative subtrees pruned during the walk (e.g. `.claude/worktrees`). */
    private val walkerBlockedRelativePrefixes: Set<String> = emptySet(),
) : CoroutineContext.Element, Drain {
    companion object Key : CoroutineContext.Key<JvmFileWatchReactorElement>
    override val key: CoroutineContext.Key<*> = Key
    val supervisor: CompletableJob = SupervisorJob(parentJob)

    private val rootPath = Path.of(root).toAbsolutePath().normalize()
    private val eventChannel = Channel<FileEvent>(capacity)
    private val directories = mutableMapOf<WatchKey, Path>()
    private var watchService: WatchService? = null
    private var watchJob: Job? = null
    private var rootKey: WatchKey? = null

    private val glob: PathGlob = PathGlob(includeGlobs, excludeGlobs)

    val events: ReceiveChannel<FileEvent> get() = eventChannel

    suspend fun open() {
        if (fsEvents != null || watchService != null || supervisor.isCompleted) return
        if (FsEventStream.available && Files.isDirectory(rootPath)) {
            openFsEvents()
            return
        }
        val service = FileSystems.getDefault().newWatchService()
        watchService = service
        registerTree(rootPath, service)
        watchJob = CoroutineScope(kotlinx.coroutines.currentCoroutineContext() + this + supervisor + Dispatchers.IO).launch {
            watchLoop(service)
        }
    }

    private var fsEvents: FsEventStream? = null

    /**
     * macOS: one kernel event stream for the whole tree. Paths arrive as real paths, so they are
     * relativized against the root's real path; blocked segments and globs filter at event time.
     * A dropped or root-level event is published as the root rescan signal `("", MODIFY)`.
     */
    private fun openFsEvents() {
        val real = rootPath.toRealPath()
        val prefix = real.toString() + "/"
        fsEvents = FsEventStream(real.toString(), 0.3) { path, flags ->
            val rescan = flags and (FsEventStream.MUST_SCAN_SUBDIRS or FsEventStream.USER_DROPPED or
                FsEventStream.KERNEL_DROPPED or FsEventStream.ROOT_CHANGED) != 0
            val event = when {
                rescan -> FileEvent("", FileEventType.MODIFY)
                !path.startsWith(prefix) -> null
                else -> {
                    val rel = path.substring(prefix.length)
                    if (isIgnored(real.resolve(rel)) || !glob.accepts(rel)) null
                    else {
                        val removed = flags and FsEventStream.ITEM_REMOVED != 0
                        val created = flags and FsEventStream.ITEM_CREATED != 0
                        val renamed = flags and FsEventStream.ITEM_RENAMED != 0
                        // Coalesced flags (created and removed in one latency window) are settled by what is there now.
                        val type = if (removed || created || renamed) {
                            if (Files.exists(real.resolve(rel))) {
                                if (created || renamed) FileEventType.CREATE else FileEventType.MODIFY
                            } else FileEventType.DELETE
                        } else FileEventType.MODIFY
                        FileEvent(rel, type)
                    }
                }
            }
            // The dispatch queue is serial: blocking it on a full channel is the backpressure.
            if (event != null) runCatching { kotlinx.coroutines.runBlocking { eventChannel.send(event) } }
        }
    }

    override suspend fun drain() {
        if (fsEvents == null && watchService == null) return
        fsEvents?.let { fsEvents = null; eventChannel.close(); it.close() }
        watchService?.close()
        watchJob?.cancelAndJoin()
        eventChannel.close()
        supervisor.cancelAndJoin()
    }

    suspend fun close() = drain()

    private suspend fun watchLoop(service: WatchService) {
        try {
            while (true) {
                // A clean build can remove the root itself, not just its children.
                if (rootKey?.isValid != true) {
                    directories.keys.forEach { it.cancel() }
                    directories.clear()
                    rootKey = null
                    if (Files.isDirectory(rootPath)) {
                        registerTree(rootPath, service, publishExisting = true)
                        eventChannel.send(FileEvent("", FileEventType.MODIFY))
                    }
                }
                val watchKey = service.poll(500, TimeUnit.MILLISECONDS) ?: continue
                val directory = directories[watchKey]
                if (directory != null) {
                    for (rawEvent in watchKey.pollEvents()) {
                        if (rawEvent.kind() == StandardWatchEventKinds.OVERFLOW) {
                            registerTree(directory, service, publishExisting = true)
                            eventChannel.send(FileEvent("", FileEventType.MODIFY))
                            continue
                        }
                        @Suppress("UNCHECKED_CAST")
                        val relative = (rawEvent.context() as? Path) ?: continue
                        val path = directory.resolve(relative).normalize()
                        val relStr = rootPath.relativize(path).toString().replace('\\', '/')
                        if (rawEvent.kind() == StandardWatchEventKinds.ENTRY_CREATE && Files.isDirectory(path)) {
                            registerTree(path, service, publishExisting = true)
                        }
                        if (!glob.accepts(relStr)) continue
                        val type = when (rawEvent.kind()) {
                            StandardWatchEventKinds.ENTRY_CREATE -> FileEventType.CREATE
                            StandardWatchEventKinds.ENTRY_DELETE -> FileEventType.DELETE
                            else -> FileEventType.MODIFY
                        }
                        eventChannel.send(FileEvent(relStr, type))
                    }
                }
                if (!watchKey.reset()) directories.remove(watchKey)
            }
        } catch (_: ClosedWatchServiceException) {
            // Normal drain path.
        } finally {
            eventChannel.close()
        }
    }

    private suspend fun registerTree(start: Path, service: WatchService, publishExisting: Boolean = false) {
        // The walked tree churns underneath us (CAS atomic-write temps appear and vanish between
        // list and stat). Files.walk's readAttributes then throws NoSuchFileException, and letting
        // that escape open() cancelled the daemon's WHOLE job tree (the "Parent job is Cancelling"
        // kanban deaths). Walk manually; every vanished entry is simply not a directory to watch.
        suspend fun walk(dir: Path) {
            if (isIgnored(dir)) return
            runCatching {
                dir.register(
                    service,
                    StandardWatchEventKinds.ENTRY_CREATE,
                    StandardWatchEventKinds.ENTRY_MODIFY,
                    StandardWatchEventKinds.ENTRY_DELETE,
                )
            }.onSuccess { key ->
                directories[key] = dir
                if (dir == rootPath) rootKey = key
            }
            val children = runCatching { Files.newDirectoryStream(dir).use { it.toList() } }.getOrElse { return }
            for (child in children) {
                if (runCatching { Files.isDirectory(child) }.getOrDefault(false)) {
                    walk(child)
                } else if (publishExisting) {
                    val relative = rootPath.relativize(child).toString().replace('\\', '/')
                    if (glob.accepts(relative)) eventChannel.send(FileEvent(relative, FileEventType.CREATE))
                }
            }
        }
        if (runCatching { Files.isDirectory(start) }.getOrDefault(false)) walk(start)
    }

    internal fun isIgnored(path: java.nio.file.Path): Boolean {
        val relative = if (path.startsWith(rootPath)) rootPath.relativize(path) else path
        if (relative.any { it.toString() in walkerBlockedSegments }) return true
        if (walkerBlockedRelativePrefixes.isEmpty()) return false
        val relStr = relative.joinToString("/")
        return walkerBlockedRelativePrefixes.any { relStr == it || relStr.startsWith("$it/") }
    }
}

/**
 * Walk-time directory pruning: keeps the OS-level watch registration small
 * by not registering dirs that the watcher already excludes.
 *
 * Note: the watcher still registers these at a directory level so OS-level
 * FS events are delivered.  Filters enforced in [PathGlob] apply at event time.
 */
actual val DEFAULT_WALKER_BLOCKED_SEGMENTS: Set<String> =
    setOf(".gradle", ".idea", "build", "node_modules")

/**
 * Pure glob filter — accepts/rejects a path (relative to a watch root) based
 * on include/exclude lists.  Supports `**`, `*`, `?` glob tokens.
 */
internal class PathGlob(
    includeGlobs: List<String>,
    excludeGlobs: List<String>,
) {
    private val includeRe: List<Regex> = includeGlobs.map { compile(it) }
    private val excludeRe: List<Regex> = excludeGlobs.map { compile(it) }

    fun accepts(path: String): Boolean {
        // Includes: when non-empty, the path must match at least one.
        // Excludes: when the path matches at least one, it is dropped.
        // Empty includes = "no include filter" — accept all candidate paths.
        val included = includeRe.isEmpty() || includeRe.any { it.matches(path) }
        if (!included) return false
        return excludeRe.none { it.matches(path) }
    }

    companion object {
        fun compile(glob: String): Regex {
            val sb = StringBuilder("^")
            var i = 0
            while (i < glob.length) {
                val c = glob[i]
                when {
                    c == '*' && i + 1 < glob.length && glob[i + 1] == '*' -> {
                        sb.append(".*")
                        i += 2
                        if (i < glob.length && glob[i] == '/') i++
                    }
                    c == '*' -> {
                        sb.append("[^/]*")
                        i++
                    }
                    c == '?' -> {
                        sb.append("[^/]")
                        i++
                    }
                    c == '.' || c == '(' || c == ')' || c == '+' ||
                        c == '|' || c == '^' || c == '$' || c == '{' || c == '}' -> {
                        sb.append('\\').append(c)
                        i++
                    }
                    else -> {
                        sb.append(c)
                        i++
                    }
                }
            }
            sb.append('$')
            return Regex(sb.toString())
        }
    }
}

/** JVM actual of the common file-watch contract: delegates to the WatchService-backed element. */
actual class FileWatchReactorElement actual constructor(
    root: String,
    parentJob: kotlinx.coroutines.Job?,
    capacity: Int,
    includeGlobs: List<String>,
    excludeGlobs: List<String>,
    walkerBlockedSegments: Set<String>,
    walkerBlockedRelativePrefixes: Set<String>,
) : CoroutineContext.Element, Drain {
    actual companion object Key : CoroutineContext.Key<FileWatchReactorElement>
    private val delegate = JvmFileWatchReactorElement(
        root, parentJob, capacity, includeGlobs, excludeGlobs,
        walkerBlockedSegments, walkerBlockedRelativePrefixes,
    )
    actual val events: kotlinx.coroutines.channels.ReceiveChannel<FileEvent> get() = delegate.events
    actual override val key: CoroutineContext.Key<*> get() = Key
    actual suspend fun open() = delegate.open()
    actual override suspend fun drain() = delegate.drain()
    actual suspend fun close() = delegate.close()
}
