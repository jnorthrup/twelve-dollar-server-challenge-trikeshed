package borg.trikeshed.daemon

import borg.trikeshed.parse.reify
import borg.trikeshed.parse.jsonOf
import borg.trikeshed.narsese.cursor
import borg.trikeshed.narsese.ingestKg

import borg.trikeshed.couch.CouchReportReactorElement
import borg.trikeshed.couch.CouchStorage
import borg.trikeshed.couch.CouchStorageFormat
import kotlinx.coroutines.channels.Channel
import kotlin.collections.set
import kotlin.jvm.JvmStatic
import kotlin.jvm.Volatile
import kotlin.system.exitProcess
import borg.trikeshed.htx.HtxElement
import borg.trikeshed.htx.openHtxElement
import borg.trikeshed.torrent.TorrentElement
import borg.trikeshed.litebike.JvmKanbanServer
import borg.trikeshed.lib.j
import borg.trikeshed.lib.get
import borg.trikeshed.lib.size
import borg.trikeshed.lib.view
import borg.trikeshed.lib.α
import borg.trikeshed.userspace.nio.channels.SocketDomain
import borg.trikeshed.userspace.nio.channels.SocketType
import borg.trikeshed.userspace.nio.ByteBuffer
import borg.trikeshed.userspace.nio.channels.spi.ChannelOperations
import borg.trikeshed.userspace.nio.file.spi.JvmFileOperations
import borg.trikeshed.userspace.nio.spi.NioSupervisor
import borg.trikeshed.userspace.nio.ebpf.bpfProbeAttach
import borg.trikeshed.userspace.nio.ebpf.Tracepoints
import borg.trikeshed.util.io.ForgeCliArgs
import borg.trikeshed.util.oroboros.CouchAttachmentGateway
import borg.trikeshed.util.oroboros.FileCasStore
import borg.trikeshed.util.oroboros.GitCouchGateway
import borg.trikeshed.util.oroboros.FileWatchReactorElement
import borg.trikeshed.util.oroboros.WorktreeCouchGateway
import borg.trikeshed.userspace.reactor.MuxReactorElement
import borg.trikeshed.userspace.reactor.MuxReactorConfig
import borg.trikeshed.lcnc.ccek.ccekReactorBinding
import borg.trikeshed.platform.HostSystem
import borg.trikeshed.platform.InstantShim
import borg.trikeshed.platform.randomUuid
import borg.trikeshed.common.File
import borg.trikeshed.common.Files
import borg.trikeshed.common.Path
import borg.trikeshed.common.resolvePath
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import kotlinx.coroutines.job
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.withLock
import borg.trikeshed.utils.kanban.SessionBoardStore
import borg.trikeshed.userspace.nio.file.spi.JvmAppendWal
import borg.trikeshed.kanban.SessionCause
import kotlinx.coroutines.withContext
import borg.trikeshed.agent.modelmux.Airgap

/** Bridge shim Path to the JVM neighbors' java.io.File at the port boundary. */
private fun jfile(p: borg.trikeshed.common.Path): java.io.File = java.io.File(p.absolutePath)

/** Preserve a named worktree alias; resolve dot-only spellings so the project has a real name. */
internal fun primaryWorktreeRoot(path: java.io.File): java.io.File {
    val root = if (path.name.isBlank() || path.name == "." || path.name == "..") path.canonicalFile else path.absoluteFile
    require(root.name.isNotBlank()) { "Primary worktree must have a project name" }
    return root
}

//java and sun deps are forbidden
//syncronous calls, anything not SQE->CQE are absolutely banned here.  what is not written you must write as uring code hosted in commonMain nio code
// see PRELOAD.md for additional ques



/**
 * Oroboros daemon — serves the Couch/kanban/console surfaces.

 * Flags:
 *   --once                  single cycle then exit (default: --watch loops)
 *   --watch                 loop forever
 *   --airgap                disable remote Jev/LLM calls; keep local BERT
 *   --interval-ms <N>       poll cadence (default = 30000)
 *   --max-slots <N>         live session cap (default = 15)
 *   --hermes-root <path>    Hermes Python source checkout
 *   --hermes-sleeve <path>  GraalPy-safe overlay root
 *   --hermes-console        eagerly boot the xterm-256color Hermes VM panel
 *   --hermes-native-worker  opt into the OWN-trust native Hermes worker (not a sandbox)
 * Positional args (must come last):
 *   forgeHome               default = ~/.local/forge (ForgeHome.defaultHome)
 *   repoDir                 default = cwd
 */
/** The one database this daemon serves; also the first path segment of the Couch surface. */
const val COUCH_DB_NAME: String = "trikeshed"

/**
 * The absorbed classpath planes plus the durable manifest that makes them bootable.
 *
 * The Couch head projection is in-memory (CouchStoreFactory.casBacked), so blobs in the
 * forge-home CAS are unaddressable across a restart without an index. The manifest is that
 * index: `.oroboros/manifests/classpath.tsv` — one `kind\trelpath\tsha256hex\tlength` line
 * per classpath file — lets bin/oroboros-daemon hydrate a runtime classpath straight out of
 * `cas/sha256/` on a machine with no gradle build at all (a forge home replicated to a
 * separate instance carries its own install).
 */
internal class BuildPlanes(
    val attachments: CouchAttachmentGateway,
    val classesGateway: WorktreeCouchGateway, val classesDir: File,
    val libGateway: WorktreeCouchGateway, val libDir: File,
    val resourcesGateway: WorktreeCouchGateway, val resourcesDir: File,
    /** build/libs/hotswap-agent.jar — the javaagent rides the manifest under kind `agent`. */
    val agentJar: File,
    val manifestFile: File,
) {
    val classesPrefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/live/classes/"
    val libPrefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/staging/lib/"
    val resourcesPrefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/resources/"
    val agentPrefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/agent/"
}

/** Absorb the live classpath into the store; returns the attachment count. Skips directories that do not exist yet. */
internal fun reconcileBuildPlane(planes: BuildPlanes, revision: String): Int {
    var n = 0
    with(planes) {
        if (classesDir.isDirectory()) n += classesGateway.reconcile(classesDir.absolutePath, "oroboros", revision, HostSystem.currentTimeMillis()).paths.size
        if (libDir.isDirectory()) n += libGateway.reconcile(libDir.absolutePath, "oroboros", revision, HostSystem.currentTimeMillis()).paths.size
        if (resourcesDir.isDirectory()) n += resourcesGateway.reconcile(resourcesDir.absolutePath, "oroboros", revision, HostSystem.currentTimeMillis()).paths.size
        if (agentJar.isFile()) {
            val bytes = agentJar.readBytes()
            val cid = borg.trikeshed.job.ContentId.of(bytes)
            val path = agentPrefix + agentJar.name
            if (attachments.listAttachments(path).none { it.path == path && it.contentId == cid }) {
                attachments.putAttachment(
                    borg.trikeshed.util.oroboros.OroborosAttachmentRef(
                        path = path, contentType = "application/java-archive",
                        length = bytes.size.toLong(), contentId = cid,
                        agentId = "oroboros", revision = revision, sequence = HostSystem.currentTimeMillis(),
                    ),
                    bytes,
                )
            }
            n += 1
        }
        writeClasspathManifest(planes, revision)
    }
    return n
}

/** Atomic (tmp+rename) manifest write; an empty classpath never clobbers a previously good manifest. */
internal fun writeClasspathManifest(planes: BuildPlanes, revision: String) {
    val kinds = listOf(
        "classes" to planes.classesPrefix,
        "lib" to planes.libPrefix,
        "resources" to planes.resourcesPrefix,
        "agent" to planes.agentPrefix,
    )
    val lines = StringBuilder("# oroboros classpath manifest\n# revision $revision\n")
    var entries = 0
    for ((kind, prefix) in kinds) {
        for (ref in planes.attachments.listAttachments(prefix).sortedBy { it.path }) {
            lines.append(kind).append('\t').append(ref.path.removePrefix(prefix))
                .append('\t').append(ref.contentId.hex).append('\t').append(ref.length).append('\n')
            entries++
        }
    }
    if (entries == 0) return
    val file = planes.manifestFile
    file.parentFile?.mkdirs()
    val tmp = java.io.File(file.parentFile?.absolutePath, file.name + ".tmp")
    tmp.writeText(lines.toString())
    if (!tmp.renameTo(java.io.File(file.absolutePath))) {
        file.writeText(lines.toString())
        tmp.delete()
    }
}

object OroborosDaemon {

    const val DEFAULT_INTERVAL_MS = 30_000L
    const val DEFAULT_MAX_SLOTS = 15
    const val DEFAULT_KANBAN_PORT = 8888
    const val DEFAULT_PG_PORT = borg.trikeshed.pgwire.PgServerElement.DEFAULT_PORT

    data class DaemonConfig(
        val watch: Boolean,
        val intervalMs: Long,
        val maxSlots: Int,
        val kanbanPort: Int,
        val hermesRoot: String?,
        val hermesSleeve: String?,
        val hermesConsole: Boolean,
        val positional: List<String>,
        /** Extra scopes mounted at boot: --project <path> (repeatable). Git repo → projects/<name>/, else assets/<name>/. */
        val projects: List<String> = emptyList(),
        /** Dynamic modules attached at boot: --module <fqcn> (repeatable). Proxy-ctor loaded (app CP, then build/live). */
        val modules: List<String> = emptyList(),
        /** Coding agents offered to AGENT: cards and agent.run: --agents codex,opencode or TRIKESHED_AGENTS; default codex,opencode. */
        val agents: Set<String> = borg.trikeshed.agent.AgentRegistry.DEFAULT_ENABLED,
        val airgap: Boolean = Airgap.configured(),
        /** The pg wire listener's port: --pg-port N; 0 binds an ephemeral port. */
        val pgPort: Int = DEFAULT_PG_PORT,
        /** Native worker has host filesystem, subprocess and network capabilities. */
        val hermesNativeWorker: Boolean = false,
    )

    @Volatile
    var daemonStartTime = 0L

    @Volatile
    var isRunning = true

    fun parseConfig(args: Array<String>): DaemonConfig {
        var watch = true
        var airgap = Airgap.configured()
        var intervalMs = DEFAULT_INTERVAL_MS
        var maxSlots = DEFAULT_MAX_SLOTS
        var kanbanPort = DEFAULT_KANBAN_PORT
        var pgPort = DEFAULT_PG_PORT
        var hermesRoot: String? = null
        var hermesSleeve: String? = null
        var hermesConsole = false
        var hermesNativeWorker = false
        val positional = mutableListOf<String>()
        val projects = mutableListOf<String>()
        val modules = mutableListOf<String>()
        var agents: Set<String>? = null

        val flags = listOf(
            ForgeCliArgs.Flag(name = "--once") { _, i -> watch = false; i + 1 },
            ForgeCliArgs.Flag(name = "--watch") { _, i -> watch = true; i + 1 },
            ForgeCliArgs.Flag(name = "--airgap") { _, i -> airgap = true; i + 1 },
            // Consumed by mainImpl via the raw args (P2 belief-bag wiring); registered so the parser accepts it.
            ForgeCliArgs.Flag(name = "--belief-bag") { _, i -> i + 1 },
            ForgeCliArgs.Flag(name = "--project", withValue = true) { a, i -> projects.add(a[i]); i + 1 },
            ForgeCliArgs.Flag(name = "--module", withValue = true) { a, i -> modules.add(a[i]); i + 1 },
            ForgeCliArgs.Flag(name = "--agents", withValue = true) { a, i -> agents = a[i].split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet(); i + 1 },
            ForgeCliArgs.Flag(name = "--interval-ms", withValue = true) { a, i ->
                val v = a[i].toLongOrNull() ?: die("--interval-ms requires a positive long")
                intervalMs = v
                i + 1
            },
            ForgeCliArgs.Flag(name = "--max-slots", withValue = true) { a, i ->
                val v = a[i].toIntOrNull() ?: die("--max-slots requires a positive int")
                maxSlots = v
                i + 1
            },
            ForgeCliArgs.Flag(name = "--kanban-port", withValue = true) { a, i ->
                val v = a[i].toIntOrNull() ?: die("--kanban-port requires a positive int")
                kanbanPort = v
                i + 1
            },
            ForgeCliArgs.Flag(name = "--pg-port", withValue = true) { a, i ->
                val v = a[i].toIntOrNull()?.takeIf { it in 0..0xffff } ?: die("--pg-port requires a port number")
                pgPort = v
                i + 1
            },
            ForgeCliArgs.Flag(name = "--hermes-root", withValue = true) { a, i ->
                hermesRoot = a[i]
                i + 1
            },
            ForgeCliArgs.Flag(name = "--hermes-sleeve", withValue = true) { a, i ->
                hermesSleeve = a[i]
                i + 1
            },
            ForgeCliArgs.Flag(name = "--hermes-console") { _, i ->
                hermesConsole = true
                i + 1
            },
            ForgeCliArgs.Flag(name = "--hermes-native-worker") { _, i ->
                hermesNativeWorker = true
                i + 1
            },
        )

        when (val r = ForgeCliArgs.parse(args.toList(), flags)) {
            is ForgeCliArgs.Result.Parsed -> {
                require("--document-feed" !in r.remaining) {
                    "--document-feed is not supported; document intake is configured through project curation"
                }
                positional.addAll(r.remaining)
            }
            ForgeCliArgs.Result.Help -> { usage(); exitProcess(0) }
            is ForgeCliArgs.Result.Error -> die(r.message)
        }
        val agentsResolved = agents
            ?: HostSystem.getenv("TRIKESHED_AGENTS")?.split(',')?.map { it.trim().lowercase() }?.filter { it.isNotEmpty() }?.toSet()
            ?: borg.trikeshed.agent.AgentRegistry.DEFAULT_ENABLED
        return DaemonConfig(watch, intervalMs, maxSlots, kanbanPort, hermesRoot, hermesSleeve, hermesConsole, positional, projects, modules, agentsResolved, airgap, pgPort, hermesNativeWorker)
    }

    /** The native worker is OWN-trust, and cannot uphold the daemon's airgap setting. */
    internal fun nativeHermesWorker(config: DaemonConfig): Boolean {
        require(!(config.hermesNativeWorker && (config.airgap || Airgap.configured()))) {
            "--hermes-native-worker cannot be used while airgap is enabled"
        }
        return config.hermesNativeWorker
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val config = parseConfig(args)
        nativeHermesWorker(config)
        if (config.airgap) {
            // Pin the process before child initialization, including scopes that drop the context.
            System.setProperty(Airgap.PROPERTY, "true")
            HostSystem.err("[OROBOROS] airgap enabled: remote Jev/LLM calls disabled; local BERT retained")
        }
        try {
            runBlocking(Airgap(config.airgap)) {
                // The daemon gets its OWN supervised scope rather than launching straight into this
                // runBlocking. mainImpl is an extension on its receiver, so everything it launches
                // without an explicit parent becomes a child of that receiver — and runBlocking
                // waits on every child. `--once` therefore did all its work, ran its cleanup,
                // returned, and hung with nothing left to do: a test worker parked on
                // BlockingCoroutine.joinBlocking, 17s of CPU across 32 minutes of wall clock.
                //
                // The fix is structural, not a sweep. Cancelling leftover children by hand works
                // only while the cancel list stays exhaustive, and the next launch that forgets to
                // register reintroduces the hang silently. Scoping to a SupervisorJob makes
                // termination a property of the hierarchy instead: whatever mainImpl launched is a
                // child of daemonScope by construction, and one cancel of the parent ends all of
                // it, in a `finally`, on every path including throw. Supervisor rather than plain
                // Job so a child failing during shutdown cannot cancel its siblings mid-close —
                // the same idiom each element uses for its own supervisor.
                val daemonScope = CoroutineScope(coroutineContext + SupervisorJob(coroutineContext.job))
                val ipnsNodes = mutableListOf<borg.trikeshed.ipns.IpnsNode>()
                try {
                    with(daemonScope) { mainImpl(args, config) { ipnsNodes.add(it) } }
                } finally {
                    try {
                        var failure: Throwable? = null
                        for (node in ipnsNodes.asReversed()) try { node.close() } catch (caught: Throwable) {
                            if (failure == null) failure = caught else failure.addSuppressed(caught)
                        }
                        failure?.let { throw it }
                    }
                    finally { daemonScope.cancel() }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            // JVM shutdown triggered by signal handler
            exitProcess(0)
        }
    }


    private fun healthSocket(ops: ChannelOperations, healthSock: File): Int {
        // Bind with retry: a prior daemon may have left a stale socket file
        // even after the JVM exited; the bind() then creates a regular file
        // instead of a UNIX socket. Retry up to 3× with the file removed
        // between attempts so we always end up with a real socket.
        // The socket lifecycle is the CCEK reactor's, not raw JDK NIO:
        // AF_UNIX socket → bind → listen all through ChannelOperations.
        var fd = -1
        var bindAttempt = 0
        while (fd < 0 && bindAttempt < 3) {
            val candidate = ops.socket(SocketDomain.AF_UNIX.posix, SocketType.SOCK_STREAM.mask, 0)
            if (candidate >= 0 && ops.bindUnix(candidate, healthSock.absolutePath) == 0 && ops.listen(candidate) == 0) {
                fd = candidate
            } else {
                HostSystem.err("[OROBOROS] health.sock bind attempt ${bindAttempt + 1} failed")
                if (candidate >= 0) ops.close(candidate)
                if (healthSock.exists()) healthSock.delete()
                bindAttempt++
            }
        }
        if (fd < 0) {
            HostSystem.err("[OROBOROS] health.sock bind FAILED after 3 attempts; aborting")
        }
        return fd
    }

    /**
     * The one shared-context owner this root hands to every child that reads evidence. LOCAL (nothing is fetched from anyone)
     * unless OROBOROS_CONTEXT_KUBO_REPO names a node; the settings can express no publication at all. Kept outside mainImpl's
     * JVM-sized coroutine state machine.
     */
    private suspend fun openSharedContext(cas: borg.trikeshed.job.CasStore): borg.trikeshed.agent.modelmux.SharedContextElement =
        borg.trikeshed.agent.modelmux.SharedContextRoot.open("shared-context", cas,
            borg.trikeshed.agent.modelmux.SharedContextRoot.settings { HostSystem.getenv(it) },
            borg.trikeshed.userspace.nio.channels.spi.JvmProcessOperations())

    /** Keep curation drain ordering outside mainImpl's JVM-sized coroutine state machine. */
    private suspend fun drainCuration(
        follow: kotlinx.coroutines.Job?,
        intake: borg.trikeshed.forge.server.CurationIntake,
        modules: borg.trikeshed.module.ModuleSupervisor,
        ctx: borg.trikeshed.module.ModuleContext,
    ) {
        follow?.join()
        intake.drain()
        runCatching { modules.drainAll() }
        ctx.drainCouncilCases()
        intake.constellations()?.drain()
    }

    /** Keep consumer shutdown and its fact dependencies outside mainImpl's large state machine. */
    private suspend fun drainCamel(
        ctx: borg.trikeshed.module.ModuleContext,
        blackboard: borg.trikeshed.graal.BlackboardChangesFactElement,
        graal: borg.trikeshed.graal.vitals.GraalFactElement,
        vitals: borg.trikeshed.graal.vitals.JvmVitals,
    ) {
        // A failed consumer stop keeps its publication dependencies live for cleanup retry.
        checkNotNull(ctx.camelRoutes).drain()
        blackboard.drain()
        runCatching { graal.close() }
        runCatching { vitals.stop() }
    }

    /** Belief-field runner registration, kept out of the daemon's JVM-sized boot method. */
    private fun registerBeliefNodes(
        ctx: borg.trikeshed.module.ModuleContext,
        memory: borg.trikeshed.memory.HermesMemoryFiles?,
        brain: borg.trikeshed.modelmux.BrainClient,
        kif: borg.trikeshed.kif.KifKnowledgeBase,
    ) {
        ctx.beliefBag?.let { bag ->
            ctx.lcncRunners["nal.mint"] = borg.trikeshed.narsese.NalNodes.mintRunner(
                brain = brain, muxContext = ctx.muxContext, cas = ctx.casStore, bag = bag, rete = ctx.rete,
                kifSink = { text ->
                    val cid = borg.trikeshed.job.ContentId.of(text.encodeToByteArray())
                    ctx.blackboard.put("nal-kif/${cid.hex}", text, "nal.mint")
                    runCatching { kif.assertKif(text) }
                },
            )
            ctx.lcncRunners["nal.decay"] = borg.trikeshed.narsese.NalNodes.decayRunner(bag)
            ctx.lcncRunners["nal.recall"] = borg.trikeshed.narsese.NalNodes.recallRunner(bag)
            ctx.lcncRunners["skill.decay"] = borg.trikeshed.narsese.NalNodes.skillDecayRunner(bag)
        }
        ctx.beliefBag?.let { bag ->
            ctx.lcncRunners["state.freeze"] = borg.trikeshed.narsese.StateNodes.freezeRunner(
                bag = bag, kif = kif, cas = ctx.casStore,
                graph = { borg.trikeshed.rdf.RdfGraph(kotlinx.coroutines.runBlocking { ctx.rete.snapshot() }
                    .view.flatMap { borg.trikeshed.dag.PlaneFacts.toTriples(it).view }) },
            )
            ctx.lcncRunners["state.thaw"] = borg.trikeshed.narsese.StateNodes.thawRunner(bag = bag, cas = ctx.casStore, kif = kif)
        }
        ctx.beliefBag?.let { bag ->
            ctx.lcncRunners["beliefs.introspect"] = borg.trikeshed.narsese.BeliefsNodes.introspectRunner(bag)
            ctx.lcncRunners["beliefs.resonate"] = borg.trikeshed.narsese.BeliefsNodes.resonateRunner(bag) { memory?.glossOf(it) }
            ctx.lcncRunners["nal.attend"] = borg.trikeshed.narsese.BeliefsNodes.attendRunner(bag)
            ctx.lcncRunners["nal.reinforce"] = borg.trikeshed.narsese.BeliefsNodes.reinforceRunner(bag)
            ctx.lcncRunners["nars.seat"] = borg.trikeshed.narsese.NarsSeatNode.seatRunner(bag) { memory?.glossOf(it) }
        }
        ctx.turnReview?.let { review ->
            ctx.lcncRunners["beliefs.review"] = borg.trikeshed.narsese.BeliefsNodes.reviewRunner(review) { angular, gloss ->
                memory?.gloss(angular, gloss)
            }
        }
        ctx.lcncRunners["nal.encode"] = borg.trikeshed.narsese.BeliefsNodes.encodeRunner()
    }

    /** Own the Curator/Wiki producer so shutdown can join its current pass. */
    private fun CoroutineScope.curatorFollow(
        curatorImpulse: borg.trikeshed.narsese.CuratorImpulseElement?,
        hermesHomeDir: File,
        memoryStore: borg.trikeshed.memory.MemoryStore,
        couchStore: borg.trikeshed.couch.CouchStore,
        casStore: borg.trikeshed.job.CasStore,
        daemonBlackboard: borg.trikeshed.graal.ConfixBlackboard,
        wikiLane: Array<borg.trikeshed.lcnc.LcncNodeRunner?>,
    ): kotlinx.coroutines.Job? = if (curatorImpulse != null) {
        val profileDir = HostSystem.getenv("HERMES_PROFILE")?.let { File(it) }
            ?: File(hermesHomeDir.absolutePath)
        val archiveProfile = HostSystem.getenv("HERMES_ARCHIVE_PROFILE")?.let { File(it) }
            ?: File(HostSystem.getProperty("user.home") ?: error("no user.home"), ".hermes.prev").takeIf { it.isDirectory() }
        // Wiki Maintainer lane cadence: one pass per N transcript-cid
        // batches (the arXiv outer loop k); WIKI_CONSOLIDATE_EVERY=0
        // disables the lane entirely.
        val wikiEvery = HostSystem.getenv("WIKI_CONSOLIDATE_EVERY")?.toIntOrNull() ?: 1
        var wikiBatchesSeen = 0
        var wikiIterationsDone = 0
        // Transcript cids that landed before the runner was armed; drained
        // into the first Maintainer pass once it is.
        val wikiPending = linkedSetOf<String>()
        launch(Dispatchers.Default) {
            runCatching {
                val distilled = borg.trikeshed.narsese.HermesDesignDistiller.distillTo(jfile(profileDir), archiveProfile?.let(::jfile), memoryStore)
                HostSystem.err("[OROBOROS] Hermes design distilled: ${distilled.size} CAS documents")
            }.onFailure {
                HostSystem.err("[OROBOROS] Hermes design distillation failed (non-fatal): ${it.message}")
            }

            val feeder = borg.trikeshed.narsese.legacy.CuratorImpulseFeeder(jfile(profileDir))
            var checkpoint = borg.trikeshed.narsese.legacy.CuratorImpulseFeeder.FollowCheckpoint.empty()
            // I5: baselines are computed once per daemon run, after the first follow has
            // had a chance to land transcripts — session cids to the blackboard.
            var baselinesLanded = false
            while (isActive && isRunning) {
                var followed: borg.trikeshed.narsese.legacy.CuratorImpulseFeeder.FollowResult? = null
                runCatching {
                    val f = feeder.followOnce(curatorImpulse, memoryStore, checkpoint)
                    checkpoint = f.checkpoint
                    followed = f
                    if (f.landed.isNotEmpty() || f.transcriptCids.size > 0) {
                        HostSystem.err(
                            "[OROBOROS] Curator followed ${f.transcriptCids.size} changed transcripts: ${f.landed.size} signals; bank ${curatorImpulse.knowledgeBank.asserts().size} axioms",
                        )
                    }
                }.onFailure {
                    HostSystem.err("[OROBOROS] CuratorImpulse follow failed (non-fatal): ${it.message}")
                }
                // ── the arXiv outer loop (WikiSkill 2608.27454): every time
                //    the feeder lands NEW transcript cids, the Wiki
                //    Maintainer runs one consolidation pass over them —
                //    traces → PATCH edits to wiki/patterns/. Guarded by
                //    cadence + presence so an idle corpus spends nothing.
                //    Batches that land BEFORE the runner is armed are
                //    stashed and processed once it is (a boot's first
                //    follow races the module registration that wires
                //    WIKI_CONSOLIDATE); the drain check runs on every
                //    tick so an armed-then-idle corpus still drains.
                val freshCids = followed?.transcriptCids
                if (wikiEvery > 0 && freshCids != null && freshCids.size > 0) {
                    // Full backlog retained — truncating here silently dropped CID 33+ of a
                    // large follow, and unchanged sessions never re-report, so the wiki
                    // stayed stale until restart (curation-uring review, P1).
                    wikiPending.addAll((freshCids α { it.b.value }).view)
                }
                val wikiRunner = wikiLane[0]
                if (isRunning && wikiEvery > 0 && wikiRunner != null && wikiPending.isNotEmpty()) {
                    wikiBatchesSeen++
                    if (wikiBatchesSeen >= wikiEvery) {
                        wikiBatchesSeen = 0
                        // Retire resolved traces only after a recorded pass. Refused edits
                        // remain refusals in that record; replaying the whole batch would
                        // also repeat accepted edits. Missing/failed work rotates to the
                        // tail so it cannot starve CID 33+.
                        val cids = wikiPending.take(32)
                        wikiIterationsDone++
                        runCatching {
                            val wikiNode = borg.trikeshed.lcnc.LcncNode(
                                id = "wiki-consolidate-lane",
                                type = borg.trikeshed.lcnc.LcncContracts.WIKI_CONSOLIDATE,
                                params = mapOf("iteration" to wikiIterationsDone.toString()),
                            )
                            val report = wikiRunner.run(wikiNode, mapOf("cids" to cids))["report"] as? Map<*, *>
                            val acknowledged = borg.trikeshed.wiki.WikiNodes.settleConsolidation(wikiPending, cids, report)
                            HostSystem.err(
                                "[OROBOROS] Wiki Maintainer iteration $wikiIterationsDone: ok=${report?.get("ok")} " +
                                        "applied=${(report?.get("applied") as? List<*>)?.size ?: "-"} " +
                                        "refused=${(report?.get("refused") as? List<*>)?.size ?: "-"} " +
                                        "acknowledged=$acknowledged pending=${wikiPending.size}",
                            )
                        }.onFailure {
                            borg.trikeshed.wiki.WikiNodes.settleConsolidation(wikiPending, cids, null)
                            HostSystem.err("[OROBOROS] Wiki Maintainer failed (non-fatal, batch retained, pending=${wikiPending.size}): ${it.message}")
                        }
                    }
                }
                if (!baselinesLanded) {
                    runCatching {
                        val impulses = feeder.loadImpulses()
                        if (impulses.size > 0) {
                            val scenarios = feeder.loadScenarios(impulses)
                            val baselines = borg.trikeshed.narsese.HermesBaselines.computeAndLand(
                                couchStore, casStore, daemonBlackboard, impulses, scenarios,
                            )
                            if (baselines != null) {
                                baselinesLanded = true
                                HostSystem.err(
                                    "[OROBOROS] Hermes baselines landed: watermark=${baselines.watermark.size} training=${baselines.training?.sessionCid?.value?.take(18) ?: "-"} corpus=${baselines.corpus.cid.value.take(18)}@${baselines.corpus.seq}",
                                )
                            }
                        }
                    }.onFailure {
                        HostSystem.err("[OROBOROS] Hermes baseline computation failed (non-fatal): ${it.message}")
                    }
                }
                if (isRunning) delay(5_000L)
            }
        }
    } else null

    private fun CoroutineScope.ipnsNode(
        oroborosDir: File,
        ownIpns: (borg.trikeshed.ipns.IpnsNode) -> Unit,
        journal: String = "ipns.journal",
    ): borg.trikeshed.ipns.IpnsNode {
        val node = borg.trikeshed.ipns.jvmIpnsNode(
            File(Files.resolvePath(oroborosDir, journal)).absolutePath, coroutineContext,
            bootstrap = HostSystem.getenv("TRIKESHED_IPNS_BOOTSTRAP")
                ?: borg.trikeshed.ipns.IpnsDhtAddresses.PUBLIC_BOOTSTRAP,
        )
        ownIpns(node)
        return node
    }

    private suspend fun CoroutineScope.couchWire(
        db: borg.trikeshed.couch.Couch,
        replicator: borg.trikeshed.couch.replicate.CouchReplicator,
        targets: Map<String, borg.trikeshed.relaxfactory.RequestFactoryRpcTarget>,
        views: borg.trikeshed.couch.IncrementalViewRegistry,
        node: borg.trikeshed.ipns.IpnsNode,
    ): borg.trikeshed.forge.server.CouchWire {
        val report = CouchReportReactorElement(parentJob = coroutineContext[kotlinx.coroutines.Job])
        val processor = borg.trikeshed.relaxfactory.GwtCouchRequestFactory(db,
            viewServer = borg.trikeshed.couch.ViewServer(report))
        val requestFactory = borg.trikeshed.relaxfactory.RequestFactoryReactorElement(
            processor = { payload -> processor.process(payload) },
            closeProcessor = { processor.close() },
            parentJob = coroutineContext[kotlinx.coroutines.Job],
        )
        try { requestFactory.open() } catch (failure: Throwable) {
            try { requestFactory.drain() } catch (cleanup: Throwable) { failure.addSuppressed(cleanup) }
            throw failure
        }
        return borg.trikeshed.forge.server.CouchWire(
            router = borg.trikeshed.couch.CouchWireRouter(db, WorktreeCouchGateway.WORKTREE_PREFIX,
                replicator = replicator, report = report, rpcTargets = targets,
                requestFactoryHandler = requestFactory) { ddoc, view -> views.lookup(ddoc, view) },
            replicator = replicator,
            scope = CoroutineScope(SupervisorJob(coroutineContext[kotlinx.coroutines.Job]) + Dispatchers.Default),
            ipns = node,
            requestFactory = requestFactory,
        )
    }

    private suspend fun kotlinx.coroutines.CoroutineScope.mainImpl(
        args: Array<String>, config: DaemonConfig, ownIpns: (borg.trikeshed.ipns.IpnsNode) -> Unit,
    ) {
        // One lane order for the daemon and bin/mux: keymux.operatorKeyMux (harness env, dotenv and
        // auth files, raw env, hermes credential pool); without explicit fileOps the file lanes read nothing.
        val fileOps = JvmFileOperations()
        // Bound ONCE into keyMux below so the reactor-owned KeyMux identity never
        // changes: MuxReactorElement.modelMux() requires `mux.keyMux === keyMux()`,
        // and KeyMux.withBinding() returns a NEW instance. The Hermes default-model
        // pin is therefore refreshed by mutating this overlay's snapshot
        // (PinOverlaySource.setPin/clearPin), not by rebinding the mux.
        val hermesPinOverlay = borg.trikeshed.agent.keymux.PinOverlaySource()
        // baseKeyMux excludes the overlay — buildBrain's own pin resolution
        // reads THIS, not keyMux, so a repin never resolves through its own
        // previous pin (self-referential freeze). keyMux (reactor/catalog
        // identity) is the one wrapper, built once, on top of it.
        val baseKeyMux = borg.trikeshed.agent.keymux.operatorKeyMux(fileOps = fileOps, hermesHome = borg.trikeshed.agent.keymux.defaultHermesHome())
        val hermesCredentials = borg.trikeshed.agent.keymux.HermesCredentialSource(borg.trikeshed.agent.keymux.defaultHermesHome(), fileOps)
        val keyMux = baseKeyMux.withBinding("*", hermesPinOverlay)
        // Probe early so a missing key aborts before opening the HTX reactor.
        val apiKeyPresent = kotlinx.coroutines.withContext(Dispatchers.IO) { keyMux.get("JULES_API_KEY") }
        if (apiKeyPresent.isNullOrBlank()) {
            HostSystem.err("[OROBOROS] JULES_API_KEY not set; Jules credential pool will be empty.")
        }

        // FLYWHEEL_CYCLE_INTERVAL env overrides CLI --interval-ms.
        val envInterval = HostSystem.getenv("FLYWHEEL_CYCLE_INTERVAL")
        val intervalMs = if (envInterval != null) {
            val ms = envInterval.toLongOrNull()
            if (ms != null && ms > 0) {
                HostSystem.err("[OROBOROS] FLYWHEEL_CYCLE_INTERVAL=${ms}ms (env override)")
                ms
            } else {
                config.intervalMs
            }
        } else {
            config.intervalMs
        }
        val watch = config.watch
        val maxSlots = config.maxSlots
        val kanbanPort = config.kanbanPort
        val pgPort = config.pgPort
        val positional = config.positional

        val home = HostSystem.getProperty("user.home")
            ?: die("System property user.home not set")
        val (forgeHome, repoDir) = withContext(Dispatchers.IO) {
            val canonicalForge = File(Files.resolvePath(home, ".local/forge"))
            val fHome = File(positional.getOrNull(0) ?: canonicalForge.absolutePath)
            val rDir = File(positional.getOrNull(1) ?: HostSystem.getProperty("user.dir")!!)
            val gitDir = rDir.resolve(".git")
            if (!gitDir.exists()) {
                HostSystem.err("[OROBOROS] $rDir is not a git work tree. Aborting.")
                exitProcess(1)
            }
            // The bug class that dumps a gigabyte CAS into a source tree: forgeHome
            // resolving to (or inside) the repo worktree. Refuse outright — state
            // belongs in ~/.local forge homes, never in source.
            val fCanon = fHome.canonicalFile
            val rCanon = rDir.canonicalFile
            if (fCanon.path == rCanon.path || fCanon.path.startsWith(rCanon.path + File.separator)) {
                HostSystem.err("[OROBOROS] REFUSED: forgeHome $fCanon is inside the repo worktree $rCanon — daemon state never lands in source trees. Use ~/.local/forge*.")
                exitProcess(1)
            }
            fHome.mkdirs()
            Pair(fHome, File(primaryWorktreeRoot(jfile(rDir)).absolutePath))
        }
        if (!preflight(repoDir)) {
            HostSystem.err("[OROBOROS] preflight failed; aborting")
            return
        }
        // ── health FIRST ───────────────────────────────────────────────────
        // This used to bind 1,600 lines further down, after CAS, wiki, git
        // reconcile and the rest — so during a boot that takes minutes there was
        // no way to ask the daemon anything at all, and OroborosDaemonHealthTest
        // timed out waiting for a socket that only appears once the work is
        // already done. Health is the one surface that must exist BEFORE the slow
        // parts, not after them: it answers 'am I alive' while the answer is still
        // in doubt. It needs only forgeHome and daemonStartTime, both known here.
        daemonStartTime = HostSystem.currentTimeMillis()

        val oroborosDir = File(Files.resolvePath(forgeHome, ".oroboros"))
        oroborosDir.mkdirs()
        val healthSock = File(Files.resolvePath(oroborosDir, "health.sock"))
        if (healthSock.exists()) healthSock.delete()

        // The health socket is a CCEK reactor service: its descriptor lifecycle
        // is owned by ChannelOperations, so the supervisor (which registers the
        // platform provider) must be open BEFORE health binds — health is the
        // first IO the reactor takes.
        val nioSupervisor = NioSupervisor()
        nioSupervisor.open()
        val channelOps = nioSupervisor.service<ChannelOperations>()
            ?: run {
                HostSystem.err("[OROBOROS] no ChannelOperations service; aborting")
                return
            }

        val healthFd = healthSocket(channelOps, healthSock)
        if (healthFd < 0) return

        val healthJob = launch(Dispatchers.IO) {
            val handle = channelOps.openChannel(64)
            while (isActive) {
                var clientFd = -1
                try {
                    clientFd = channelOps.accept(healthFd)
                    if (clientFd < 0) {
                        delay(100)
                        continue
                    }
                    val uptimeMs = HostSystem.currentTimeMillis() - daemonStartTime

                    // Backward-compatible ALIVE line (cycle fields retired with the flywheel)
                    val aliveLine = "ALIVE $uptimeMs -1 -1 -1 -1 -1\n"

                    val metricsJson = try {
                        "METRICS " + jsonOf(mapOf("uptimeMs" to uptimeMs)) + "\n"
                    } catch (e: Exception) {
                        "METRICS {}\n"
                    }

                    // The ALIVE/METRICS payload is delivered through the uring
                    // facade (writev → submit → CQE), not a raw channel.
                    val metricsBytes = (aliveLine + metricsJson).toByteArray()
                    var sent = 0
                    while (sent < metricsBytes.size) {
                        val slice = ByteBuffer(metricsBytes, sent, metricsBytes.size - sent)
                        if (handle.writev(clientFd, slice, 0L) < 0) break
                        val cqe = handle.wait(1)
                        val wr = cqe.firstOrNull()?.res ?: -1
                        if (wr <= 0) break
                        sent += wr
                    }
                } catch (e: Exception) { /* ignore */ }
                finally {
                    if (clientFd >= 0) runCatching { channelOps.close(clientFd) }
                }
            }
        }

        // A daemon process rooted at a repo other than TrikeShed itself (its own port +
        // forgeHome, run standalone) must not file its worktree under "projects/trikeshed/" —
        // that mislabels every absorbed path with this project's name instead of its own.
        // lowercase() keeps TrikeShed's own default byte-identical to the prior hardcoded
        // literal ("TrikeShed".lowercase() == "trikeshed"), so existing stored content stays
        // addressable under the same prefix it was written with.
        WorktreeCouchGateway.WORKTREE_PREFIX = "projects/${repoDir.name.lowercase()}/"

        if ((HostSystem.getProperty("os.name") ?: "").lowercase().contains("linux")) {
            bpfProbeAttach(-1, Tracepoints.SYS_ENTER_SOCKET)
            bpfProbeAttach(-1, Tracepoints.SYS_ENTER_CONNECT)
            bpfProbeAttach(-1, Tracepoints.SYS_ENTER_EXECVE)
            bpfProbeAttach(-1, Tracepoints.SYS_ENTER_OPENAT)
        }

        // HTX + TLS reactor: every Jules API call (and every ModelMux/KeyMux
        // call) flows through HtxKey → HtxElement → HtxReactorElement →
        // JvmTlsCodecBackend. No standalone JDK HTTP client. mTLS
        // (ClientAuth, client cert, trust store) is configured on the
        // TlsConfig carried by the route service, not per-client. The
        // supervisor (opened above with the health bind) auto-registers
        // ChannelOperations + JvmTlsCodecBackend + HtxReactorElement
        // via platformNioProviders().
        val htxElement: HtxElement = openHtxElement(
            nioSupervisor = nioSupervisor,
            parentJob = coroutineContext[kotlinx.coroutines.Job],
        )
        HostSystem.err("[OROBOROS] HTX reactor open — Jules/ModelMux via TLS codec")

        // ── MuxReactorElement: the live key+quota surface ────────────────
        // Owns lease/quota state for both ModelMux.chat/stream/embed and the
        // Brain/Jules dispatch paths. Before this wiring, the KeyMux
        // ReactorSource and ModelMux lease/release calls were unreachable:
        // no MuxReactorElement.Key was ever present in any coroutine context,
        // so every quota edge was dead code in production.
        val operatorMux = kotlinx.coroutines.CompletableDeferred<suspend () -> borg.trikeshed.agent.modelmux.ModelMux>(coroutineContext[kotlinx.coroutines.Job])
        val muxReactor = MuxReactorElement(
            initialConfig = MuxReactorConfig(),
            parentJob = coroutineContext[kotlinx.coroutines.Job],
            keyMux = keyMux,
            modelMuxProvider = { operatorMux.await().invoke() },
        )
        muxReactor.open()
        // ── CCEK binding: the single control plane for assemblies ────
        // Provides choreograph(), createUserContext(), and the bounded
        // agent fan-out that LCNC nodes, model panels, and the curator
        // all run through. Modules access it via the binding's
        // reactorScope for coroutine dispatch.
        val ccekBinding = ccekReactorBinding(coroutineContext + Dispatchers.Default + nioSupervisor + fileOps + htxElement + muxReactor)
        HostSystem.err("[OROBOROS] CCEK binding open: reactor=${ccekBinding.reactorScope}")
        // Seed from already-resolved KeyMux env keys so the ReactorSource
        // (read path `llm.*.key`) returns real keyIds the very first cycle.
        // Each resolved key becomes one MuxCredentialRecord; later calls to
        // ModelMux.session(...).authKey() reach the pool via the ReactorSource.
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            for (provider in listOf(
                "jules", "brain"
            )) {
                val v = keyMux.get("$provider.default.key") ?: continue
                muxReactor.loadCredentialPool(
                    mapOf(provider to listOf(
                        borg.trikeshed.userspace.reactor.MuxCredentialRecord(
                            id = "$provider-default",
                            label = "$provider-default",
                            baseUrl = "",
                            lastStatus = "active",
                        )
                    ))
                )
                // store the resolved value on the entry for ReactorSource reads
                muxReactor.recordAccess(
                    keyId = "$provider-default",
                    provider = provider,
                    label = "$provider-default",
                )
            }
        }
        HostSystem.err("[OROBOROS] MuxReactor open — KeyMux/ModelMux live")

        // ── TorrentElement: BitTorrent v2 + uTP transport sharing HTX/TLS ──
        // Tracker announces flow through the same HtxElement → HtxReactorElement
        // → JvmTlsCodecBackend path as Jules/ModelMux. Piece data lands in the
        // BlockStore (content-addressed, same CID contract as IPFS blocks).
        // The TorrentElement owns its own CoroutineScope(supervisor) internally;
        // cleanup is via close() in the finally block.
        val torrentElement = TorrentElement(
            parentJob = coroutineContext[kotlinx.coroutines.Job],
            reactorContext = htxElement + muxReactor + nioSupervisor,
        )
        torrentElement.open()
        HostSystem.err("[OROBOROS] TorrentElement open — torrent:// via HTX/TLS + uTP datagrams")

        // ── The store: CAS-collapsed Couch (rev hash = body blob CID) over the forge-home CAS ──
        // Built before the HTTP tier so the server can host the PWA and the build out of it.
        // fileOps was created above (the KeyMux harness lane shares it).
        // This selects the host-filesystem CAS backend. UserspaceBtrfs worlds below
        // use FileOperations independently of whether the host filesystem is Btrfs.
        val casRootPath = fileOps.resolvePath(forgeHome.absolutePath, "cas")
        val ipnsNode = ipnsNode(oroborosDir, ownIpns)
        val casBacking = withContext(Dispatchers.IO) {
            ipnsNode.open()
            borg.trikeshed.btrfs.JvmFilesystemTypeProbe.probe(casRootPath)
        }
        val casSelection = (HostSystem.getenv("TRIKESHED_CAS") ?: "pack").trim().lowercase()
        var btrfsCasStore: borg.trikeshed.btrfs.BtrfsReflinkStore? = null
        val casStore: borg.trikeshed.job.CasStore = withContext(Dispatchers.IO) {
            when (casSelection) {
                "btrfs" -> {
                    val store = try {
                        borg.trikeshed.btrfs.BtrfsReflinkStore(
                            rootDir = casRootPath,
                            fileOps = fileOps,
                            processOps = borg.trikeshed.userspace.nio.channels.spi.JvmProcessOperations(),
                            refCounter = borg.trikeshed.reflink.InMemoryReferenceCounter(),
                            fsProbe = borg.trikeshed.btrfs.JvmFilesystemTypeProbe,
                        )
                    } catch (t: Throwable) {
                        HostSystem.err("[OROBOROS] CAS STORE REFUSED: TRIKESHED_CAS=btrfs but $casRootPath is not on btrfs — ${t.message}")
                        HostSystem.err("[OROBOROS] BOOT ABORTED: no silent fallback to FileCasStore (mission-002 decision D6).")
                        exitProcess(1)
                    }
                    btrfsCasStore = store
                    store
                }
                "pack" -> borg.trikeshed.job.PackCasStore(fileOps, casRootPath.toString())
                "file" -> FileCasStore(fileOps, casRootPath)
                else -> {
                    HostSystem.err("[OROBOROS] BOOT ABORTED: TRIKESHED_CAS='$casSelection' is not a known store (expected 'pack', 'btrfs' or 'file').")
                    exitProcess(1)
                }
            }
        }
        HostSystem.err(
            "[OROBOROS] CAS STORE SELECTED: ${casStore::class.java.name} casRoot=$casRootPath " +
                    "TRIKESHED_CAS=$casSelection fstype=${casBacking?.first ?: "<undeterminable>"} " +
                    "source=${casBacking?.second ?: "<undeterminable>"}"
        )
        val sharedContext = openSharedContext(casStore)
        // The agent's own breadcrumb index ranks through the facet memory the shared context answers projections
        // with: a record it kept and a document a peer pinned with the same bytes are one document facet.
        val breadcrumbContexts = borg.trikeshed.agent.modelmux.SharedContextRoot.breadcrumbs(
            sharedContext, casStore,
            borg.trikeshed.agent.modelmux.BreadcrumbFileStore(
                fileOps, fileOps.resolvePath(forgeHome.absolutePath, "modelmux", "breadcrumbs"),
            ),
        )
        // The D13 MATERIALIZE surface exists only when the btrfs store is live: reflinkReorganize
        // is a BtrfsReflinkStore member, absent from the CasStore base class.
        val casReflinkWire = btrfsCasStore?.let {
            borg.trikeshed.forge.server.CasReflinkWire(it, casRootPath).also { _ ->
                HostSystem.err(
                    "[OROBOROS] CAS reflink routes armed: " +
                            borg.trikeshed.forge.server.CasReflinkWire.ROUTES.joinToString(" ") { r -> "${r.first} ${r.second}" }
                )
            }
        }
        // One selected storage owner feeds the existing primary Couch consumers. Format selection
        // is explicit; an existing database in another format is never silently replaced.
        val couchStorage = openCouchStorage(casStore, fileOps, forgeHome, this)
        val couchDb = couchStorage.couch
        val couchStore = couchDb.store
        val attachmentGateway = CouchAttachmentGateway(couchStore, casStore)
        val gitCouchGateway = GitCouchGateway(fileOps, attachmentGateway)
        val worktreeCouchGateway = WorktreeCouchGateway(fileOps, attachmentGateway)
        // The running build is an attachment set too (rxf-rsync lineage: classes and jars served
        // from the store). `build/…` is excluded from the worktree plane, so two narrow gateways
        // absorb exactly the live classpath: build/live/classes and build/staging/lib.
        val buildPlanes = buildPlanes(fileOps, attachmentGateway, repoDir, forgeHome)
        // ── Agent home: ~/.hermes is colocated history, not repo state — a fourth narrow gateway,
        // same shape as the build planes. Excludes are the agent's OWN install/cache material
        // (venv, tool binaries, thumbnail/image/audio caches, scratch, per-profile sandboxes) —
        // reinstallable, not "history". Everything else (sessions, skills, state.db, logs, kanban,
        // memories, cron, config) is what "teleport a clone" means: the agent's memory, not its jar.
        // Boot-absorbed, no watcher: a home directory's caches/logs churn constantly and a live
        // watch on 2.7GB of it would dwarf the repo's own file-event volume for no replication
        // benefit. The panel sync button reconciles it on demand (see GraalWire planeSyncs).
        val hermesHomeDir = File(HostSystem.getProperty("user.home") ?: error("no user.home"), ".hermes")
        val hermesHomeGateway = WorktreeCouchGateway(
            fileOps, attachmentGateway,
            prefix = borg.trikeshed.util.oroboros.HermesCorpus.PREFIX,
            excludedSegments = setOf(
                "hermes-agent", "bin", "cache", "image_cache", "audio_cache", "lsp", "plugins",
                "scratch", "sandboxes", "venv", "node_modules", "__pycache__", ".git", ".curator_backups",
            ),
            excludedPath = borg.trikeshed.util.oroboros.HermesCorpus::isTrace,
        )
        couchDb.ensureDesignDoc(vhostRoot = "docs/")
        // Declare the heading the worktree gateway has always been minting documents under. Until
        // now `projects/<repo>/…` was an id prefix nobody had declared, so the store could not say
        // what projects it held; the manifest is an ordinary document, so it replicates with them.
        borg.trikeshed.couch.Projects(couchDb).put(
            repoDir.name.lowercase(),
            mapOf("root" to repoDir.absolutePath, "prefix" to WorktreeCouchGateway.WORKTREE_PREFIX),
        )
        // Peer exchange for _replicate rides the same HTX reactor as Jules/ModelMux — no JDK client.
        val peerHttp = borg.trikeshed.couch.replicate.HttpExchange { method, url, body, contentType ->
            val req = borg.trikeshed.htx.parseHtxRequest(
                url = url,
                method = borg.trikeshed.htx.HtxMethod.valueOf(method.uppercase()),
                body = body?.let { borg.trikeshed.lib.ByteSeries(it) } ?: borg.trikeshed.htx.emptyHtxBody(),
            ).let { r -> if (contentType != null) r.copy(headers = borg.trikeshed.htx.htxHeaders("Content-Type" j contentType)) else r }
            val resp = htxElement.request(req)
            borg.trikeshed.couch.replicate.HttpReply(resp.status, resp.body.toArray())
        }
        // ── Incremental view registry (P2): every design-doc view marked
        //    `"incremental": true` gets one _changes-driven tendon (mapped-once,
        //    Trie-cached, `_local` checkpointed); `_view` reads marked views off the
        //    router's registry hook and never rescan the corpus. Unmarked views keep
        //    today's eager route, untouched.
        val incrementalViews = borg.trikeshed.couch.IncrementalViewRegistry(
            db = couchDb,
            parentJob = coroutineContext[kotlinx.coroutines.Job],
            log = { msg -> HostSystem.err("[OROBOROS] $msg") },
        )
        launch {
            incrementalViews.open()
            HostSystem.err("[OROBOROS] incremental-view registry open")
        }
        // One replicator, held by both mountings: `POST _replicate` drives it as a route, and the
        // RequestFactory's `replicate` operation drives the same object inside a batch.
        val couchReplicator = borg.trikeshed.couch.replicate.CouchReplicator(couchDb, peerHttp)
        val requestFactoryRpcTargets =
            java.util.concurrent.ConcurrentHashMap<String, borg.trikeshed.relaxfactory.RequestFactoryRpcTarget>()
        val couchWire = couchWire(couchDb, couchReplicator,
            requestFactoryRpcTargets, incrementalViews, ipnsNode)
        val reportReactorForWires = requireNotNull(couchWire.router.report)

        // Kanban HTTP server (CCEK litebike listener, no JDK networking) — starts before
        // the reactive cycle so the port is bound. Driver is available at this point.
        // The Couch wire is mounted on the same listener: `/` is the store-hosted PWA, `/trikeshed/…`
        // the 1.6/1.7 surface, `/api/…` the built-ins — one port, one reactor.
        // ── Graal console: JFR/JMX instrument cluster + sub-VM host + reactor-served RTS view.
        //    All of it rides the SAME litebike listener (extraRoutes/SSE respond seam) — the
        //    userspace uring stack stays the only channelization substrate; JFR/JMX are in-process.
        val daemonBlackboard = borg.trikeshed.graal.ConfixBlackboard.empty()
        val jvmVitals = borg.trikeshed.graal.vitals.JvmVitals().also { it.start() }
        // Guest worlds are file-based under forgeHome: a `world = true` guest gets its own btrfs
        // subvolume on disk, so what it wrote and what it snapshotted are still there next boot.
        // They shared one in-memory filesystem before, which meant every world died with the daemon.
        val vmWorldStore = borg.trikeshed.btrfs.BtrfsWorldStore.ofFiles(
            fileOps,
            borg.trikeshed.btrfs.BtrfsWorldStore.homeUnder(forgeHome.absolutePath),
            cas = couchDb.cas,
        )
        // ONE pointcut adapter over the daemon blackboard. Built here, before the Hypervisor, so
        // the Hypervisor's landings, the couch projection (installed below, in the pointcut
        // subsystem) and the graal fact tendon all read the same `flow` — the Hypervisor used to
        // build a private adapter of its own, whose landings no projection ever saw.
        val pointcutAdapter = borg.trikeshed.pointcut.PointcutBlackboardAdapter(daemonBlackboard)
        val vmHost = borg.trikeshed.vm.HypervisorVmHost(
            borg.trikeshed.graal.subvm.Hypervisor(blackboard = daemonBlackboard, adapter = pointcutAdapter, worldStore = vmWorldStore),
        )
        borg.trikeshed.vm.VmSupervisor.install(vmHost)
        val wireScope = CoroutineScope(
            ccekBinding.reactorScope.coroutineContext +
                    SupervisorJob(ccekBinding.reactorScope.coroutineContext[kotlinx.coroutines.Job]) +
                    CoroutineName("oroboros-wire")
        )
        // H1: the daemon's own blackboard is finally SERVED. The Hypervisor and the
        // pointcut adapter already write receipts into it; the wire streams them out
        // on the same litebike listener. Repair contract: seq-ordered replay, `id:`
        // on every SSE event, `since` as a query param, snapshot at /blackboard/board.
        val blackboardWire = borg.trikeshed.forge.server.BlackboardWire(daemonBlackboard, wireScope)
        // A guest's file-based world publishes onto the same database `_replicate` already moves,
        // so a VM world teleports on the couch transport rather than needing a lane of its own.
        val vmWire = borg.trikeshed.forge.server.VmWire(
            vmHost, wireScope,
            worlds = borg.trikeshed.btrfs.VmWorldTeleport(couchDb, vmWorldStore),
        )
        val hermesWire = hermesWire(config, home, repoDir, forgeHome, daemonBlackboard,
            htxElement, muxReactor, wireScope, vmWorldStore, fileOps, breadcrumbContexts)
        val piWire = piWire(config, htxElement, muxReactor, wireScope, breadcrumbContexts)
        // ── Project DBs: dropped hierarchies as their own couch databases (shared CAS) ──
        val projectDbRegistry = borg.trikeshed.forge.server.ProjectDbRegistry(COUCH_DB_NAME)
        // ── Memory store + ISAM index layer (fs-memory Prongs 1+2) ──
        // MemoryStore composes the existing CAS+Couch into the paper's
        // memory store M. MemoryIndexLayer subscribes to mutations and
        // maintains taxonomy/temporal/provenance ISAM routes.
        // Declared BEFORE graalWire: the density route reads its live lineIndex.
        val memoryStore = memoryStore(casStore, couchStore, daemonBlackboard, fileOps, forgeHome.absolutePath)
        val memoryIndex = borg.trikeshed.memory.MemoryIndexLayer(memoryStore)
        val couchIndexBridge = borg.trikeshed.memory.CouchIndexBridge(attachmentGateway, memoryIndex)
        HostSystem.err("[OROBOROS] MemoryStore + MemoryIndexLayer: ${memoryIndex.route(borg.trikeshed.memory.IndexKind.Taxonomy).entryCount} taxonomy entries")

        // ── Reactive git-state hub: JvmFileWatchReactorElement watches .git/**
        //    and feeds the GitCouchGateway + git-state cache. This IS the
        //    choreography — coroutine pipelines that react to filesystem
        //    events, not blocking ProcessBuilder calls. ──
        val gitState = GitStateCache(repoDir)
        val cycleTriggers = Channel<Unit>(Channel.CONFLATED)

        // ── Composable Reconcile Elements (CCEK) ──
        val worktreeReconcileElement = worktreeReconciliation(
            repoDir, worktreeCouchGateway, couchIndexBridge, memoryStore, attachmentGateway,
            casStore, gitState,
        )

        val graalWire = borg.trikeshed.forge.server.GraalWire(
            jvmVitals,
            couchStore,
            reportReactorForWires,
            CoroutineScope(wireScope.coroutineContext + worktreeReconcileElement),
            couchDb,
            vmHost,
            attachmentGateway,
            projectDbs = projectDbRegistry,
            memoryStore = memoryStore,
            pointcuts = pointcutAdapter,
            // The panel sync button reconciles the hermes home plane beside the worktree:
            // its boot absorb is the only other pass it ever gets, and filenodes missing
            // from disk otherwise survive in the terrain until the daemon restarts.
            planeSyncs = if (hermesHomeDir.isDirectory()) listOf {
                hermesHomeGateway.reconcile(
                    hermesHomeDir.absolutePath, "oroboros",
                    gitState.headSha(), HostSystem.currentTimeMillis(),
                )
            } else emptyList(),
        )

        // ── BeliefBagElement: the daemon-owned NarseseBag (AIKR belief bound) ──
        // Flagged (--belief-bag / TRIKESHED_BELIEF_BAG=1) while phases P3..P8 land.
        // Evidence spills to the SAME forge-home CAS the store uses; the WAL rides
        // .oroboros (a ForgeHome-reserved prefix). DecayTick = daily curation pulse.
        val beliefBagEnabled = "--belief-bag" in args || HostSystem.getenv("TRIKESHED_BELIEF_BAG") == "1"
        val beliefBag: borg.trikeshed.narsese.BeliefBagElement? = if (beliefBagEnabled) {
            val walDir = File(Files.resolvePath(forgeHome, ".oroboros")).apply { mkdirs() }
            val bag = borg.trikeshed.narsese.BeliefBagElement(
                capacity = 4096,
                cas = casStore,
                wal = borg.trikeshed.couch.isam.JvmDurableAppendLog(jfile(File(Files.resolvePath(walDir, "belief.wal")))),
                decayFn = { b -> borg.trikeshed.narsese.AttentionEconomy.decay(b) },
                priorityFloor = borg.trikeshed.narsese.CurationState.STALE.floor,
                parentJob = coroutineContext[kotlinx.coroutines.Job],
            )
            bag.open()
            launch(Dispatchers.Default) {
                while (isActive) {
                    delay(24 * 3600 * 1000L)
                    bag.intake.send(borg.trikeshed.narsese.BeliefIntake.DecayTick)
                }
            }
            HostSystem.err("[OROBOROS] BeliefBag open — ${bag.size} beliefs (capacity 4096, WAL ${walDir}/belief.wal)")
            bag
        } else null

        // The NARS curation loop, closed: review (induction) + render (bounded MEMORY
        // file, forge-homed — the ~/.hermes swap stays an explicit later step) + the
        // curation ledger (every belief event lands as a Rete-visible blackboard fact).
        val turnReview: borg.trikeshed.narsese.TurnReviewElement? = beliefBag?.let { bag ->
            val r = borg.trikeshed.narsese.TurnReviewElement(bag, parentJob = coroutineContext[kotlinx.coroutines.Job])
            r.open()
            r
        }
        val hermesMemoryFiles: borg.trikeshed.memory.HermesMemoryFiles? = beliefBag?.let { bag ->
            val files = borg.trikeshed.memory.HermesMemoryFiles(
                bag = bag,
                memoriesDir = File(Files.resolvePath(forgeHome, "memories")),
                evaluatorCid = borg.trikeshed.job.ContentId.of("oroboros-session".encodeToByteArray()),
            )
            // session start: user edits are authoritative evidence, then freeze the render
            launch(Dispatchers.IO) {
                val deltas = files.ingestUserEdits()
                if (deltas > 0) HostSystem.err("[OROBOROS] MEMORY.md user edits re-ingested: $deltas deltas")
            }
            files
        }
        // ── Curation receipts: one per (kind, angular), and each one SHOWS the
        // belief. Subscribed HERE, before any suspension point, because the
        // event flow has no replay and the boot seed mints ~1k beliefs early.
        // The expression comes from whoever knows it — the mint's own gloss,
        // the bag's remembered gloss, the rete's firing gloss, the hermes gloss
        // table, or the rete's registered terms — plus the resident signal's
        // relation/evidence/cids so a receipt can be linked by identity. The
        // rete is built later and arrives through [receiptRete].
        var receiptRete: borg.trikeshed.narsese.CausalityReteElement? = null
        if (beliefBag != null) {
            launch {
                beliefBag.beliefEvents.collect { ev ->
                    val (kind, angular, eventGloss) = when (ev) {
                        is borg.trikeshed.narsese.BeliefEvent.Minted -> Triple("minted", ev.angular, ev.gloss)
                        is borg.trikeshed.narsese.BeliefEvent.Revised -> Triple("revised", ev.angular, ev.gloss)
                        is borg.trikeshed.narsese.BeliefEvent.Attended -> Triple("attended", ev.angular, null)
                        is borg.trikeshed.narsese.BeliefEvent.Evicted -> Triple("evicted", ev.angular, null)
                        is borg.trikeshed.narsese.BeliefEvent.Contradicted -> Triple("contradicted", ev.angular, null)
                    }
                    val rete = receiptRete
                    val signal = beliefBag.signalOf(angular)
                    val terms = rete?.termsOf(angular)
                    val expression = eventGloss
                        ?: beliefBag.glossOf(angular)
                        ?: rete?.glossOf(angular)
                        ?: hermesMemoryFiles?.glossOf(angular)
                        ?: terms?.let { "${it.a} --> ${it.b}" }
                    val receipt = linkedMapOf<String, Any?>(
                        "event" to kind, "angular" to angular.toString(), "actor" to "curator-pure",
                    )
                    if (expression != null) receipt["expression"] = expression
                    if (terms != null) { receipt["subject"] = terms.a; receipt["object"] = terms.b }
                    if (signal != null) {
                        receipt["relation"] = signal.relation.name
                        receipt["expectation"] = borg.trikeshed.narsese.Nal.truthOf(signal.evidence).expectation()
                        receipt["evidence"] = mapOf("positive" to signal.evidence.positive, "negative" to signal.evidence.negative)
                        receipt["subjectCid"] = signal.subjectCid
                        receipt["objectCid"] = signal.objectCid
                        receipt["provenanceCid"] = signal.provenanceCid
                    }
                    daemonBlackboard.put("narsese/curation/$kind/${angular.toString(16)}", receipt, "oroboros")
                }
            }
        }

        // Shared, live, queryable KIF bank — nal-kif/construction-kif/legal-kif
        // all assert here (in addition to their write-only, provenance-only
        // blackboard landing), so SparqlKifMcpServer-style pattern queries
        // (kif.query semantics) over `sparql.query`/`kif.sparqlSelect` can
        // actually find them. Also backs state.freeze/thaw's persistence.
        // One bank rather than three: the predicate vocabularies (causal
        // relation/subject/object for NAL, cites/holding/party for legal)
        // don't collide, and a single bank is what lets the legal tribunal's
        // evidence-bank query (below) see everything ingested so far. The
        // curator banks its SUMO spine + assessed impulses HERE too — one
        // bank, not a wire twin and an impulse twin each hoarding their own.
        val kifBank = borg.trikeshed.kif.KifKnowledgeBase()
        // ── CausalityReteElement + CuratorImpulseElement: the LIVE rete over the
        // bag (eternal truths at discounted support, minimum-understanding floor)
        // and the curator-impulse teaching recipient (hindsight replay → SUMO/KIF
        // banked knowledge → bag signals). Both ride the belief-bag flag; rules
        // and impulses are fed by callers (forge routes / curation pulses).
        val causalityRete: borg.trikeshed.narsese.CausalityReteElement? = beliefBag?.let { bag ->
            val r = borg.trikeshed.narsese.CausalityReteElement(
                bag,
                rules = borg.trikeshed.lib.emptySeriesOf(),
                parentJob = coroutineContext[kotlinx.coroutines.Job],
            )
            r.open()
            r
        }
        // ONE curator: the same element serves the BeliefWire teach/query routes
        // AND the hermes feeder below — rete-registered, kifBank-banked.
        val curatorImpulse: borg.trikeshed.narsese.CuratorImpulseElement? = beliefBag?.let { bag ->
            val c = borg.trikeshed.narsese.CuratorImpulseElement(
                bag,
                rete = causalityRete,
                knowledgeBank = kifBank,
                // The pinned SUMO corpus (Merge + Mid-level) is the ground theory; the
                // 13-category spine is only the offline-cold-cache fallback.
                groundTheory = borg.trikeshed.ontology.SumoCorpus.text().ifBlank { borg.trikeshed.ontology.SumoOntology.emitUpperKif() },
                // Same tee shape as councilKifSink below: taught axioms land in the `kif-ledger/`
                // couch plane the boot thaw re-asserts from. Without this the curator's whole
                // knowledge — everything /api/beliefs/teach banks — died at every restart while
                // council's and legal.ingest's survived, because only they wrote the ledger.
                ledger = { kif ->
                    val cid = borg.trikeshed.job.ContentId.of(kif.encodeToByteArray())
                    runCatching {
                        couchDb.put(
                            "kif-ledger/${cid.hex}",
                            mapOf("kif" to kif, "source" to "curator.teach", "atMs" to HostSystem.currentTimeMillis()),
                            null,
                        )
                    }.onFailure { HostSystem.err("[OROBOROS] curator kif-ledger write failed (non-fatal): ${it.message}") }
                    // The couch write above does not survive a restart — casBacked rebuilds its
                    // head projection empty at every boot, so the bodies persist in CAS but
                    // nothing can find them again. The file is the durable plane.
                    runCatching { borg.trikeshed.narsese.NarsDurableLedger.appendAxiom(forgeHome, kif) }
                        .onFailure { HostSystem.err("[OROBOROS] curator axiom ledger write failed (non-fatal): ${it.message}") }
                },
                parentJob = coroutineContext[kotlinx.coroutines.Job],
            )
            c.open()
            c
        }
        receiptRete = causalityRete
        val beliefWire = if (beliefBag != null && turnReview != null) {
            // W5.3: wire the live curator element into the beliefs HTTP surface
            // (teach/query routes) — the SAME element the feeder teaches.
            borg.trikeshed.forge.server.BeliefWire(beliefBag, turnReview, hermesMemoryFiles, curatorImpulse)
        } else null
        if (causalityRete != null) {
            HostSystem.err("[OROBOROS] CausalityRete live: ${causalityRete.rules.size} eternal rules; CuratorImpulse bank: ${curatorImpulse?.knowledgeBank?.size() ?: 0} axioms (ground theory ${curatorImpulse?.theorySize ?: 0} forms, impulses are ${curatorImpulse?.agentClass})")
            launch {
                causalityRete.firings.collect { firing ->
                    daemonBlackboard.put(
                        "narsese/rete/firing/${firing.firingCid.hex}",
                        mapOf(
                            "event" to "dependent-rete-firing",
                            "firingCid" to firing.firingCid.value,
                            "ruleCid" to firing.sourceRuleCid.value,
                            "antecedent" to firing.rule.antecedent,
                            "consequent" to firing.rule.consequent,
                            "dependence" to firing.dependence.name,
                        ),
                        "oroboros",
                    )
                }
            }
            launch {
                while (isActive) {
                    causalityRete.fireLive()
                    delay(250L)
                }
            }
        }

        // ── Hermes design distillation + incremental curator feeding (I1/I2) ──
        // The trusted ledger/state.db reader remains CuratorImpulseFeeder. At boot its snapshot
        // is distilled into CAS/Line-CAS design docs; then one structured coroutine follows
        // MAX(messages.id) checkpoints. Checkpoint state is local/frozen Series data — no daemon
        // registry. All file/sqlite/store blocking work is dispatched to IO inside the helpers.
        // The wikiLane holder is the seam between this loop and the WIKI_CONSOLIDATE
        // registration below (which runs after brainClient/moduleContext exist): the
        // registration arms slot 0, the loop polls it — null just means "not wired yet".
        val wikiLane = arrayOf<borg.trikeshed.lcnc.LcncNodeRunner?>(null)
        val curatorFollowJob = curatorFollow(
            curatorImpulse, hermesHomeDir, memoryStore, couchStore, casStore, daemonBlackboard, wikiLane,
        )

        // ── PatchWire: the ComfyUI patch-panel backend — full KeyMux/ModelMux access
        // (provider-neutral, key-leased, values never cross the wire) + multiproject
        // scope mounting (drag a directory: git repo → projects/<name>/, else
        // assets/<name>/ — the blackboard's taxonomy prefixes are the subscope seams).
        val projectScopes = borg.trikeshed.forge.server.ProjectScopes(
            fileOps, attachmentGateway, couchIndexBridge, casStore, beliefBag,
            projectDbs = projectDbRegistry,
            ledgerFile = jfile(File(Files.resolvePath(forgeHome, ".oroboros/projects.tsv"))),
            filesRoot = jfile(File(Files.resolvePath(forgeHome, "files"))),
        )
        val projectDbWire = borg.trikeshed.forge.server.ProjectDbWire(projectDbRegistry, uploads = projectScopes)
        val projectMiner = borg.trikeshed.forge.server.ProjectMiner(
            projectDbRegistry, projectScopes, casStore, beliefBag, jfile(File(Files.resolvePath(forgeHome, "files"))),
        )
        // ── Brain pin = Hermes' live session. Hermes records, per session, the
        // model and the resolved runtime it actually runs on
        // (sessions.model_config.gateway_runtime: provider, base_url, api_mode)
        // and ranks sessions by real recency (hermes_state.py; mirrored in
        // HermesActiveSession). The daemon runs under the same $HERMES_HOME as
        // the operator's CLI, so the row Hermes would resume IS the model
        // instance to borrow — it follows every `/model` switch with no second
        // config. The key resolves the way Hermes resolves it — the provider's
        // env vars, then its credential pool — which here is the KeyMux
        // `llm.<provider>.key` lane; a runtime that names only a provider gets
        // its base url from `llm.<provider>.base_url` the same way. No session,
        // an api_mode BrainClient cannot speak (it posts /chat/completions), or
        // a key that does not resolve → the roster, with the reason logged.
        // (GLM_MODEL was never a Hermes variable; only GLM_BASE_URL is — the
        // zai base-url override — and the session row already reflects it.)
        val brainErrorSink = borg.trikeshed.modelmux.JvmBrainErrorSink(forgeHome)
        // LIVE: the ladder below runs at boot AND again on the first call after
        // Hermes' state.db / auth.json / .env change (HermesWatch), so the brain
        // follows a `/model` switch or a key rotation without a restart.
        val hermesWatch = borg.trikeshed.hermes.HermesWatch.default()
        // One meter for every mux. Hermes history contributes usage; only provider HTTP
        // observations can establish exhausted capacity.
        val quotaLegion = borg.trikeshed.agent.modelmux.QuotaLegion(windowMs = borg.trikeshed.agent.modelmux.QuotaLegion.DAY_MS)
        fun refreshQuotaLegion() {
            val now = HostSystem.currentTimeMillis()
            borg.trikeshed.hermes.HermesModelUsageJdbc.install()
            val db = borg.trikeshed.hermes.HermesModelUsage.stateDb()
            quotaLegion.refresh(borg.trikeshed.hermes.HermesModelUsage.ledgerRows(db), now)
            HostSystem.err(
                "[OROBOROS] quota legion from hermes ledger ($db): " +
                        quotaLegion.ledgerUsage.entries.joinToString("; ") { (p, usage) ->
                            "$p observed peak ${usage.provenLimit}/day, recent usage ${quotaLegion.ledgerSpentFor(p, now)}"
                        }.ifEmpty { "no provider rows — every key unmetered" },
            )
        }
        refreshQuotaLegion()

        // ── mux/* blackboard home: the working models/keys land here REDACTED
        // (keys by fingerprint, never keyId — see MuxBlackboardProjection) on
        // every reactor state publication. The board, not hermes' state.db,
        // is the open inspectable answer to "what is the daemon running on".
        launchMuxBlackboardHome(muxReactor, quotaLegion, daemonBlackboard)

        suspend fun buildBrain(): Pair<borg.trikeshed.modelmux.BrainClient, Map<String, Any?>> {
            refreshQuotaLegion()
            val configuredModels = hermesCredentials.configuredModels().view.filter {
                it.apiMode == "chat_completions" && it.baseUrl.isNotBlank() &&
                    runCatching { baseKeyMux.get("llm.${it.provider}.key") }.getOrNull()?.isNotBlank() == true
            }
            val hermesSession = borg.trikeshed.hermes.HermesActiveSession.current()
            val hermesProvider = hermesSession?.runtime?.provider
            // baseKeyMux, not keyMux: this resolves the NEXT pin, so it must not
            // read back through the overlay this same refresh set last time.
            suspend fun hermesLane(field: String): String? = hermesProvider?.let { provider ->
                kotlinx.coroutines.withContext(Dispatchers.IO) {
                    runCatching { baseKeyMux.get("llm.$provider.$field") }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                }
            }
            val hermesKey = hermesLane("key")
            val hermesBaseUrl = hermesSession?.runtime?.baseUrl ?: hermesLane("base_url")
            val hermesModel = hermesSession?.model?.takeIf { it.isNotBlank() }
            val hermesPinReason: String = when {
                hermesSession == null -> "no session row in ${borg.trikeshed.hermes.HermesActiveSession.stateDb()}"
                hermesModel == null -> "session ${hermesSession.id} carries no model"
                hermesProvider == null -> "session ${hermesSession.id} has no resolved runtime provider"
                !hermesSession.runtime.speaksChatCompletions ->
                    "session ${hermesSession.id} runs api_mode=${hermesSession.runtime.apiMode}, not chat_completions"
                hermesBaseUrl == null -> "no base url for provider $hermesProvider (session row nor llm.$hermesProvider.base_url)"
                hermesKey == null -> "no key resolves for llm.$hermesProvider.key"
                else -> ""
            }
            // Rung 2 (2026-09-04): the launch Hermes makes when no session row
            // pins a runtime — its resume path "falls back to ambient config
            // resolution", i.e. the profile's config.yaml model block
            // (HermesConfigDefault mirrors resolve_runtime_provider). Until this
            // rung existed the daemon fell from a pin-less row straight to the
            // static roster, and the model Hermes runs in this profile was never
            // the model the daemon ran.
            val hermesHome = borg.trikeshed.hermes.HermesModelUsage.hermesHome()
            val configOutcome: borg.trikeshed.hermes.HermesConfigDefault.Outcome? =
                if (hermesPinReason.isEmpty()) null
                else borg.trikeshed.hermes.HermesConfigDefault.resolve(hermesHome, keyLane = { provider, field ->
                    kotlinx.coroutines.withContext(Dispatchers.IO) {
                        runCatching { baseKeyMux.get("llm.$provider.$field") }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                    }
                })
            val configLaunch = (configOutcome as? borg.trikeshed.hermes.HermesConfigDefault.Outcome.Pinned)?.launch
                ?.takeIf { it.apiMode == "chat_completions" }
            val configReason: String? = when (configOutcome) {
                null -> null
                is borg.trikeshed.hermes.HermesConfigDefault.Outcome.Unavailable -> configOutcome.reason
                is borg.trikeshed.hermes.HermesConfigDefault.Outcome.Pinned ->
                    if (configLaunch == null) "config default ${configOutcome.launch.model} runs api_mode=${configOutcome.launch.apiMode}, not chat_completions" else null
            }
            val built: borg.trikeshed.modelmux.BrainClient = if (hermesPinReason.isEmpty() && hermesSession != null && hermesModel != null && hermesBaseUrl != null && hermesKey != null) {
                val seen = borg.trikeshed.platform.InstantShim.ofEpochMilli((hermesSession.recencyEpochSeconds * 1000).toLong())
                HostSystem.err(
                    "[OROBOROS] Brain PINNED to hermes session ${hermesSession.id} (${hermesSession.source}, " +
                            (if (hermesSession.isOpen) "open" else "ended") + ", last activity $seen, ${hermesSession.apiCallCount} api calls): " +
                            "$hermesModel @ $hermesBaseUrl (provider=$hermesProvider, api_mode=${hermesSession.runtime.apiMode ?: "chat_completions"}, ${hermesSession.ledger})",
                )
                // The host Hermes launches against IS an operator-configured provider
                // host: admit it through the substrate's deny-by-default egress gate
                // the same way a configured base_url is (EgressAllowlist.allowUrl).
                // 2026-09-04: the first config-default pin, mimo-v2.5 @ opencode.ai,
                // resolved a key and built a correct request, then died one layer
                // down — "egress denied by substrate: opencode.ai:443" — because
                // that host is Hermes' to know, not the HarnessRegistry's.
                borg.trikeshed.userspace.nio.channels.spi.EgressAllowlist.allowUrl(hermesBaseUrl)
                borg.trikeshed.modelmux.BrainClient(apiKey = hermesKey, base = hermesBaseUrl.trimEnd('/'), model = hermesModel, errorSink = brainErrorSink, quotaLegion = quotaLegion)
            } else if (configLaunch != null) {
                HostSystem.err(
                    "[OROBOROS] Brain PINNED to hermes config default (${configLaunch.configFile}; session pin unavailable: $hermesPinReason): " +
                            "${configLaunch.model} @ ${configLaunch.baseUrl} (provider=${configLaunch.provider}, api_mode=${configLaunch.apiMode}, key from ${configLaunch.keySource})",
                )
                borg.trikeshed.userspace.nio.channels.spi.EgressAllowlist.allowUrl(configLaunch.baseUrl)
                borg.trikeshed.modelmux.BrainClient(apiKey = configLaunch.apiKey, base = configLaunch.baseUrl, model = configLaunch.model, errorSink = brainErrorSink, quotaLegion = quotaLegion)
            } else if (configuredModels.isNotEmpty()) {
                val specs = configuredModels.map {
                    borg.trikeshed.userspace.nio.channels.spi.EgressAllowlist.allowUrl(it.baseUrl)
                    borg.trikeshed.modelmux.BrainClient.EndpointSpec(
                        name = "hermes:${it.provider}", envVar = "", base = it.baseUrl,
                        model = it.model, provider = it.provider, contextWindow = it.contextWindow,
                    )
                }
                val importedMux = borg.trikeshed.agent.modelmux.ModelMux(baseKeyMux) {
                    quota(quotaLegion)
                    defaultModel(specs.first().model)
                    for (spec in specs) model(spec.model, setOf("chat", "tools"), baseUrl = spec.base,
                        provider = spec.provider, contextWindow = spec.contextWindow)
                }
                HostSystem.err("[OROBOROS] Brain uses Hermes configured endpoint ${specs.first().model}; selected protocol unavailable: $configReason")
                borg.trikeshed.modelmux.BrainClient(
                    keyMux = baseKeyMux, modelMux = importedMux, endpointSpecs = specs,
                    errorSink = brainErrorSink, quotaLegion = quotaLegion,
                )
            } else {
                HostSystem.err("[OROBOROS] Brain on the provider roster — hermes session pin unavailable: $hermesPinReason; config default unavailable: $configReason")
                borg.trikeshed.modelmux.BrainClient(errorSink = brainErrorSink, keyMux = keyMux, quotaLegion = quotaLegion)
            }
            val account: Map<String, Any?> = mapOf(
                "pin" to when {
                    hermesPinReason.isEmpty() ->
                        mapOf("source" to "session", "model" to hermesModel, "baseUrl" to hermesBaseUrl, "provider" to hermesProvider, "sessionId" to hermesSession?.id)
                    configLaunch != null ->
                        mapOf("source" to "config", "model" to configLaunch.model, "baseUrl" to configLaunch.baseUrl, "provider" to configLaunch.provider, "configFile" to configLaunch.configFile, "keySource" to configLaunch.keySource)
                    configuredModels.isNotEmpty() -> configuredModels.first().let {
                        mapOf("source" to "configured-provider", "model" to it.model, "baseUrl" to it.baseUrl, "provider" to it.provider)
                    }
                    else -> null
                },
                "reason" to listOfNotNull(hermesPinReason.ifEmpty { null }, configReason).joinToString("; ").ifEmpty { null },
                "builtAtMs" to HostSystem.currentTimeMillis(),
            )
            return built to account
        }
        val brainClient = borg.trikeshed.hermes.LiveBrainClient(hermesWatch, { buildBrain() }, buildBrain())
        // The runner registry is assembled below; the publisher reads it late.
        val lcncRunnersRef = java.util.concurrent.atomic.AtomicReference<Map<String, borg.trikeshed.lcnc.LcncNodeRunner>>(emptyMap())
        // ── The ONE production network and its registry, hoisted above the publisher: the
        //    panels plane (LcncPublisher → PanelFactBridge) writes into it, the couch tendon
        //    and the modules below write into it, and the KIF tee reads every op off it.
        val reteProductions = borg.trikeshed.dag.ReteProductionRegistry()
        val rete = borg.trikeshed.dag.ReteNetwork(reteProductions)
        // KIF half of the join: every fact the network applies is projected into `kifBank`
        // (and un-projected on retract) by one observer — attached before any bridge opens,
        // so nothing needs priming; `prime` is still called once after the bridges open below,
        // idempotently, as the belt to this brace.
        val (kifTee, kifTeeDisposer) = borg.trikeshed.dag.KifTee.attach(rete, kifBank)
        val lcncPublisher = borg.trikeshed.lcnc.LcncPublisher(daemonBlackboard, { lcncRunnersRef.get() }, attachmentGateway, rete, kifBank)
        // The stored set of prompts (Forge genesis, Cut P): versions are CAS citizens, heads are
        // `prompts/<name>` attachments + `lcnc/prompt/<name>` on the board, the ledger under the
        // forge home is what a restart re-reads (the couch index is per boot).
        val promptStore = borg.trikeshed.lcnc.PromptStore(
            attachmentGateway, casStore, borg.trikeshed.lcnc.PromptStore.ledgerFile(forgeHome), lcncPublisher,
        ) { HostSystem.currentTimeMillis() }
        // The program ledger (AutoTools notion, Cut 0): a published program's bytes are CAS
        // citizens already, but its `panels/<name>` head lives in a couch index rebuilt per boot;
        // <forgeHome>/programs/ledger.jsonl is what a restart re-reads, and the head is re-filed
        // and republished as `lcnc/program/<name>` at the same programCid.
        val programLedger = borg.trikeshed.lcnc.ProgramLedger(
            attachmentGateway, casStore, borg.trikeshed.lcnc.ProgramLedger.ledgerFile(forgeHome), lcncPublisher,
        ) { HostSystem.currentTimeMillis() }
        // The mounted projects as one document set (Forge genesis, Cut F/D): the legos and the
        // document surface read the same seam.
        val projectCorpus = borg.trikeshed.forge.server.JvmProjectCorpus(projectDbRegistry, projectScopes, projectMiner,
            primary = borg.trikeshed.forge.server.PrimaryProjectBinding(repoDir.name.lowercase(),
                WorktreeCouchGateway.WORKTREE_PREFIX, couchStore, attachmentGateway, repoDir.absolutePath,
                reader = casStore as? borg.trikeshed.job.BoundedCasReader))
        // Workspace snapshots (Forge genesis, Cut C): the whole workspace named as one cid, a lineage
        // in <forgeHome>/snapshots/ledger.jsonl, the head as lcnc/snapshot/head.
        val snapshotService = borg.trikeshed.forge.server.WorkspaceSnapshotService(
            daemonBlackboard, casStore, attachmentGateway, promptStore, projectDbRegistry, lcncPublisher,
            borg.trikeshed.forge.server.WorkspaceSnapshotService.ledgerFile(forgeHome),
        )
        val patchWire = borg.trikeshed.forge.server.PatchWire(
            brain = brainClient,
            scopes = projectScopes,
            attachments = attachmentGateway,
            publisher = lcncPublisher,
            prompts = promptStore,
            corpus = projectCorpus,
            snapshots = snapshotService,
            programs = programLedger,
            muxContext = htxElement + muxReactor + breadcrumbContexts + sharedContext,
            mountScope = wireScope,
            miner = projectMiner,
            catalogProvider = { requireNotNull(muxReactor.modelMux()) },
            sessionSnapshot = jfile(File(Files.resolvePath(forgeHome, ".modelmux/sessions.json"))),
            blackboard = daemonBlackboard,
            repository = repoDir.path,
            pointcuts = pointcutAdapter,
        )
        // (boot mounts + ledger remount happen below, once the Rete tendon hook is armed)
        // ── Dynamic modules: Rete (hoisted — the tendon below feeds it) + production
        //    registry + CoW route registry + supervisor (proxy ctors: app CP first,
        //    then a fresh URLClassLoader over build/live/classes — hotswapFeed's tree,
        //    so a class compiled after boot attaches without a bounce).
        // (reteProductions / rete are constructed above the LcncPublisher, which needs them)
        val moduleRoutes = borg.trikeshed.module.ModuleRouteRegistry()
        // Workgroup discovery has its own signed name; publishing it cannot replace the site's IPNS head.
        val lcncIpnsNode = ipnsNode(oroborosDir, ownIpns, "lcnc-ipns.journal").also { it.open() }
        val moduleScope = CoroutineScope(
            ccekBinding.reactorScope.coroutineContext +
                    SupervisorJob(ccekBinding.reactorScope.coroutineContext[kotlinx.coroutines.Job]) +
                    CoroutineName("oroboros-module") + lcncIpnsNode
        )
        // Spec §3.1 production wiring: ONE stored-program resolver — the offered
        // presets (the panels/ attachment namespace was rooted out 2026-08-27
        // with the browser editor) — shared by module program runs
        // (/api/lcnc/run {program}) and webhook node dispatch.
        // THE LOADER IS THE BLACKBOARD (LcncPublisher.load): the source — a preset,
        // then the user's `panels/<name>` attachment — keeps `lcnc/program/<name>`
        // fresh, and the entry is what the run seam obeys.
        val storedProgramLoader: suspend (String) -> borg.trikeshed.lcnc.LcncProgram? = { name -> lcncPublisher.load(name) }
        val confixIsam = if (casStore.durability == borg.trikeshed.userspace.nio.file.spi.StorageDurability.DURABLE) {
            borg.trikeshed.couch.isam.ConfixIsamElement(moduleScope, couchStore.changes,
                fileOps.resolvePath(forgeHome.toString(), "confix/couch"), fileOps, casStore,
                dictionaryCodec = { borg.trikeshed.isam.ZstdDictionaryCodec(it) },
                primary = couchStorage.takeIf { it.dense != null })
        } else null
        val moduleContext = borg.trikeshed.module.ModuleContext(
            couch = couchDb,
            rete = rete,
            productions = reteProductions,
            beliefBag = beliefBag,
            turnReview = turnReview,
            blackboard = daemonBlackboard,
            casStore = casStore,
            attachments = attachmentGateway,
            routes = moduleRoutes,
            scope = moduleScope,
            clock = { HostSystem.currentTimeMillis() },
            stateDir = jfile(forgeHome),
            muxContext = htxElement + muxReactor,
            ccekBinding = ccekBinding,
            programLoader = storedProgramLoader,
            kifBank = kifBank,
            narsRete = causalityRete,
            confixIsam = confixIsam,
        )
        lcncRunnersRef.set(moduleContext.lcncRunners)
        val headhunterWire = borg.trikeshed.forge.server.HeadhunterWire.open(moduleContext, brainClient, patchWire)
        requestFactoryRpcTargets["session.info"] = borg.trikeshed.relaxfactory.RequestFactoryRpcTarget { args ->
            linkedMapOf<String, Any?>(
                "db" to couchDb.info(),
                "args" to args,
                "lcnc" to linkedMapOf<String, Any?>(
                    "contracts" to borg.trikeshed.lcnc.LcncContracts.all().size,
                    "runners" to moduleContext.lcncRunners.size,
                ),
                "rpcTargets" to requestFactoryRpcTargets.keys.sorted(),
            )
        }
        moduleContext.lcncRunners.putAll(
            borg.trikeshed.lcnc.RequestFactoryNodes.registry(
                borg.trikeshed.relaxfactory.RequestFactoryProxy(
                    borg.trikeshed.relaxfactory.RelaxTransport.local(couchWire.router.requestFactory),
                ),
            ),
        )
        // Step K: the context-assembly node family is host-composed like any module's
        // runners — webhook dispatch and program runs can mint real context receipts.
        moduleContext.lcncRunners.putAll(borg.trikeshed.memory.ace.AceContextNodes.registry(daemonBlackboard))
        // P4: lawyer-bot reading seat. ONLY this runner calls BrainClient/ModelMux;
        // ConstructionReadingLoop owns deterministic CAS claim-check/fold/bag/Rete landing.
        beliefBag?.let { readingBag ->
            moduleContext.lcncRunners["read.construct"] = borg.trikeshed.narsese.ConstructionBotNode.runner(
                brain = brainClient,
                muxContext = htxElement + muxReactor,
                cas = casStore,
                bag = readingBag,
                rete = rete,
                kifSink = { kif ->
                    val cid = borg.trikeshed.job.ContentId.of(kif.encodeToByteArray())
                    daemonBlackboard.put("construction-kif/${cid.hex}", kif, "reader")
                    runCatching { kifBank.assertKif(kif) }
                },
            )
        }
        // Sub-VM module legos: tika/corenlp/camel/graalce as supervised guest evals
        // over the daemon's own hypervisor (VmSupervisor.current — VmWire's same host).
        borg.trikeshed.lcnc.SubVmLegos.register(moduleContext)
        // uring legos: the ring as palette nodes — SQE in, CQE out, through the
        // facade's probed backend; contracts in LcncContracts, one registration site.
        borg.trikeshed.lcnc.UringLegos.register(moduleContext)
        // The LIFETIME half of camel: vm.camel.up/down/routes hold a CamelContext open past the
        // run that started it, so a poller (timer:, file:, imaps:) has somewhere to live and every
        // Exchange that crosses lands on the board as camel/route/<id>/exchange.
        borg.trikeshed.lcnc.CamelRouteLegos.register(moduleContext)
        // The coding-agent lane (Forge genesis, Cut A): the host's CLIs probed once; agent.run /
        // agent.list legos and the claim worker's lane share one runner; receipts are agent/run/<runId>.
        val agentRoster = borg.trikeshed.agent.AgentCliProbe.probe(config.agents, borg.trikeshed.agent.AgentRegistry.KNOWN)
        val agentRunner = borg.trikeshed.agent.JvmAgentRunner(
            agentRoster, repoDir = jfile(repoDir), forgeHome = jfile(forgeHome), cas = casStore, attachments = attachmentGateway, blackboard = daemonBlackboard,
        )
        moduleContext.agentRuns = agentRunner
        moduleContext.lcncRunners.putAll(borg.trikeshed.lcnc.AgentNodes.registry(agentRunner) { borg.trikeshed.platform.randomUuid().toString() })
        val agentWire = borg.trikeshed.forge.server.AgentWire(
            agentRunner, daemonBlackboard, probedAtMs = HostSystem.currentTimeMillis(),
            enabledBy = if ("--agents" in args) "--agents" else if (HostSystem.getenv("TRIKESHED_AGENTS") != null) "TRIKESHED_AGENTS" else "default",
        )
        HostSystem.err("[OROBOROS] coding agents: " + agentRoster.joinToString { it.id + if (it.enabled) " " + it.version else " (" + it.why + ")" })
        borg.trikeshed.lcnc.OroborosLcncWiring.lcncStores(moduleContext, promptStore, snapshotService, projectCorpus)
        // ── hermes.lastUsed: the outcome, next to the intent ──────────
        // mux.meta answers "what is modelmux configured to select" and reports
        // selection:null. Hermes' own state.db answers "what actually replied",
        // and it is not empty. Where those two disagree, the ledger is the one
        // with completions behind it. JVM-side because the ledger is SQLite.
        // Ledger = $HERMES_HOME/state.db; `session` = the row Hermes would resume
        // (HermesActiveSession) and `brainPin` = what the daemon borrowed from it.
        moduleContext.lcncRunners["hermes.lastUsed"] = borg.trikeshed.lcnc.LcncNodeRunner { _, _ ->
            val db = borg.trikeshed.hermes.HermesModelUsage.stateDb()
            val recent = borg.trikeshed.hermes.HermesModelUsage.recent(db)
            fun row(u: borg.trikeshed.hermes.HermesModelUsage.Usage) = mapOf(
                "model" to u.model,
                "provider" to u.provider,
                "baseUrl" to u.baseUrl,
                "task" to u.task,
                "calls" to u.calls,
                "inputTokens" to u.inputTokens,
                "outputTokens" to u.outputTokens,
                "lastSeenMs" to (u.lastSeenEpochSeconds * 1000).toLong(),
            )
            val session = borg.trikeshed.hermes.HermesActiveSession.current(jfile(db))
            mapOf(
                "ledger" to db.absolutePath,
                "session" to session?.let { s ->
                    mapOf(
                        "id" to s.id,
                        "source" to s.source,
                        "open" to s.isOpen,
                        "model" to s.model,
                        "provider" to s.runtime.provider,
                        "baseUrl" to s.runtime.baseUrl,
                        "apiMode" to s.runtime.apiMode,
                        "lastActivityMs" to (s.recencyEpochSeconds * 1000).toLong(),
                        "messages" to s.messageCount,
                        "apiCalls" to s.apiCallCount,
                        "cwd" to s.cwd,
                    )
                },
                "brainPin" to brainClient.pin["pin"],
                "brainPinReason" to brainClient.pin["reason"],
                "brainPinBuiltAtMs" to brainClient.pin["builtAtMs"],
                "lastUsed" to (recent.firstOrNull()?.let(::row)),
                "recent" to recent.map(::row),
                "provenEndpoints" to borg.trikeshed.hermes.HermesModelUsage.provenEndpoints(db)
                    .map { mapOf("provider" to it.first, "baseUrl" to it.second) },
            )
        }
        // ── CCEK itself, programmable ────────────────────────────────
        // Every family above drives a PROJECTION of CCEK (board, council, legal).
        // This one drives the engine: incarnate/signal/agent/projection/recording/
        // status/drain plus context lineage, choreographed by the SAME
        // reactor-bound binding the rest of the process rides (ccekBinding above),
        // so a program addresses the live CCEK rather than a private instance.
        moduleContext.lcncRunners.putAll(
            borg.trikeshed.lcnc.CcekNodes.registry(borg.trikeshed.lcnc.CcekSeams.live(ccekBinding)),
        )
        // Belief bag, freeze/thaw and belief-field nodes retain the shared bank, rete and model context.
        registerBeliefNodes(moduleContext, hermesMemoryFiles, brainClient, kifBank)
        val language = registerCorpusLanguage(moduleContext, kifBank, causalityRete, projectCorpus,
            projectScopes, wireScope, couchDb, forgeHome, beliefBag, brainClient, htxElement + muxReactor,
            casStore, moduleScope, hermesMemoryFiles)
        val documentReviewWire = language.review
        val curationIntake = language.intake
        val tribunalHolder = language.tribunal
        // ── BrainClient decomposition as LCNC: credential.enter → prompt.chat →
        //    result.confirm. CouchKeyStore backs the credential persistence;
        //    the chatFn uses the daemon's HTX client (200/non-200 patchpoints).
        val couchKeyStore = couchKeyStore(couchDb, keyMux)
        // ModelMux for the mux.* LCNC nodes: built from the brain's full
        // provider ROSTER (the static table, un-gated) over the daemon's
        // shared KeyMux — so the panel reflects every provider this machine
        // could talk to, not the brain's runtime pin (GLM single-endpoint).
        // One key pool: every card's provider tag resolves llm.<provider>.key
        // through the same env → dotenv → harness chain keys.status reports.
        // HtxKey and MuxReactorElement are inherited from the CCEK binding.
        // Card ids must be UNIQUE. ModelMux.session takes the first entry whose id
        // matches, so a model id served by two providers is not ambiguous — the
        // second one is silently unreachable while still being listed in the panel.
        // The roster collides exactly so (z-ai/glm-5.2 under both nvidia and
        // openrouter; one hermes model under three endpoints), which is why the
        // panel offered a menu whose entries mostly failed. disambiguateModelIds
        // keeps the bare id for the first claimant and qualifies the rest.
        // LIVE: cards are rebuilt on the first mux call after Hermes' files
        // change, so the picklist shows a `/model` switch on its next open.
        suspend fun buildLcncMux(): borg.trikeshed.agent.modelmux.ModelMux {
            val liveBrain = brainClient.live()
            val pin = brainClient.pin["pin"] as? Map<*, *>
            val pinnedModel = pin?.get("model") as? String
            val pinnedProvider = pin?.get("provider") as? String
            val pinnedBase = pin?.get("baseUrl") as? String
            // catalogKeys stays IDENTICAL to the reactor-owned keyMux — the Hermes
            // pin rides hermesPinOverlay (bound once at boot) instead of a fresh
            // withBinding() chain, so MuxReactorElement.modelMux()'s `mux.keyMux
            // === keyMux()` identity check holds. setPin()/clearPin() replace the
            // whole overlay snapshot, so a provider switch cannot leave the old
            // provider's key/base_url bound alongside the new one.
            val catalogKeys = keyMux
            // Presence-only: modelKeyId is a binding path, not a secret. The
            // secret is resolved inside PinOverlaySource.read, from pinMux's
            // OWN keyMux — never fetched here.
            val pinnedSpec = if (pinnedModel != null && pinnedProvider != null && pinnedBase != null) {
                val pinLookup: Pair<borg.trikeshed.agent.modelmux.ModelMux, String>? = runCatching {
                    val pinMux = liveBrain.modelMux()
                    val pinKeyId = requireNotNull(pinMux.modelKeyId(pinnedModel)) { "Configured model has no key binding" }
                    pinMux to pinKeyId
                }.onFailure {
                    // Explicit need, not a catalog-wide exception: the pin is one
                    // optional preference over the full provider catalog below.
                    HostSystem.err("[OROBOROS] hermes pin unavailable, catalog continues without it: ${it.message}")
                }.getOrNull()
                val pinKeyMux = pinLookup?.first?.keyMux
                val pinKeyId = pinLookup?.second
                if (pinKeyMux != null && pinKeyId != null && pinKeyMux !== keyMux) {
                    hermesPinOverlay.setPin(
                        borg.trikeshed.agent.keymux.PinBinding(
                            provider = pinnedProvider,
                            baseUrl = pinnedBase,
                            keyDelegate = pinKeyMux,
                            keyId = pinKeyId,
                        ),
                    )
                    borg.trikeshed.modelmux.BrainClient.EndpointSpec(
                        name = "hermes:$pinnedProvider", envVar = "", base = pinnedBase,
                        model = pinnedModel, provider = pinnedProvider,
                        contextWindow = pinLookup?.first?.contextWindow(pinnedModel) ?: 0,
                    )
                } else {
                    if (pinKeyMux === keyMux) {
                        HostSystem.err("[OROBOROS] hermes pin resolves through the operator mux itself; skipping to avoid a recursive lookup")
                    }
                    hermesPinOverlay.clearPin()
                    null
                }
            } else {
                hermesPinOverlay.clearPin()
                null
            }
            // Cards come from Hermes FIRST — the model instances it has run on and
            // been answered by ($HERMES_HOME/state.db: sessions + session_model_usage,
            // HermesInstances) — then the static roster for whatever Hermes has not
            // touched. The live picklist prompt.chat declares (mux.models#models[].id)
            // therefore offers what actually runs here, not a hand-typed table.
            // …and only the rows THIS daemon can authenticate: a provider whose
            // `llm.<provider>.key` does not resolve here would be a dead entry in the
            // listbox, so it is reported, not offered.
            val hermesKnown = borg.trikeshed.hermes.HermesInstances.known()
            val hermesKeyed = kotlinx.coroutines.withContext(Dispatchers.IO) {
                hermesKnown.map { it.provider }.distinct().associateWith { provider ->
                    runCatching { keyMux.get("llm.$provider.key") }.getOrNull()?.isNotBlank() == true
                }
            }
            val hermesInstances = hermesKnown.filter { hermesKeyed[it.provider] == true }
            val configuredSpecs = hermesCredentials.configuredModels().view.filter {
                it.apiMode == "chat_completions" && it.baseUrl.isNotBlank() &&
                    runCatching { baseKeyMux.get("llm.${it.provider}.key") }.getOrNull()?.isNotBlank() == true
            }.map {
                borg.trikeshed.userspace.nio.channels.spi.EgressAllowlist.allowUrl(it.baseUrl)
                borg.trikeshed.modelmux.BrainClient.EndpointSpec(
                    name = "hermes:${it.provider}", envVar = "", base = it.baseUrl, model = it.model,
                    provider = it.provider, contextWindow = it.contextWindow,
                )
            }
            val hermesSpecs = (configuredSpecs + borg.trikeshed.hermes.HermesInstances.specs(hermesInstances))
                .distinctBy { it.provider to it.model }
            val hermesClaimed = hermesSpecs.mapTo(HashSet()) { it.provider to it.model }
            val staticSpecs = liveBrain.providerRoster().filterNot { (it.provider ?: it.name) to it.model in hermesClaimed }
            val discovered = hermesSpecs + staticSpecs
            val lcncRoster = if (pinnedSpec == null) discovered else listOf(pinnedSpec) + discovered.filterNot {
                (it.provider ?: it.name) == pinnedSpec.provider && it.model == pinnedSpec.model
            }
            HostSystem.err(
                "[OROBOROS] mux cards: ${hermesSpecs.size} from hermes (${borg.trikeshed.hermes.HermesModelUsage.stateDb()}), " +
                        "${staticSpecs.size} from the static roster; configured default=${pinnedSpec?.model ?: "none"}" +
                        hermesInstances.take(3).joinToString(prefix = " — newest: ", separator = ", ") { "${it.model}@${it.provider}" } +
                        hermesKeyed.filterValues { !it }.keys.takeIf { it.isNotEmpty() }
                            ?.joinToString(prefix = "; hermes providers with no key here (not offered): ", separator = ", ").orEmpty(),
            )
            val lcncRosterEntries = lcncRoster.map {
                borg.trikeshed.agent.modelmux.RosterEntry(provider = it.provider ?: it.name, model = it.model)
            }
            val lcncCardIds = borg.trikeshed.agent.modelmux.disambiguateModelIds(lcncRosterEntries)
            borg.trikeshed.agent.modelmux.shadowedEntries(lcncRosterEntries).forEach { (entry, id) ->
                HostSystem.err(
                    "[OROBOROS] roster collision: ${entry.provider} serves '${entry.model}', " +
                            "already claimed — routable as '$id' (previously unreachable)",
                )
            }
            // Preserve usage history and HTTP quota observations across catalog rebuilds.
            refreshQuotaLegion()
            return borg.trikeshed.agent.modelmux.ModelMux(catalogKeys) {
                quota(quotaLegion)
                if (pinnedSpec != null) defaultModel(lcncCardIds.first())
                lcncRoster.forEachIndexed { i, ep ->
                    model(
                        id = lcncCardIds[i],
                        caps = setOf("chat", "conflict-resolve"),
                        baseUrl = ep.base,
                        provider = ep.provider ?: ep.name,
                        // The qualified id is a LOCAL routing key; the provider still
                        // only answers to its own name for the model.
                        wireModel = ep.model,
                        contextWindow = ep.contextWindow,
                    )
                }
            }
        }
        val lcncMux = borg.trikeshed.hermes.LiveHolder(hermesWatch, buildLcncMux()) { buildLcncMux() }
        operatorMux.complete { lcncMux.current() }
        moduleContext.lcncRunners.putAll(
            borg.trikeshed.lcnc.BrainMuxNodes.registry(
                credStore = couchKeyStore,
            ),
        )
        // Legal council seats carry their effective limits and spend context.
        // Explicit endpoint/model lists bound failover; otherwise the seat's
        // existing model preference applies.
        val councilDialog = borg.trikeshed.lcnc.modelMuxCouncilDialog(brainClient, htxElement + muxReactor)
        // Per-case job nexus: every convened case gets its own lifecycle (the
        // boot TribunalInstance singleton above stays legacy-preset-only).
        val councilCases = moduleContext.councilCases
        moduleContext.lcncRunners.putAll(
            borg.trikeshed.lcnc.CouncilNodes.registry(
                dialog = councilDialog,
                seams = councilRecordSeams(casStore, couchDb, daemonBlackboard, kifBank, councilCases),
            ),
        )
        // ── WikiSkill (arXiv 2608.27454) as two legos: wiki.consolidate (the
        //    Wiki Maintainer, one iteration per invocation) and wiki.propose
        //    (the Skill Proposer, one atomic proposal per pass). Their ONE
        //    spend seam is BrainClient.chatSeat under the same htx+mux context
        //    the council uses, so every Maintainer/Proposer token lands on the
        //    daemon's quota/lease receipts. Wiki state lives under the FORGE
        //    home (<forgeHome>/wiki) — never the repo worktree. The raw/ layer
        //    is the CAS, with a cid-VERIFIED rebuild from the hermes profile
        //    for snapshots this process never wrote (WikiTraceSources).
        //    The same consolidate runner instance is armed into the curation
        //    loop's lane seam — manual /api/lcnc/run invocations and the
        //    automatic feeder-driven lane hit ONE wiki, ONE spend seam.
        val wikiDialog = borg.trikeshed.wiki.WikiNodes.WikiDialog { call ->
            val (content, answeredBy) = kotlinx.coroutines.withContext(htxElement + muxReactor) {
                brainClient.chatSeat(
                    messages = listOf("system" to call.system, "user" to call.prompt),
                    maxTokens = call.maxTokens,
                    temperature = call.temperature,
                    contextId = call.contextId.takeIf { it.isNotBlank() },
                    preferredModel = call.preferredModel,
                )
            }
            borg.trikeshed.wiki.WikiNodes.WikiReply(content, answeredBy)
        }
        val wikiRoot = { File(Files.resolvePath(forgeHome, "wiki")) }
        val wikiTraces = borg.trikeshed.wiki.WikiTraceSources.loader(
            cas = casStore,
            profileDir = jfile(HostSystem.getenv("HERMES_PROFILE")?.let { File(it) } ?: File(hermesHomeDir.absolutePath)),
        )
        moduleContext.lcncRunners[borg.trikeshed.lcnc.LcncContracts.WIKI_CONSOLIDATE] =
            borg.trikeshed.wiki.WikiNodes.consolidateRunner(
                dialog = wikiDialog, wikiRoot = wikiRoot, traces = wikiTraces,
                casPut = { bytes -> casStore.put(bytes).value },
            ).also { wikiLane[0] = it }
        moduleContext.lcncRunners[borg.trikeshed.lcnc.LcncContracts.WIKI_PROPOSE] =
            borg.trikeshed.wiki.WikiNodes.proposeRunner(
                dialog = wikiDialog, wikiRoot = wikiRoot, traces = wikiTraces,
                casPut = { bytes -> casStore.put(bytes).value },
            )
        // Both wiki legos above call a model to do their work, so until now READING a curated
        // artifact needed an API key. VAL-CROSS-002 found the curation plane hosted, durable and
        // unreachable as itself. These two routes are the read side, and they touch nothing.
        val wikiReadWire = borg.trikeshed.forge.server.WikiReadWire(
            curations = curationIntake.constellations, wikiRoot = { jfile(wikiRoot()) })
        HostSystem.err(
            "[OROBOROS] Wiki read routes armed: " +
                    borg.trikeshed.forge.server.WikiReadWire.ROUTES.joinToString(" ") { r -> "${r.first} ${r.second}" } +
                    " root=${wikiRoot().absolutePath}"
        )
        // Boot thaw (non-fatal): the kifBank and the
        // blackboard are in-memory — couch + FileCasStore are the durable
        // planes. Re-assert the kif-ledger/ facts and re-land the
        // council-case/ index facts so the bank and the GET read-back
        // survive a restart.
        launch(Dispatchers.Default) {
            runCatching {
                var kifCount = 0
                var caseCount = 0
                val kifRows = couchDb.allDocs(startkey = "kif-ledger/", endkey = "kif-ledger/\uFFF0", includeDocs = true)["rows"] as? List<*> ?: emptyList<Any?>()
                for (row in kifRows) {
                    val rowMap = row as? Map<*, *> ?: continue
                    if (rowMap["id"]?.toString()?.startsWith("kif-ledger/") != true) continue
                    val kif = (rowMap["doc"] as? Map<*, *>)?.get("kif") as? String ?: continue
                    runCatching { kifBank.assertKif(kif) }.onSuccess { kifCount++ }
                }
                // The couch loop above can only see documents THIS boot wrote — casBacked's head
                // projection starts empty every time. The file ledger is what actually carries
                // taught axioms across a restart.
                var kifFileCount = 0
                for (kif in borg.trikeshed.narsese.NarsDurableLedger.readAxioms(forgeHome)) {
                    runCatching { kifBank.assertKif(kif) }.onSuccess { kifFileCount++ }
                }
                val caseRows = couchDb.allDocs(startkey = "council-case/", endkey = "council-case/\uFFF0", includeDocs = true)["rows"] as? List<*> ?: emptyList<Any?>()
                for (row in caseRows) {
                    val rowMap = row as? Map<*, *> ?: continue
                    val docId = rowMap["id"]?.toString() ?: continue
                    if (!docId.startsWith("council-case/")) continue
                    val doc = rowMap["doc"] as? Map<*, *> ?: continue
                    // The couch case doc carries no caseCid (a doc cannot embed
                    // its own hash); the read-back resolves transcript/verdict
                    // from these cids directly.
                    daemonBlackboard.put(docId, mapOf(
                        "verdictCid" to (doc["verdictCid"]?.toString() ?: ""),
                        "transcriptCid" to (doc["transcriptCid"]?.toString() ?: ""),
                        "documentCid" to (doc["documentCid"]?.toString() ?: ""),
                        "status" to (doc["status"]?.toString() ?: ""),
                    ), "council-thaw")
                    caseCount++
                }
                // Rules half of the thaw: the rete boots over zero rules, so every rule ever
                // admitted is re-offered from the `rete-rule/` plane. admit() is a set union on
                // ruleCid, so replaying the whole plane is idempotent.
                var ruleCount = 0
                causalityRete?.let { liveRete ->
                    val ruleRows = couchDb.allDocs(startkey = "rete-rule/", endkey = "rete-rule/￰", includeDocs = true)["rows"] as? List<*> ?: emptyList<Any?>()
                    val restored = ArrayList<borg.trikeshed.narsese.EternalRule>()
                    for (row in ruleRows) {
                        val rowMap = row as? Map<*, *> ?: continue
                        if (rowMap["id"]?.toString()?.startsWith("rete-rule/") != true) continue
                        val doc = rowMap["doc"] as? Map<*, *> ?: continue
                        val antecedent = doc["antecedent"]?.toString() ?: continue
                        val consequent = doc["consequent"]?.toString() ?: continue
                        val packed = doc["evidence"]?.toString()?.toLongOrNull() ?: continue
                        val copula = runCatching {
                            borg.trikeshed.narsese.NalCopula.valueOf(doc["copula"]?.toString() ?: "")
                        }.getOrNull() ?: continue
                        restored.add(
                            borg.trikeshed.narsese.EternalRule(
                                antecedent = antecedent,
                                consequent = consequent,
                                copula = copula,
                                evidence = borg.trikeshed.narsese.EvidenceCoord(packed),
                                provenanceCid = doc["provenanceCid"]?.toString()?.takeIf { it.isNotBlank() },
                            ),
                        )
                    }
                    restored.addAll(borg.trikeshed.narsese.NarsDurableLedger.readRules(forgeHome))
                    // Sense productions are caps over the sense rows, not rules: any minted before the rows stay out of the rete.
                    restored.removeAll { it.provenanceCid == borg.trikeshed.narsese.ConstellationNodes.SENSES }
                    if (restored.isNotEmpty()) ruleCount = liveRete.admit(borg.trikeshed.lib.seriesOf(restored))
                }
                HostSystem.err(
                    "[OROBOROS] council thaw: $kifCount kif facts (couch) + $kifFileCount (durable ledger), " +
                            "$caseCount cases re-indexed, $ruleCount eternal rules re-admitted"
                )
            }.onFailure {
                HostSystem.err("[OROBOROS] council thaw failed (non-fatal): ${it.message}")
            }
        }
        val moduleSupervisor = borg.trikeshed.module.ModuleSupervisor(
            ctx = moduleContext,
            liveClassesDir = jfile(File(Files.resolvePath(repoDir, "build/live/classes"))),
            receipt = { event, id, detail ->
                daemonBlackboard.put("$event/$id", detail.mapValues { it.value?.toString() ?: "" }, "oroboros")
            },
        )
        val moduleWire = borg.trikeshed.forge.server.ModuleWire(moduleSupervisor, moduleRoutes)
        val webhookRuntime = borg.trikeshed.forge.server.couchWebhookRuntime(
            couchStore, daemonBlackboard, jfile(forgeHome),
            runners = moduleContext.lcncRunners,
            loadProgram = { name -> borg.trikeshed.lcnc.LcncPresets.all()[name]?.encodeToByteArray() },
        )
        val webhookWire = webhookRuntime.wire
        val webhookScope = CoroutineScope(SupervisorJob(coroutineContext[kotlinx.coroutines.Job]) + Dispatchers.Default + htxElement)
        // Outbound deliveries own their lane: separate WAL + prefix, so inbound and
        // outbound NUID acceptance spaces never collide.
        val outboundHookLedger = withContext(Dispatchers.IO) {
            borg.trikeshed.hook.CausalHookDeliveryLedger.open(
                jfile(File(Files.resolvePath(forgeHome, ".hook-deliveries-out.wal"))), "hook-delivery-out/",
            )
        }
        borg.trikeshed.hook.installOutboundWebhookBridge(couchStore, daemonBlackboard, webhookScope, outboundHookLedger)

        // Boot facts land on the board — the durable answer to "what is this daemon".
        daemonBlackboard.put(
            "daemon/boot/kanban",
            mapOf("port" to "8888", "atMs" to HostSystem.currentTimeMillis().toString()),
            "oroboros",
        )
        val (postgrestWire, kanbanServer) = registerWireSurfaces(moduleContext, moduleRoutes, forgeHome,
            reteProductions, rete, kifTee, causalityRete, curatorImpulse, couchDb, breadcrumbContexts, beliefBag,
            graalWire, vmWire, piWire, hermesWire, beliefWire, patchWire, moduleWire, webhookWire,
            blackboardWire, agentWire, couchWire, projectDbWire, casReflinkWire, wikiReadWire)
        // Published programs (AutoTools notion, Cut 0): every head the ledger names is re-filed as
        // its `panels/<name>` attachment and republished as `lcnc/program/<name>` at the same
        // programCid. PLACED HERE, after the last `moduleContext.lcncRunners.putAll(...)` above and
        // not beside the prompt thaw: the republish is `LcncPublisher.publishAll()`, i.e. a
        // `lateBound()`, which resolves every contract against the runner registry AS IT STANDS and
        // tells the answer into the daemon's one KIF bank. Beside the prompts it would have been
        // the boot's first lateBound() with two thirds of the registry (ProjectNodes … SurfaceNodes)
        // still unregistered, so the bank would have learned `unbound` for legos that are bound.
        // (`LcncFacts.learn` now REPLACES a type's binding instead of adding a second row, so an
        // early pass can no longer strand that answer — but the honest resolution is the late one.)
        // Sequential, not launch{}: it must finish before `moduleSupervisor.attach(KanbanModule())`
        // below, whose own publishAll() computes the corpus from these attachments and whose
        // runs.recover() replays receipts against the entries.
        // Guarded like the module attach below and `KanbanModule`'s own publishAll(): this is
        // SEQUENTIAL boot code running before `kanbanServer.run(...)` binds, and `main`'s only
        // catch is CancellationException — so anything that escaped here would cost the daemon
        // its whole HTTP surface for a fault whose honest cost is the ledger's heads. The thaw
        // already refuses one bad head at a time; this is the brace to that belt, for the faults
        // it cannot foresee (the corpus-wide republish reads every `panels/` attachment, ledger
        // line or not).
        runCatching { programLedger.thaw() }
            .onSuccess { restored -> HostSystem.err("[OROBOROS] programs: $restored head(s) restored from the ledger") }
            .onFailure { HostSystem.err("[OROBOROS] programs: ledger thaw FAILED (${it.message}); the daemon boots without the ledger's heads") }
        launch {
            // KanbanModule is the point of the module system: attached by DEFAULT (the WAL-backed
            // board replaces the fossil plan-parser). TRIKESHED_NO_KANBAN_MODULE=1 opts out.
            if (HostSystem.getenv("TRIKESHED_NO_KANBAN_MODULE") != "1") {
                runCatching { moduleSupervisor.attach(borg.trikeshed.kanban.module.KanbanModule()) }
                    .onSuccess { HostSystem.err("[OROBOROS] module attached: ${it.id} (default) — ${it.describe()}") }
                    .onFailure { HostSystem.err("[OROBOROS] KanbanModule attach FAILED: ${it.message}") }
            }
            for (fqcn in config.modules) {
                runCatching { moduleSupervisor.attach(fqcn) }
                    .onSuccess { HostSystem.err("[OROBOROS] module attached: ${it.id} ($fqcn)") }
                    .onFailure { HostSystem.err("[OROBOROS] module attach FAILED for $fqcn: ${it.message}") }
            }
        }

        // ── Project dbs: every mounted db grows its own Changes→Rete tendon
        //    (partition = db name — blackboard subscope seams by project), then
        //    boot mounts: the --project flags and the forge-home mount ledger
        //    (project dbs SURVIVE restarts — the ledger replays them).
        projectDbRegistry.factPlane(moduleScope, rete, reportReactorForWires)
        launch(Dispatchers.IO) {
            for (extra in config.projects) {
                runCatching { projectScopes.mount(extra) }
                    .onSuccess { HostSystem.err("[OROBOROS] project db mounted: ${it.kind} ${it.name} (${it.paths} paths, ${it.docs} docs, ${it.minted} minted)") }
                    .onFailure { HostSystem.err("[OROBOROS] scope mount FAILED for $extra: ${it.message}") }
            }
            val remounted = runCatching { projectScopes.remountLedger() }.getOrElse { 0 }
            if (remounted > 0) HostSystem.err("[OROBOROS] project dbs remounted from ledger: $remounted")
        }
        val kanbanJob = SupervisorJob(coroutineContext[kotlinx.coroutines.Job])
        // The pg wire: psql and the drivers read the same catalog PostgREST serves, on their own port over the userspace ring.
        val pgServer = if (watch) borg.trikeshed.pgwire.PgServerElement(CoroutineScope(coroutineContext + kanbanJob), postgrestWire.surface, "0.0.0.0:$pgPort") else null
        if (watch) {
            launch(CoroutineScope(kanbanJob).coroutineContext + Dispatchers.Default) {
                try {
                    pgServer!!.open()
                    val bound = pgServer.localAddress?.substringAfterLast(':') ?: pgPort.toString()
                    HostSystem.err("[OROBOROS] pg wire listening on ${pgServer.localAddress} (psql -h 127.0.0.1 -p $bound -U trikeshed -d trikeshed)")
                } catch (t: Throwable) {
                    HostSystem.err("[OROBOROS] pg wire failed to listen on :$pgPort: ${t.message}")
                }
            }
            launch(CoroutineScope(kanbanJob).coroutineContext + Dispatchers.Default) {
                // Boot race seen in the wild: bindAndServe dies with "Parent job is Cancelling"
                // moments after the port binds. Until the racing job is named, the server RETRIES —
                // a daemon whose HTTP tier can be killed once at boot must not stay headless.
                var attempt = 0
                while (isRunning) {
                    try {
                        kanbanServer.run(kanbanPort, null)
                        break
                    } catch (t: Throwable) {
                        if (t is kotlinx.coroutines.CancellationException && !isRunning) break
                        attempt++
                        HostSystem.err("[OROBOROS] Kanban server failed (attempt $attempt): ${t.message}")
                        t.printStackTrace()
                        if (attempt >= 5) { HostSystem.err("[OROBOROS] Kanban server giving up after $attempt attempts"); break }
                        kotlinx.coroutines.delay(1500L * attempt)
                    }
                }
            }
            HostSystem.err("[OROBOROS] Kanban HTTP server launching on :$kanbanPort (CCEK litebike) — Couch 1.6 surface at /$COUCH_DB_NAME, PWA hoisted at /")
        } else {
            HostSystem.err("[OROBOROS] --once mode: Kanban server skipped")
        }

        // ── Pointcut Subsystem ──
        // Connect the pointcut adapter to the actual process-wide ConfixBlackboard instance if it existed globally.
        // Currently, we'll continue providing an empty blackboard here as there's no pre-existing global ConfixBlackboard exposed to OroborosDaemon.
        // Pointcut landings stay in the adapter's flow and the blackboard (cursor reads); they are not couch documents.
        pointcutAdapter.install()
        borg.trikeshed.couch.viewserver.KotlinViewServer.install(pointcutAdapter)


        val gitWatcher = FileWatchReactorElement(
            root = repoDir.absolutePath,
            parentJob = coroutineContext[kotlinx.coroutines.Job],
            capacity = 4096,
            includeGlobs = listOf(".git/**"),
            excludeGlobs = emptyList(),
            // This watcher wants the git DB and nothing else, but the walk is rooted at the repo:
            // 15,232 of this checkout's 16,537 directories live under .claude/worktrees, so
            // without pruning it registered an OS watch on 92% of the tree to observe none of it.
            // `.git` stays walkable — everything this watcher exists for is under it.
            walkerBlockedSegments = WorktreeCouchGateway.EXCLUDED_SEGMENTS - ".git",
            walkerBlockedRelativePrefixes = WorktreeCouchGateway.EXCLUDED_RELATIVE_PREFIXES,
        )
        launch(Dispatchers.IO) { gitWatcher.open() }
        HostSystem.err("[OROBOROS] Git watcher open — reactive .git/** events")

        // The Jules causal WAL is an event source, not an out-of-band operator
        // surface. External queue/review appends wake the same serialized cycle
        // that owns API polling, drain, settlement, and dispatch.
        val julesWalWatcher = FileWatchReactorElement(
            root = forgeHome.absolutePath,
            parentJob = coroutineContext[kotlinx.coroutines.Job],
            capacity = 256,
            includeGlobs = listOf("jules-board.wal"),
            excludeGlobs = emptyList(),
            // One file at the forge root, but the walk is rooted at the forge home — which is
            // where the CAS store lives. Pruning the store's shard tree keeps this watcher the
            // size of the thing it actually watches.
            walkerBlockedSegments = WorktreeCouchGateway.EXCLUDED_SEGMENTS,
            walkerBlockedRelativePrefixes = emptySet<String>(),
        )
        launch(Dispatchers.IO) { julesWalWatcher.open() }
        launch {
            for (event in julesWalWatcher.events) {
                cycleTriggers.trySend(Unit)
                println("[OROBOROS] jules-wal-event: ${event.type}")
            }
        }
        HostSystem.err("[OROBOROS] Jules WAL watcher open — serialized cycle trigger")

        // Working-tree plane: source and document files live under Couch/CAS,
        // independently of the `.git/**` identity plane above.


        val gitReconcileElement = borg.trikeshed.util.oroboros.element.GitReconcileElement(
            forgeHome = repoDir.absolutePath,
            gitCouchGateway = gitCouchGateway,
            couchIndexBridge = couchIndexBridge,
            headShaProvider = { gitState.headSha() },
            awaitObjectsDirty = { gitState.awaitObjectsDirty() },
            parentJob = coroutineContext[kotlinx.coroutines.Job]
        )
        launch(Dispatchers.IO) { gitReconcileElement.open() }

        val worktreeWatcher = FileWatchReactorElement(
            root = repoDir.absolutePath,
            parentJob = coroutineContext[kotlinx.coroutines.Job],
            capacity = 4096,
            includeGlobs = emptyList(),
            // Derived from the gateway's own ignore sets, never hand-listed here again: the
            // hand-listed version omitted `logs/`, so the daemon's log writes woke the watcher
            // whose reconcile wrote that log — a permanent self-feeding quake at 95% CPU.
            excludeGlobs = WorktreeCouchGateway.watcherExcludeGlobs(),
            // …and prune the same paths from the WALK, not just from event delivery. Registering
            // an OS watch on every directory of .git and of every .claude/worktrees checkout cost
            // minutes of boot and a permanent watch set, for events this daemon then discards.
            walkerBlockedSegments = WorktreeCouchGateway.EXCLUDED_SEGMENTS,
            walkerBlockedRelativePrefixes = WorktreeCouchGateway.EXCLUDED_RELATIVE_PREFIXES,
        )
        launch(Dispatchers.IO) { worktreeWatcher.open() }
        HostSystem.err("[OROBOROS] Worktree watcher open — reactive source/document events")

        launch {
            // Seismic damping: a build refeed or git fetch is thousands of events in seconds;
            // one line per 5s window with a magnitude, instead of an earthquake in the log.
            var windowStart = 0L; var windowCount = 0; var lastPath = ""
            for (event in worktreeWatcher.events) {
                worktreeReconcileElement.worktreeDirty.trySend(Unit)
                cycleTriggers.trySend(Unit)
                val now = HostSystem.currentTimeMillis()
                if (now - windowStart > 5_000) {
                    if (windowCount > 1) println("[OROBOROS] worktree-quake: $windowCount events in 5s (last: $lastPath)")
                    else if (windowCount == 1) println("[OROBOROS] worktree-event: $lastPath")
                    windowStart = now; windowCount = 0
                }
                windowCount++; lastPath = "${event.type} ${event.path}"
            }
        }

        // The build plane is read in place; no watcher polls it and nothing re-absorbs it into couch.

        // Choreography 1: git filesystem events → GitStateCache invalidation.
        // The cache holds headSha, treeClean, and refHead — read from .git
        // files directly (no ProcessBuilder). File events invalidate the
        // relevant cache entry; the next cycle reads fresh values.
        launch {
            var lastRefLogMs = 0L
            for (event in gitWatcher.events) {
                cycleTriggers.trySend(Unit)
                when {
                    event.path.startsWith(".git/HEAD") -> {
                        gitState.invalidateHead()
                        println("[OROBOROS] git-event: HEAD changed → headSha cache invalidated")
                    }
                    event.path.startsWith(".git/index") -> {
                        gitState.invalidateTree()
                        println("[OROBOROS] git-event: index changed → treeClean cache invalidated")
                    }
                    event.path.startsWith(".git/refs/") -> {
                        gitState.invalidateHead()
                        if (HostSystem.currentTimeMillis() - lastRefLogMs > 5_000) {
                            lastRefLogMs = HostSystem.currentTimeMillis()
                            println("[OROBOROS] git-event: ref changed → ${event.path} (further ref churn sampled 1/5s)")
                        }
                    }
                    event.path.startsWith(".git/objects/") -> {
                        // New git object — trigger Couch reconcile if in --watch mode
                        if (watch) {
                            gitState.markObjectsDirty()
                        }
                    }
                }
            }
        }

        // The build plane (classes, staged jars, resources) is read in place by the classpath routes; it is
        // not absorbed into couch — a class file is not a document and a compile is not a revision.
        withContext(Dispatchers.IO) {
            // ── Foundation: git + worktree reconcile ──
            val reconcileResult = runCatching {
                val headSha = gitState.headSha()
                val snap = gitCouchGateway.reconcile(
                    forgeHome = repoDir.absolutePath,
                    agentId = "oroboros",
                    revision = headSha,
                    sequence = HostSystem.currentTimeMillis(),
                )
                couchIndexBridge.indexReconciliation(
                    GitCouchGateway.GIT_PREFIX,
                    snap.paths.size j { i: Int -> snap.paths[i] },
                )
                HostSystem.err("[OROBOROS] Git→Couch initial reconcile: ${snap.paths.size} paths @ ${headSha.take(12)}")

                val worktreeSnap = worktreeReconcileElement.sync()
                projectScopes.registerPrimary(jfile(repoDir), worktreeSnap.paths.size)
                HostSystem.err(
                    "[OROBOROS] Worktree→Couch initial reconcile: ${worktreeSnap.paths.size} paths" +
                            (if (worktreeSnap.skippedDirs.isEmpty()) ""
                            else " — INCOMPLETE: ${worktreeSnap.skippedDirs.size} unreadable dir(s), " +
                                    "nothing under them tombstoned: ${worktreeSnap.skippedDirs.take(5)}") +
                            (if (worktreeSnap.skippedFiles.isEmpty()) ""
                            else " — ${worktreeSnap.skippedFiles.size} file(s) over " +
                                    "${borg.trikeshed.util.oroboros.WorktreeCouchGateway.MAX_FILE_BYTES shr 20} MiB skipped: " +
                                    "${worktreeSnap.skippedFiles.take(3)}")
                )
                headSha to worktreeSnap
            }.onFailure {
                HostSystem.err("[OROBOROS] git/worktree reconcile failed: ${it.message}")
                it.printStackTrace()
            }.getOrNull() ?: return@withContext

            val (headSha, worktreeSnap) = reconcileResult

            // ── Belief seeding (degrades independently) ──
            runCatching {
                // ── Belief minting feed: epistemic signals from the memory plane land in the bag.
                // FNV identity stays on the signal's CIDs; the BAG key gets the feature-coded
                // AngularCodec coordinate so recallNear is real locality, not hash noise.
                // Boot seed is AIKR-capped; the bag's own capacity bounds the rest.
                if (beliefBag != null) {
                    var mintedSignals = 0
                    val mintCap = 2048
                    for (i in 0 until worktreeSnap.paths.size) {
                        if (mintedSignals >= mintCap) break
                        val path = worktreeSnap.paths[i]
                        if (!path.endsWith(".md") && !path.endsWith(".markdown")) continue
                        val att = attachmentGateway.getAttachment(path) ?: continue
                        val docText = att.second.decodeToString()
                        val surface = runCatching {
                            borg.trikeshed.cas.ContentEpistemicIngest.ingest(casStore, docText)
                        }.getOrNull() ?: continue
                        for (si in 0 until surface.signals.size) {
                            if (mintedSignals >= mintCap) break
                            val s = surface.signals[si]
                            val coord = borg.trikeshed.narsese.AngularCodec.encode(
                                relation = s.relation,
                                taxonomyKey = path,
                                subjectTerm = path.substringAfterLast('/'),
                                objectTerm = s.objectCid?.take(12),
                            )
                            beliefBag.intake.send(
                                borg.trikeshed.narsese.BeliefIntake.Mint(
                                    s.copy(angular = coord),
                                    borg.trikeshed.cursor.BudgetCoord(0.5f, 0.3f, 0.5f),
                                    gloss = borg.trikeshed.cas.epistemicGloss(surface, s, path.substringAfterLast('/'), docText),
                                ),
                            )
                            mintedSignals++
                        }
                    }
                    HostSystem.err("[OROBOROS] BeliefBag seeded: $mintedSignals epistemic signals → ${beliefBag.size} beliefs")
                }
            }.onFailure {
                HostSystem.err("[OROBOROS] memory bridge/belief failed: ${it.message}")
                it.printStackTrace()
            }

            // ── Hermes home reconcile ──
            runCatching {
                if (hermesHomeDir.isDirectory()) {
                    val hermesSnap = hermesHomeGateway.reconcile(hermesHomeDir.absolutePath, "oroboros", headSha, HostSystem.currentTimeMillis())
                    HostSystem.err("[OROBOROS] Hermes home→Couch initial reconcile: ${hermesSnap.paths.size} paths (teleportable clone of ~/.hermes)")
                } else {
                    HostSystem.err("[OROBOROS] Hermes home skipped: $hermesHomeDir not found")
                }
            }.onFailure {
                HostSystem.err("[OROBOROS] Hermes home reconcile failed: ${it.message}")
                it.printStackTrace()
            }
        }

        // ── Couch report reactor: CCEK element for map/reduce events ──
        val reportReactor = reportReactorForWires
        HostSystem.err("[OROBOROS] Couch report reactor — feeding the Graal console flourish feed")

        // ── Tendon: _changes → report bus + Rete facts. Every committed revision (local write,
        //    reconcile, or a peer's replication) is a fact in the production system; the git object
        //    plane stays out (opaque blobs carry no fields worth matching).
        // (rete hoisted above the kanban server so ModuleContext can carry it)
        val changesFacts = borg.trikeshed.couch.CouchChangesFactElement(
            db = couchDb,
            rete = rete,
            report = reportReactor,
            // pointcut/ docs stay out: the graal tendon below asserts each landing once, on the graal partition.
            admit = { !it.docId.startsWith("_design/") && !it.docId.startsWith(GitCouchGateway.GIT_PREFIX) &&
                !it.docId.startsWith("pointcut/") && borg.trikeshed.util.oroboros.HermesCorpus.admits(it.docId) },
            parentJob = kanbanJob,
        )
        launch {
            changesFacts.open()
            HostSystem.err("[OROBOROS] Changes→Rete tendon open — ${changesFacts.factsApplied} facts from the initial reconcile, commits=${reportReactor.reportState.value.commits}")
        }

        // ── Tendon: daemonBlackboard keys → Rete facts (partition "blackboard"). Admit table is
        //    BlackboardNamespaces: rule-firing outputs (kanban/rule/, narsese/curation/,
        //    narsese/rete/firing/) stay receipt-only so the sink cannot re-enter the network.
        val blackboardFacts = borg.trikeshed.graal.BlackboardChangesFactElement(
            blackboard = daemonBlackboard,
            rete = rete,
            parentJob = kanbanJob,
        )
        // ── Tendon: the runtime → Rete facts (partition "graal"): bounded STATE facts per tick
        //    (memory, gc/<collector>, jit, deopt/<method> capped, alloc/<class> top-N) plus one
        //    fact per pointcut landing key off the one shared adapter (daemon + Hypervisor lanes).
        val graalFacts = borg.trikeshed.graal.vitals.GraalFactElement(
            vitals = jvmVitals,
            rete = rete,
            pointcutFlows = listOf(pointcutAdapter.flow),
            tickMs = borg.trikeshed.graal.vitals.GraalFactElement.DEFAULT_TICK_MS,
            parentJob = kanbanJob,
        )
        launch {
            blackboardFacts.open()
            HostSystem.err("[OROBOROS] Blackboard→Rete tendon open — ${blackboardFacts.factsApplied} facts from the initial drain of ${daemonBlackboard.keys().size} keys")
            graalFacts.open()
            HostSystem.err("[OROBOROS] Graal→Rete tendon open")
            // Belt to the tee's brace: anything the network held before the observer attached is projected once.
            kifTee.prime(rete)
            HostSystem.err("[OROBOROS] Rete→KIF tee: ${kifTee.trackedCount()} facts projected into the one bank")
        }

        val mainJob = coroutineContext[kotlinx.coroutines.Job]
        val reactiveJob = SupervisorJob(mainJob)

        // Wake the daemon without cancelling resource owners: their close paths
        // must drain admitted work before the daemon supervisor is cancelled.
        val sigHandler = {
            isRunning = false
            reactiveJob.cancel()
        }
        borg.trikeshed.platform.PosixSignals.handle("TERM", sigHandler)
        borg.trikeshed.platform.PosixSignals.handle("INT", sigHandler)

        HostSystem.err(
            "[OROBOROS] daemon up. forgeHome=$forgeHome repo=$repoDir " +
                    "intervalMs=$intervalMs maxSlots=$maxSlots mode=${if (watch) "watch" else "once"}"
        )

        // Hot-swappable telemetry + quarantine guard. Same instance, JVM
        // retransforms the class in place — next call sees new bytecode. The
        // reactive choreography owns all poll/drain/dispatch; CycleBody only
        // observes and traces.
        try {
            if (watch) {
                reactiveJob.join()
            } else {
                // --once: settle the reactive elements, then exit.
                delay(intervalMs)
                isRunning = false
                reactiveJob.cancelAndJoin()
                return
            }
        } finally {
            withContext(NonCancellable) {
                isRunning = false
                reactiveJob.cancelAndJoin()
                healthJob.cancel()
                runCatching { channelOps.close(healthFd) }
                healthJob.cancelAndJoin()
                if (healthSock.exists()) healthSock.delete()
                // Network requests own admitted remote invocations; settle them while HTX and
                // the local module/store dependencies are still live. Outer close also covers startup failure.
                lcncIpnsNode.drain()
                // Independent Pi sessions settle before their shared model/breadcrumb services close.
                drainPi(piWire)
                // Finish accepted guest turns while their blackboard/model/store dependencies are live.
                runCatching { hermesWire.drain() }.onFailure {
                    HostSystem.err("[OROBOROS] Hermes drain failed: ${it.message}")
                }
                runCatching { couchWire.requestFactory?.drain() }.onFailure {
                    HostSystem.err("[OROBOROS] RequestFactory drain failed: ${it.message}")
                }
                // Admitted shared-context transfers settle while the stores they read and write are still open.
                runCatching { sharedContext.drain() }.onFailure {
                    HostSystem.err("[OROBOROS] Shared context drain failed: ${it.message}")
                }
                // Stop job-agent admission and await accepted writes/model work before their stores close.
                runCatching { headhunterWire.drain() }
                runCatching { documentReviewWire.stopAdmission() }
                // The follow/Wiki producer stops at its admission boundary and settles its
                // current pass before the runner registry, model clients, or stores close.
                drainCuration(curatorFollowJob, curationIntake, moduleSupervisor, moduleContext)
                // Join accepted route commands, then consumers and their final facts. A failed
                // stop is not permission to close the observation dependencies underneath it.
                drainCamel(moduleContext, blackboardFacts, graalFacts, jvmVitals)
                projectScopes.drain()
                runCatching { worktreeReconcileElement.drain() }
                changesFacts.drain()
                pgServer?.let { runCatching { it.drain() } }
                runCatching { kanbanJob.cancel() }
                runCatching { kifTeeDisposer.close() }
                runCatching { tribunalHolder.instance?.nexus?.drain() }
                runCatching { headhunterWire.drainCuration() }
                runCatching { documentReviewWire.drain() }
                runCatching { confixIsam?.drain() }
                runCatching { moduleScope.coroutineContext.job.cancelAndJoin() }
                runCatching { headhunterWire.close() }
                runCatching { documentReviewWire.close() }
                runCatching { turnReview?.drain() }
                runCatching { causalityRete?.drain() }
                runCatching { curatorImpulse?.drain() }
                runCatching { beliefBag?.supervisor?.cancelAndJoin() }
                runCatching { incrementalViews.closeAll() }
                runCatching { memoryIndex.close() }
                runCatching { gitReconcileElement.supervisor.cancelAndJoin() }
                runCatching { worktreeWatcher.close() }
                runCatching { gitWatcher.close() }
                runCatching { julesWalWatcher.close() }
                try { htxElement.close() } catch (_: Exception) {}
                try { torrentElement.close() } catch (_: Exception) {}
                try { muxReactor.close() } catch (_: Exception) {}
                runCatching { couchStorage.close() }
                try { nioSupervisor.close() } catch (_: Exception) {}
            }
        }
    }

    private data class LanguageRegistration(
        val review: borg.trikeshed.forge.server.DocumentReviewWire,
        val intake: borg.trikeshed.forge.server.CurationIntake,
        val tribunal: borg.trikeshed.lcnc.TribunalInstanceHolder,
    )

    /** One ordered registration slice; keep its direct bytecode out of the daemon's JVM-limited boot method. */
    private suspend fun registerCorpusLanguage(
        moduleContext: borg.trikeshed.module.ModuleContext,
        kifBank: borg.trikeshed.kif.KifKnowledgeBase,
        causalityRete: borg.trikeshed.narsese.CausalityReteElement?,
        projectCorpus: borg.trikeshed.forge.server.JvmProjectCorpus,
        projectScopes: borg.trikeshed.forge.server.ProjectScopes,
        wireScope: CoroutineScope,
        couchDb: borg.trikeshed.couch.Couch,
        forgeHome: File,
        beliefBag: borg.trikeshed.narsese.BeliefBagElement?,
        brainClient: borg.trikeshed.modelmux.BrainClient,
        muxContext: kotlin.coroutines.CoroutineContext,
        casStore: borg.trikeshed.job.CasStore,
        moduleScope: CoroutineScope,
        hermesMemoryFiles: borg.trikeshed.memory.HermesMemoryFiles?,
    ): LanguageRegistration {
        val constellationNodes = borg.trikeshed.narsese.ConstellationNodes.registerLanguageNodes(moduleContext, kifBank, causalityRete)
        val documentReviewWire = borg.trikeshed.lcnc.OroborosLcncWiring.documentReview(moduleContext, projectCorpus, constellationNodes)
        val curationIntake = borg.trikeshed.forge.server.CurationIntake.install(
            constellationNodes,
            moduleContext, projectCorpus, projectScopes, wireScope,
        )
        // ── Rule admission: the seam that ends the live rete's dead spin —
        // the daemon boots causalityRete over ZERO rules; these admit law.
        causalityRete?.let { liveRete ->
            // …and law that is only in memory is not law after a restart. Each admitted rule is
            // filed under its own ruleCid in the `rete-rule/` couch plane, which the boot thaw
            // below re-admits — the rules counterpart of the `kif-ledger/` axiom plane.
            moduleContext.lcncRunners["nal.rule.admit"] = borg.trikeshed.narsese.RuleNodes.ruleAdmitRunner(
                liveRete,
                review = documentReviewWire.review::consume,
                ledger = { r ->
                    runCatching {
                        couchDb.put(
                            "rete-rule/${r.ruleCid.hex}",
                            mapOf(
                                "antecedent" to r.antecedent,
                                "consequent" to r.consequent,
                                "copula" to r.copula.name,
                                "evidence" to r.evidence.packed.toString(),
                                "provenanceCid" to (r.provenanceCid ?: ""),
                                "atMs" to HostSystem.currentTimeMillis(),
                            ),
                            null,
                        )
                    }.onFailure { HostSystem.err("[OROBOROS] rete-rule ledger write failed (non-fatal): ${it.message}") }
                    // Same reason as the axiom ledger: couch cannot find its own documents after
                    // a restart, so the durable record of admitted law is the file.
                    runCatching { borg.trikeshed.narsese.NarsDurableLedger.appendRule(forgeHome, r) }
                        .onFailure { HostSystem.err("[OROBOROS] rete-rule file ledger write failed (non-fatal): ${it.message}") }
                },
            )
            moduleContext.lcncRunners["nal.rules.fromKg"] = borg.trikeshed.narsese.RuleNodes.rulesFromKgRunner(liveRete)
        }
        // Bag-off honesty: these contracts ship unconditionally, so with the
        // bag flagged off the canvas still gets a value naming the flag — not
        // a 404. KanbanModule's own bag-gated pair is stubbed here too (its
        // attach only registers them when ctx.beliefBag is live).
        if (beliefBag == null) {
            val bagGated = listOf(
                "read.construct", "nal.mint", "nal.decay", "nal.recall", "skill.decay",
                "nal.attend", "nal.reinforce", "nal.rule.admit", "nal.rules.fromKg",
                "beliefs.introspect", "beliefs.resonate", "beliefs.review", "nars.seat",
                "state.freeze", "state.thaw", "kanban.attention", "kanban.drift", "kanban.review",
            )
            val bagOff = borg.trikeshed.lcnc.LcncNodeRunner { _, _ ->
                mapOf("error" to "belief bag disabled (--belief-bag)")
            }
            for (type in bagGated) moduleContext.lcncRunners[type] = bagOff
        }
        // ── Legal domain nodes: legal.ingest, legal.evidence ────────────
        moduleContext.lcncRunners["legal.ingest"] = borg.trikeshed.narsese.LegalNodes.ingestRunner(
            curate = { moduleContext.lcncRunners[borg.trikeshed.lcnc.DocumentCurationLegos.CURATE] },
            cas = casStore,
        )
        // Historical KIF and prior rulings remain readable. New curation publishes
        // through DocumentCurationWire's retained tuple plane, not a second KIF sink.
        moduleContext.lcncRunners["legal.evidence"] = borg.trikeshed.narsese.LegalNodes.evidenceRunner(kifBank)
        // ── Tribunal: the LCNC preset that argues, rebuts, and rules through
        //    REAL hermes-env model dialogs. The node family (mux.chat /
        //    tribunal.record / display) is registered in-process, and each seat's
        //    model call routes through BrainClient — KeyMux harness lane
        //    ($HERMES_HOME/.env, auth.json credential pool) → ModelMux →
        //    HtxReactor, so the tribunal's token spend lands on the daemon's
        //    quota/lease receipts exactly like every other model traffic.
        //    The instance opens on the first tribunal.record, not at boot.
        //    Prose retention and lifecycle are separate from KG belief intake.
        val tribunalHolder = borg.trikeshed.lcnc.TribunalInstanceHolder()
        val tribunalLock = kotlinx.coroutines.sync.Mutex()
        moduleContext.lcncRunners.putAll(
            borg.trikeshed.lcnc.TribunalNodes.registry(
                dialog = borg.trikeshed.lcnc.modelMuxDialog(
                    brain = brainClient,
                    muxContext = muxContext,
                ),
                record = borg.trikeshed.lcnc.tribunalRecord(casStore) { verdictCid ->
                    val t = tribunalLock.withLock {
                        tribunalHolder.instance ?: borg.trikeshed.lcnc.TribunalInstance.open(
                            scope = moduleScope,
                            plan = borg.trikeshed.lcnc.TribunalInstance.schemaPlan(),
                            presetDocument = borg.trikeshed.lcnc.LcncPresets.all().getValue("preset-tribunal"),
                        ).also { tribunal ->
                            try {
                                tribunal.awaitRootSeeds()
                            } catch (failure: Throwable) {
                                withContext(NonCancellable) {
                                    try { tribunal.nexus.drain() }
                                    catch (cleanup: Throwable) { failure.addSuppressed(cleanup) }
                                }
                                throw failure
                            }
                            tribunalHolder.instance = tribunal
                        }
                    }
                    t.record(verdictCid)
                },
            ),
        )
        moduleContext.lcncRunners.putAll(borg.trikeshed.lcnc.KgNodes.registry { text ->
            checkNotNull(beliefBag) { "kg.ingest: belief bag is disabled" }.ingestKg(text) { angular, expression ->
                hermesMemoryFiles?.gloss(angular, expression)
            }
        })
        return LanguageRegistration(documentReviewWire, curationIntake, tribunalHolder)
    }

    private data class WireSurfaces(
        val postgrest: borg.trikeshed.forge.server.PostgrestWire,
        val server: JvmKanbanServer,
    )

    /** Preserve route order and one quad-store identity while keeping assembly out of mainImpl. */
    private fun registerWireSurfaces(
        moduleContext: borg.trikeshed.module.ModuleContext,
        moduleRoutes: borg.trikeshed.module.ModuleRouteRegistry,
        forgeHome: File,
        reteProductions: borg.trikeshed.dag.ReteProductionRegistry,
        rete: borg.trikeshed.dag.ReteNetwork,
        kifTee: borg.trikeshed.dag.KifTee,
        causalityRete: borg.trikeshed.narsese.CausalityReteElement?,
        curatorImpulse: borg.trikeshed.narsese.CuratorImpulseElement?,
        couchDb: borg.trikeshed.couch.Couch,
        breadcrumbContexts: borg.trikeshed.agent.modelmux.BreadcrumbElement,
        beliefBag: borg.trikeshed.narsese.BeliefBagElement?,
        graalWire: borg.trikeshed.forge.server.GraalWire,
        vmWire: borg.trikeshed.forge.server.VmWire,
        piWire: borg.trikeshed.forge.server.PiWire,
        hermesWire: borg.trikeshed.forge.server.HermesConsoleWire,
        beliefWire: borg.trikeshed.forge.server.BeliefWire?,
        patchWire: borg.trikeshed.forge.server.PatchWire,
        moduleWire: borg.trikeshed.forge.server.ModuleWire,
        webhookWire: borg.trikeshed.forge.server.WebhookWire,
        blackboardWire: borg.trikeshed.forge.server.BlackboardWire,
        agentWire: borg.trikeshed.forge.server.AgentWire,
        couchWire: borg.trikeshed.forge.server.CouchWire,
        projectDbWire: borg.trikeshed.forge.server.ProjectDbWire,
        casReflinkWire: borg.trikeshed.forge.server.CasReflinkWire?,
        wikiReadWire: borg.trikeshed.forge.server.WikiReadWire,
    ): WireSurfaces {
        // The canvas as RDF, joined with what watches it: productions (Rete),
        // causal rules (CausalityRete), and KIF facts (curator bank).
        val rdfWire = borg.trikeshed.forge.server.LcncRdfWire(
            productions = { reteProductions.all() },
            causalRules = { causalityRete?.rules?.let { r -> (0 until r.size).map { r[it] } }.orEmpty() },
            facts = { pattern -> curatorImpulse?.let { c -> runCatching { c.queryBank(pattern) }.getOrDefault(emptyList()) }.orEmpty() },
        )
        // The fact plane itself, read-only: /api/rete/facts, /api/facts/rdf, /api/rete/productions.
        val reteWire = borg.trikeshed.forge.server.ReteWire(rete, kifTee, causalityRete, borg.trikeshed.ontology.SumoCorpus.pinned)
        // The polyglot agent sleeves and the red cards their unresolved traps generate (/api/sleeves).
        val sleeveWire = borg.trikeshed.forge.server.SleeveWire()
        // The hover blip: one LCNC node read across panels + KIF + productions + graal (/api/lcnc/blip).
        val blipWire = borg.trikeshed.forge.server.LcncBlipWire(
            network = rete,
            kif = { pattern -> curatorImpulse?.let { c -> runCatching { c.queryBank(pattern) }.getOrDefault(emptyList()) }.orEmpty() },
            productions = { reteProductions.all() },
        )
        // Virtuoso's quad store: SPARQL Update fills it, /sparql and SPASQL read it beside the fact plane's triples.
        val quadStore = borg.trikeshed.rdf.QuadStore()
        val sparqlWire = borg.trikeshed.forge.server.SparqlWire(
            borg.trikeshed.rdf.SparqlSurface(quadStore),
            borg.trikeshed.rdf.CypherSurface(quadStore),
            live = {
                borg.trikeshed.rdf.QuadStore().load(borg.trikeshed.rdf.RdfGraph(
                    rete.snapshot().view.flatMap { borg.trikeshed.dag.PlaneFacts.toTriples(it).view },
                )).scan()
            },
        )
        // Supabase's data API over SQL tables kept in the primary Couch (/rest/v1/*, /pg/query), plus DB.DBA.RDF_QUAD,
        // the breadcrumbs of every session and, when the belief bag runs, its beliefs; the pg wire reads the same catalog.
        val postgrestWire = borg.trikeshed.forge.server.PostgrestWire(couchDb) {
            quadStore.tables() +
                borg.trikeshed.cursor.query.CursorTable("breadcrumbs") { breadcrumbContexts.table } +
                listOfNotNull(beliefBag?.let { bag -> borg.trikeshed.cursor.query.CursorTable("nars_beliefs") { bag.cursor() } })
        }
        val extraRouteList: List<borg.trikeshed.litebike.ExtraRoute> = listOfNotNull(
            graalWire::route, vmWire::route, piWire::route, hermesWire::route, beliefWire?.let { it::route },
            patchWire::route, moduleWire::route, webhookWire::route, blackboardWire::route, rdfWire::route,
            reteWire::route, blipWire::route, agentWire::route, sleeveWire::route, postgrestWire::route, sparqlWire::route,
        )
        // ── the surface family: node types the canvas could only reach by fetch ──
        // blackboard.*, graal.vitals/heap, vms.list, panels.list … existed (board.get /
        // board.view moved to KanbanModule: units over BoardStoreElement, not a self-fetch)
        // as contracts plus small JS wrappers, so a headless run (webhook delivery,
        // /api/lcnc/run, a scheduled program) threw LcncUnknownNodeType — preset-hermes
        // could not run outside a browser tab. These dispatch to the daemon's OWN
        // handlers in process: one author, no second implementation to drift.
        moduleContext.lcncRunners.putAll(
            borg.trikeshed.lcnc.SurfaceNodes.registry { method, path, body ->
                val text = buildString {
                    append(method).append(' ').append(path).append(" HTTP/1.1\r\n")
                    append("Content-Type: application/json\r\n\r\n")
                    if (body != null) append(jsonOf(body))
                }
                val claimed = moduleRoutes.match(path)?.route
                val response = claimed?.invoke(method, path, text, null)
                    ?: extraRouteList.firstNotNullOfOrNull { it(method, path, text, null) }
                response?.body?.let { runCatching { reify(it) }.getOrDefault(it) }
            },
        )
        val kanbanServer = JvmKanbanServer(
            extraRoutes = extraRouteList,
            rawRoutes = listOfNotNull(graalWire::ingestRoute, couchWire::route, projectDbWire::route, casReflinkWire?.let { it::route }, wikiReadWire::route),
            streamingPaths = borg.trikeshed.forge.server.CouchWire.streamingPaths(COUCH_DB_NAME) +
                    borg.trikeshed.forge.server.GraalWire.STREAMING +
                    borg.trikeshed.forge.server.VmWire.STREAMING +
                    borg.trikeshed.forge.server.HermesConsoleWire.STREAMING +
                    borg.trikeshed.forge.server.BlackboardWire.STREAMING,
            maxRequestBatch = 4096,
            stateDir = jfile(forgeHome),
            moduleRoutes = moduleRoutes,
        )
        return WireSurfaces(postgrestWire, kanbanServer)
    }

    /** Per-case commands and snapshot receipts share the daemon's existing storage owners. */
    internal fun councilCaseRegistry(
        scope: kotlinx.coroutines.CoroutineScope,
        cas: borg.trikeshed.job.CasStore,
        couch: borg.trikeshed.couch.Couch,
    ): borg.trikeshed.lcnc.CouncilCaseRegistry = borg.trikeshed.lcnc.councilCaseRegistry(scope, cas, couch)

    /** Host adapters acknowledge persistence before exposing derived Council facts. */
    internal fun councilRecordSeams(
        cas: borg.trikeshed.job.CasStore,
        couch: borg.trikeshed.couch.Couch,
        blackboard: borg.trikeshed.graal.ConfixBlackboard,
        kif: borg.trikeshed.kif.KifKnowledgeBase,
        cases: borg.trikeshed.lcnc.CouncilCaseRegistry,
    ): borg.trikeshed.lcnc.RecordSeams {
        val couchPut: (String, Map<String, Any?>) -> Unit = { id, body ->
            val rev = couch.docJson(id)?.get("_rev") as? String
            borg.trikeshed.lcnc.RecordSeams.requireCouchWrite(id, couch.put(id, body, rev))
        }
        return borg.trikeshed.lcnc.RecordSeams(
            casPut = { cas.put(it).value },
            blackboardPut = { key, fact, source -> blackboard.put(key, fact, source) },
            kifSink = { expression ->
                val cid = borg.trikeshed.job.ContentId.of(expression.encodeToByteArray())
                couchPut("kif-ledger/${cid.hex}", mapOf("kif" to expression, "source" to "council",
                    "atMs" to HostSystem.currentTimeMillis()))
                kif.assertKif(expression)
                blackboard.put("legal-kif/${cid.hex}", expression, "council.record")
            },
            couchPut = couchPut,
            recordRuling = cases::recordRuling,
            recordMistrial = cases::recordMistrial,
            blackboardGet = { key ->
                (blackboard.get(key) as? Map<*, *>)?.entries?.associate { (k, v) -> k.toString() to (v?.toString() ?: "") }
            },
            couchGet = couch::docJson,
            casGet = { cid -> cas.get(borg.trikeshed.job.ContentId(cid)) },
        )
    }

    private suspend fun CoroutineScope.worktreeReconciliation(
        repoDir: File,
        gateway: WorktreeCouchGateway,
        index: borg.trikeshed.memory.CouchIndexBridge,
        memory: borg.trikeshed.memory.MemoryStore,
        attachments: CouchAttachmentGateway,
        cas: borg.trikeshed.job.CasStore,
        gitState: GitStateCache,
    ): borg.trikeshed.util.oroboros.element.WorktreeReconcileElement {
        val element = borg.trikeshed.util.oroboros.element.WorktreeReconcileElement(
            repoRoot = repoDir.absolutePath,
            worktreeCouchGateway = gateway,
            couchIndexBridge = index,
            memoryBridge = borg.trikeshed.util.oroboros.MemoryBridge(memory, attachments, borg.trikeshed.cas.IpfsBridge(cas)),
            headShaProvider = { gitState.headSha() },
            parentJob = coroutineContext[kotlinx.coroutines.Job],
        )
        element.open()
        return element
    }

    private fun buildPlanes(
        fileOps: JvmFileOperations,
        attachmentGateway: CouchAttachmentGateway,
        repoDir: File,
        forgeHome: File,
    ): BuildPlanes {
        val buildClassesDir = File(Files.resolvePath(repoDir, "build/live/classes"))
        val stagingLibDir = File(Files.resolvePath(repoDir, "build/staging/lib"))
        val buildClassesGateway = WorktreeCouchGateway(
            fileOps, attachmentGateway,
            prefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/live/classes/",
            excludedSegments = emptySet(), excludedRelativePrefixes = emptySet(),
        )
        val stagingLibGateway = WorktreeCouchGateway(
            fileOps, attachmentGateway,
            prefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/staging/lib/",
            excludedSegments = emptySet(), excludedRelativePrefixes = emptySet(),
        )
        // Third narrow plane: jvm resources (web/*, META-INF/services) — without them a
        // forge-booted instance serves no console page. Plus the hotswap agent jar, so the
        // hydrated runtime is launchable end-to-end from the manifest alone.
        val processedResourcesDir = File(Files.resolvePath(repoDir, "build/processedResources/jvm/main"))
        val resourcesGateway = WorktreeCouchGateway(
            fileOps, attachmentGateway,
            prefix = WorktreeCouchGateway.WORKTREE_PREFIX + "build/resources/",
            excludedSegments = emptySet(), excludedRelativePrefixes = emptySet(),
        )
        return BuildPlanes(
            attachments = attachmentGateway,
            classesGateway = buildClassesGateway, classesDir = buildClassesDir,
            libGateway = stagingLibGateway, libDir = stagingLibDir,
            resourcesGateway = resourcesGateway, resourcesDir = processedResourcesDir,
            agentJar = File(Files.resolvePath(repoDir, "build/libs/hotswap-agent.jar")),
            manifestFile = File(Files.resolvePath(forgeHome, ".oroboros/manifests/classpath.tsv")),
        )
    }

    private suspend fun couchKeyStore(couchDb: borg.trikeshed.couch.Couch, keyMux: borg.trikeshed.agent.keymux.KeyMux): borg.trikeshed.agent.keymux.CouchKeyStore {
        val couchKeyStore = borg.trikeshed.agent.keymux.CouchKeyStore(couchDb)
        // Seed CouchKeyStore from the daemon's KeyMux so the prefill
        // dropdown resolves real keys from env/hermes/harness stores.
        runCatching {
            for (i in 0 until borg.trikeshed.agent.keymux.HarnessRegistry.providers.size) {
                val p = borg.trikeshed.agent.keymux.HarnessRegistry.providers[i]
                val k = kotlinx.coroutines.withContext(Dispatchers.IO) {
                    keyMux.get("llm.${p.id}.key")
                }
                val u = kotlinx.coroutines.withContext(Dispatchers.IO) {
                    keyMux.get("llm.${p.id}.base_url")
                }
                if (!k.isNullOrBlank()) {
                    couchKeyStore.storeCredential(
                        p.id, k,
                        u ?: p.defaultBaseUrl ?: "",
                        "openai",
                    )
                }
            }
        }
        return couchKeyStore
    }

    private fun memoryStore(
        casStore: borg.trikeshed.job.CasStore,
        couchStore: borg.trikeshed.couch.CouchStore,
        blackboard: borg.trikeshed.graal.ConfixBlackboard,
        files: borg.trikeshed.userspace.nio.file.spi.FileOperations,
        forge: String,
    ): borg.trikeshed.memory.MemoryStore {
        val memoryStore = borg.trikeshed.memory.MemoryStore(casStore, couchStore)


        // R2: the inverted index is an appendable ISAM cursor of its lines. At boot, restore the continent from its
        // rows (no cold re-derive); every ingest appends only the new spine's rows.
        val spines = borg.trikeshed.cas.LineCasSpineIsam(files.resolvePath(forge, ".oroboros", "linecas.isam"), files)
        spines.restore()?.let { restored ->
            memoryStore.restoreIndex(restored)
            HostSystem.err("[OROBOROS] LineCasIndex restored from store: ${restored.documentCount} docs, ${restored.contentKeyCount} content keys")
            // Durable fact, not a log line: the board carries what the boot actually did.
            blackboard.put(
                "daemon/linecas-index",
                mapOf("docs" to restored.documentCount.toString(), "contentKeys" to restored.contentKeyCount.toString()),
                "oroboros",
            )
        }
        memoryStore.onIndexIngest = { spine ->
            runCatching { spines.append(spine) }
                .onFailure { t -> HostSystem.err("[OROBOROS] LineCasIndex append failed: ${t.message}") }
        }
        return memoryStore
    }

    /** Pi boot remains independent of the Hermes VM and outside the size-limited daemon boot method. */
    private fun piWire(
        config: DaemonConfig,
        htxElement: HtxElement,
        muxReactor: MuxReactorElement,
        scope: CoroutineScope,
        breadcrumbContexts: borg.trikeshed.agent.modelmux.BreadcrumbElement,
    ): borg.trikeshed.forge.server.PiWire = borg.trikeshed.forge.server.PiWire(
        scope, htxElement + muxReactor + (scope.coroutineContext[Airgap] ?: Airgap(config.airgap)),
        breadcrumbContexts, { muxReactor.modelMux() },
        HostSystem.getProperty(borg.trikeshed.forge.server.PiWire.TOKEN_PROPERTY)?.trim()?.takeIf { it.isNotEmpty() },
    )

    private suspend fun drainPi(wire: borg.trikeshed.forge.server.PiWire) {
        runCatching { wire.drain() }.onFailure {
            HostSystem.err("[OROBOROS] Pi drain failed: ${it.message}")
        }
    }

    private suspend fun hermesWire(
        config: DaemonConfig,
        home: String,
        repoDir: File,
        forgeHome: File,
        blackboard: borg.trikeshed.graal.ConfixBlackboard,
        htxElement: HtxElement,
        muxReactor: MuxReactorElement,
        socketScope: CoroutineScope,
        world: borg.trikeshed.btrfs.BtrfsWorldStore,
        fileOps: borg.trikeshed.userspace.nio.file.spi.FileOperations,
        breadcrumbContexts: borg.trikeshed.agent.modelmux.BreadcrumbElement,
    ): borg.trikeshed.forge.server.HermesConsoleWire {
        val console = hermesConsole(config, home, repoDir, forgeHome, blackboard,
            htxElement, muxReactor, socketScope, world, fileOps, breadcrumbContexts)
        val wire = borg.trikeshed.forge.server.HermesConsoleWire(console, socketScope) { panelId ->
            hermesConsole(config, home, repoDir, forgeHome, blackboard,
                htxElement, muxReactor, socketScope, world, fileOps, breadcrumbContexts, panelId)
        }
        if (config.hermesConsole) check(wire.open()) { "Hermes console did not admit startup" }
        return wire
    }

    /** The console shares the daemon board and resolves the current reactor-owned model lease per call. */
    private fun hermesConsole(
        config: DaemonConfig,
        home: String,
        repoDir: File,
        forgeHome: File,
        blackboard: borg.trikeshed.graal.ConfixBlackboard,
        htxElement: HtxElement,
        muxReactor: MuxReactorElement,
        socketScope: CoroutineScope,
        world: borg.trikeshed.btrfs.BtrfsWorldStore,
        fileOps: borg.trikeshed.userspace.nio.file.spi.FileOperations,
        breadcrumbContexts: borg.trikeshed.agent.modelmux.BreadcrumbElement,
        panelId: String = "default",
    ): borg.trikeshed.hermes.HermesVmConsole {
        val runtime = File(forgeHome, "python/graalpy-25.3.4.1")
        // The pinned Hermes fork is checked out as a submodule under utils.
        val source = config.hermesRoot ?: HostSystem.getenv("HERMES_SOURCE_ROOT")
            ?: File(repoDir, "utils/hermes-trikeshed-graalpy").absolutePath
        val workerHome = File(forgeHome, "hermes-graal")
        fileOps.mkdirs(workerHome.absolutePath)
        return borg.trikeshed.hermes.HermesVmConsole(
        root = java.nio.file.Paths.get(source),
        sleeve = java.nio.file.Paths.get(
            config.hermesSleeve ?: HostSystem.getenv("HERMES_GRAAL_SLEEVE")
                ?: File(Files.resolvePath(repoDir, "utils/graalpy-sleeve/hermes")).absolutePath
                ?: error("no hermes sleeve"),
        ),
        blackboard = blackboard,
        modelMuxProvider = { muxReactor.modelMux() },
        muxContext = htxElement + muxReactor + breadcrumbContexts + (socketScope.coroutineContext[Airgap] ?: Airgap(config.airgap)),
        socketScope = socketScope,
        world = world,
        workerConfiguration = if (nativeHermesWorker(config)) borg.trikeshed.graal.subvm.PythonWorker(
            timeoutMillis = 900_000,
            workingDirectory = repoDir.absolutePath,
            pythonPath = listOf(
                source,
                File(repoDir, "utils/graalpy-sleeve/bridges").absolutePath,
            ),
            // The port's README builds its interpreter at <checkout>/.venv-graalpy.
            executable = File(runtime, "venv/bin/python").takeIf { it.isFile() }?.absolutePath
                ?: File(source, ".venv-graalpy/bin/python").absolutePath,
            arguments = listOf("hermes"),
            environment = mapOf(
                "HOME" to workerHome.absolutePath,
                "XDG_STATE_HOME" to File(workerHome, ".local/state").absolutePath,
                "HERMES_HOME" to workerHome.absolutePath,
                "HERMES_RUNTIME_DIR" to File(workerHome, "runtime").absolutePath,
                "HERMES_DISABLE_LAZY_INSTALLS" to "1",
                "HERMES_EXIT_WATCHDOG_S" to "0",
                "TERMINAL_CWD" to repoDir.absolutePath,
                "TERM" to "xterm-256color",
                "COLUMNS" to "100", "LINES" to "32",
            ),
        ) else null,
        panelId = panelId,
        breadcrumbs = true,
        )
    }

    /** Explicit primary format selection; only commit mode permits a volatile CAS projection. */
    internal fun openCouchStorage(
        casStore: borg.trikeshed.job.CasStore,
        fileOps: borg.trikeshed.userspace.nio.file.spi.FileOperations,
        forgeHome: File,
        scope: CoroutineScope,
        format: CouchStorageFormat = CouchStorageFormat.parse(HostSystem.getenv("TRIKESHED_COUCH_FORMAT")),
    ): CouchStorage {
        val storage = CouchStorage.open(COUCH_DB_NAME, casStore, fileOps,
            fileOps.resolvePath(forgeHome.absolutePath, "couch"), format,
            borg.trikeshed.isam.UringIsamOperations(scope, leafBytes = 64 * 1024,
                leafCodec = borg.trikeshed.isam.CasLeafCodec(casStore, { borg.trikeshed.isam.ZstdDictionaryCodec(it) })),
        )
        HostSystem.err("[OROBOROS] couch store: ${casStore.durability} ${format.id} (${storage.couch.store.size} docs recovered)")
        return storage
    }

    /** The redacted mux working set, published to the board on every reactor state publication. */
    private fun kotlinx.coroutines.CoroutineScope.launchMuxBlackboardHome(
        muxReactor: borg.trikeshed.userspace.reactor.MuxReactorElement,
        quotaLegion: borg.trikeshed.agent.modelmux.QuotaLegion,
        daemonBlackboard: borg.trikeshed.graal.ConfixBlackboard,
    ) = launch {
        muxReactor.flowState.collect { state ->
            val entries = borg.trikeshed.userspace.reactor.MuxBlackboardProjection.entries(
                state,
                quotaLegion.standings(state, HostSystem.currentTimeMillis()),
                muxReactor.providerHealth,
            )
            for (i in 0 until entries.size) {
                val (key, value) = entries[i]
                daemonBlackboard.put(key, value, borg.trikeshed.userspace.reactor.MuxBlackboardProjection.SOURCE)
            }
        }
    }

    internal suspend fun preflight(repoDir: File): Boolean {
        // git fetch origin master (best-effort, 5s timeout)
        val fetchOk = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val builder = ProcessBuilder("git", "fetch", "origin", "master", "--dry-run").directory(jfile(repoDir))
            builder.environment().apply { clear(); putAll(borg.trikeshed.graal.subvm.GuestEnvironment.curated()) }
            val fetch = builder.start()
            val finished = fetch.waitFor(5, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) fetch.destroyForcibly()
            finished && fetch.exitValue() == 0
        }
        if (!fetchOk) return true // offline is OK, we'll poll anyway

        suspend fun command(vararg args: String): String = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val builder = ProcessBuilder(*args).directory(jfile(repoDir)).redirectErrorStream(true)
            builder.environment().apply { clear(); putAll(borg.trikeshed.graal.subvm.GuestEnvironment.curated()) }
            val p = builder.start()
            val outAsync = java.util.concurrent.CompletableFuture.supplyAsync { p.inputStream.bufferedReader().readText().trim() }
            val finished = p.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) {
                p.destroyForcibly()
                p.waitFor()
                return@withContext ""
            }
            outAsync.get(5, java.util.concurrent.TimeUnit.SECONDS)
        }

        val local = command("git", "rev-parse", "HEAD")
        val remote = command("git", "rev-parse", "origin/master")
        if (local == remote) return true
        // Local ahead of remote is normal between pushes. Only block when truly
        // diverged: local has commits origin doesn't AND vice versa.
        val mergeBase = command("git", "merge-base", local, remote)
        if (mergeBase == local || mergeBase == remote) {
            // linear: local ahead OR local behind, but not both
            return true
        }
        // local is neither reachable from remote nor vice versa → diverged
        println("[OROBOROS] UPSTREAM-DIVERGED local=$local remote=$remote mergeBase=$mergeBase")
        return false
    }

    private fun die(msg: String): Nothing {
        HostSystem.err("[OROBOROS] $msg")
        usage()
        exitProcess(2)
    }

    private fun usage() {
        HostSystem.err(
            """usage: OroborosDaemon [--once | --watch] [--airgap] [--interval-ms N] [--max-slots N] [--kanban-port N] [--pg-port N]
              [--hermes-root PATH] [--hermes-sleeve PATH] [--hermes-console] [--hermes-native-worker] [forgeHome] [repoDir]
              --airgap: disable remote Jev/LLM calls; keep local BERT
              --hermes-native-worker: enable OWN-trust native Hermes worker (not a sandbox; incompatible with --airgap)
              env: JULES_API_KEY (required)
                   HERMES_SOURCE_ROOT / HERMES_GRAAL_SLEEVE (optional)
                   TRIKESHED_AIRGAP (or JVM property trikeshed.airgap) also enables airgap;
                   the curator is airgapped unless it is set off (TRIKESHED_AIRGAP=off)
              forgeHome default: ~/.local/forge (ForgeHome.defaultHome)
              repoDir  default: cwd
              kanban-port default: 8888
              pg-port default: 5433 (the pg wire: psql, pgjdbc; 0 for an ephemeral port)"""
        )
    }
}




/**
 * reap-append — post-DELETE WorkDrained causes to the WAL so the conductor's
 * `cards` projection no longer re-adopts the deleted sessions on next poll.
 *
 * Reads a list of session ids from the path passed as arg[0], emits one
 * `SessionCause.WorkDrained` cause per id (with `commitSha="outbox:<short>"`)
 * so the session is permanently retired from the live map.
 */
object ReapAppend {
    @JvmStatic
    fun main(args: Array<String>) = runBlocking {
        val listPath = args.getOrNull(0) ?: error("usage: ReapAppend <sid-list.txt> [wal-path]")
        val walPath = args.getOrNull(1)
            ?: File(HostSystem.getProperty("user.home") ?: error("no user.home"), ".local/forge/jules-board.wal").absolutePath
        val store = SessionBoardStore(JvmAppendWal(java.io.File(walPath ?: error("no wal-path"))).also {
            java.io.File(walPath!!).parentFile.mkdirs()
        })
        val sids = File(listPath).readLines().filter { it.isNotBlank() }
        println("appending WorkDrained for ${sids.size} sessions to $walPath")
        var ok = 0
        for (sid in sids) {
            val commitSha = "outbox-${sid.take(7)}"
            store.appendWork(sid, SessionCause.WorkDrained(
                workId = "reap-${sid}",
                sessionId = sid,
                commitSha = commitSha,
                taskId = "reap-pass",
                at = HostSystem.currentTimeMillis(),
            ))
            ok++
        }
        println("appended $ok WorkDrained causes")
    }
}
