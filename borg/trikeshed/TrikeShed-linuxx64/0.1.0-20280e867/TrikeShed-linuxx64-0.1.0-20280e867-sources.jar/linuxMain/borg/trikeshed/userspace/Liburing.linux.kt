@file:OptIn(kotlin.experimental.ExperimentalNativeApi::class, kotlinx.cinterop.ExperimentalForeignApi::class)

package borg.trikeshed.userspace

import kotlinx.cinterop.*
import borg.trikeshed.lib.Series
import borg.trikeshed.lib.size
import borg.trikeshed.lib.get
import zlinux_uring.IORING_FSYNC_DATASYNC
import zlinux_uring.io_uring
import zlinux_uring.io_uring_cqe
import zlinux_uring.io_uring_cqe_seen
import zlinux_uring.io_uring_get_sqe
import zlinux_uring.io_uring_peek_cqe
import zlinux_uring.io_uring_prep_accept
import zlinux_uring.io_uring_prep_close
import zlinux_uring.io_uring_prep_connect
import zlinux_uring.io_uring_prep_socket
import zlinux_uring.io_uring_prep_bind
import zlinux_uring.io_uring_prep_listen
import zlinux_uring.io_uring_prep_poll_add
import zlinux_uring.io_uring_prep_poll_remove
import zlinux_uring.io_uring_prep_shutdown
import zlinux_uring.io_uring_prep_fsync
import zlinux_uring.io_uring_prep_ftruncate
import zlinux_uring.k_io_uring_prep_sendmsg
import zlinux_uring.k_io_uring_prep_recvmsg
import zlinux_uring.io_uring_prep_read
import zlinux_uring.io_uring_prep_write
import zlinux_uring.io_uring_queue_exit
import zlinux_uring.io_uring_queue_init
import zlinux_uring.io_uring_submit
import zlinux_uring.io_uring_wait_cqe

internal actual object LiburingImpl : LiburingFacade by LiburingSession()

/**
 * Compile-time native-depth gate for the Linux actual.
 *
 * 1 = liburing cinterop (the compiled-in kernel ring; probes opcode support)
 *
 * The facade surface is byte-identical above; this const exists so the three
 * targets present one gate shape — JVM, JS and Linux each pin a native depth
 * ceiling that the runtime probe cannot exceed. Going more native means
 * raising the const, never adding a second API.
 */
internal const val LINUX_NATIVE_URING_LEVEL: Int = 1

/** IORING_SETUP_SUBMIT_ALL (Linux 5.18): an SQE that fails to issue does not stop the ones after it. */
internal const val SETUP_SUBMIT_ALL: Int = 0x80


/** Each userspace backend owns one of these rings. The legacy singleton is separate. */
internal class LinuxLiburingFacade : LiburingFacade {
    private var ring: CPointer<io_uring>? = null
    val completionFd: Int get() = ring?.pointed?.ring_fd ?: -1
    /** [peekCqe]'s out-parameter, allocated on first use and freed with the ring. */
    private var cqeSlot: CPointerVar<io_uring_cqe>? = null
    private var inFlight = 0
    private val requests = mutableMapOf<Long, Int>()
    private var probe: CPointer<zlinux_uring.io_uring_probe>? = null
    var features: UInt = 0u
        private set
    /** The errno io_uring_queue_init or the probe registration of [open] failed with. */
    var setupErrno: Int? = null
        private set
    /** Whether [open] set the ring up with IORING_SETUP_SUBMIT_ALL: one enter submits every queued SQE. */
    var submitAll: Boolean = false
        private set
    fun supports(op: UringOp): Boolean = op.code >= 0 && probe?.let {
        zlinux_uring.io_uring_opcode_supported(it, op.code) != 0
    } == true

    private val handlers = mutableMapOf<Long, MutableList<(UringCompletion) -> Unit>>()

    override fun open(entries: Int, flags: Int): Result<Unit> {
        if (ring != null) return Result.success(Unit)
        if (entries <= 0) return failure("entries must be positive", -22)
        val allocated = nativeHeap.alloc<io_uring>()
        val rc = io_uring_queue_init(entries.toUInt(), allocated.ptr, flags.toUInt())
        if (rc < 0) {
            nativeHeap.free(allocated.ptr)
            setupErrno = -rc
            return failure("io_uring_queue_init failed", rc)
        }
        ring = allocated.ptr
        features = allocated.features
        setupErrno = null
        submitAll = flags and SETUP_SUBMIT_ALL != 0
        probe = zlinux_uring.io_uring_get_probe_ring(allocated.ptr)
        if (probe == null) {
            val probeError = platform.posix.errno
            close()
            setupErrno = probeError
            return failure("io_uring_register probe failed", -probeError)
        }
        return Result.success(Unit)
    }

    /** Before borrowing any application resource, prove enter and CQ retrieval work. */
    fun probeExecution(): Result<Unit> {
        check(inFlight == 0) { "execution probe must precede application admission" }
        val token = Long.MIN_VALUE
        val prepared = prepSubmission(UringOp.Companion.Submissions.nop(token), 0)
        val submitted = if (prepared.isSuccess) submit() else Result.failure(prepared.exceptionOrNull()!!)
        val completion = if (submitted.getOrNull() == 1) waitCqe() else null
        val terminal = completion?.getOrNull()
        if (terminal?.userData == token && terminal.res == 0) return Result.success(Unit)
        val detail = prepared.exceptionOrNull() ?: submitted.exceptionOrNull() ?: completion?.exceptionOrNull()
        // Only a NOP has been prepared here: no caller buffer or descriptor is
        // borrowed, so discarding this probe cannot release application memory.
        exitRing()
        return Result.failure(IllegalStateException("io_uring NOP execution probe failed: ${terminal?.res ?: detail?.message}"))
    }

    val submissionSpace: Int get() = ring?.let { zlinux_uring.io_uring_sq_space_left(it).toInt() } ?: 0
    val pendingSubmissions: Int get() = ring?.let { zlinux_uring.io_uring_sq_ready(it).toInt() } ?: 0

    override fun prepCancel(targetUserData: Long, userData: Long): Result<Unit> =
        prepare(userData) { sqe -> zlinux_uring.io_uring_prep_cancel64(sqe, targetUserData.toULong(), 0) }

    override fun prepRead(fd: Int, bufAddress: Long, len: Int, offset: Long, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_read(sqe, fd, bufAddress.toCPointer<ByteVar>(), len.toUInt(), offset.toULong())
        }

    override fun prepWrite(fd: Int, bufAddress: Long, len: Int, offset: Long, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_write(sqe, fd, bufAddress.toCPointer<ByteVar>(), len.toUInt(), offset.toULong())
        }

    override fun prepAccept(fd: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_accept(sqe, fd, null, null, 0)
        }

    override fun prepConnect(fd: Int, addrPtr: Long, addrLen: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_connect(
                sqe,
                fd,
                addrPtr.toCPointer<ByteVar>()?.reinterpret(),
                addrLen.toUInt(),
            )
        }

    override fun prepSocket(domain: Int, type: Int, protocol: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_socket(sqe, domain, type, protocol, 0u)
        }

    override fun prepBind(fd: Int, addrPtr: Long, addrLen: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_bind(sqe, fd, addrPtr.toCPointer<ByteVar>()?.reinterpret(), addrLen.toUInt())
        }

    override fun prepListen(fd: Int, backlog: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_listen(sqe, fd, backlog)
        }

    override fun prepPollAdd(fd: Int, pollMask: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_poll_add(sqe, fd, pollMask.toUInt())
        }

    override fun prepPollRemove(targetUserData: Long, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_poll_remove(sqe, targetUserData.toULong())
        }

    override fun prepShutdown(fd: Int, how: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_shutdown(sqe, fd, how)
        }

    override fun prepClose(fd: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_close(sqe, fd)
        }

    override fun prepFsync(fd: Int, userData: Long, datasync: Boolean): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_fsync(sqe, fd, if (datasync) IORING_FSYNC_DATASYNC.toUInt() else 0u)
        }

    override fun prepFtruncate(fd: Int, size: Long, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            io_uring_prep_ftruncate(sqe, fd, size)
        }

    override fun prepSendmsg(fd: Int, msgHdrPtr: Long, flags: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            k_io_uring_prep_sendmsg(sqe, fd, msgHdrPtr.toCPointer<COpaque>(), flags.toUInt())
        }

    override fun prepRecvmsg(fd: Int, msgHdrPtr: Long, flags: Int, userData: Long): Result<Unit> =
        prepare(userData) { sqe ->
            k_io_uring_prep_recvmsg(sqe, fd, msgHdrPtr.toCPointer<COpaque>(), flags.toUInt())
        }

    override fun submit(): Result<Int> {
        val currentRing = ring ?: return failure("liburing ring is not open")
        var rc: Int
        do { rc = io_uring_submit(currentRing) } while (rc == -platform.posix.EINTR)
        return if (rc < 0) failure("io_uring_submit failed", rc) else Result.success(rc)
    }

    override fun waitCqe(): Result<UringCompletion?> {
        val currentRing = ring ?: return failure("liburing ring is not open")
        memScoped {
            val cqe = alloc<CPointerVar<io_uring_cqe>>()
            var rc: Int
            do { rc = io_uring_wait_cqe(currentRing, cqe.ptr) } while (rc == -platform.posix.EINTR)
            if (rc < 0) return failure("io_uring_wait_cqe failed", rc)
            val ready = cqe.value ?: return failure("io_uring_wait_cqe returned no CQE")
            val completion = ready.toCompletion()
            io_uring_cqe_seen(currentRing, ready)
            settled(completion.userData)
            publish(completion)
            return Result.success(completion)
        }
    }

    override fun peekCqe(): Result<UringCompletion?> {
        val currentRing = ring ?: return failure("liburing ring is not open")
        // One CQE pointer slot per ring, not a malloc'd scope per peek.
        val cqe = cqeSlot ?: nativeHeap.alloc<CPointerVar<io_uring_cqe>>().also { cqeSlot = it }
        var rc: Int
        do { rc = io_uring_peek_cqe(currentRing, cqe.ptr) } while (rc == -platform.posix.EINTR)
        if (rc == -platform.posix.EAGAIN) return Result.success(null)
        if (rc < 0) return failure("io_uring_peek_cqe failed", rc)
        val ready = cqe.value ?: return Result.success(null)
        val completion = ready.toCompletion()
        io_uring_cqe_seen(currentRing, ready)
        settled(completion.userData)
        publish(completion)
        return Result.success(completion)
    }

    override fun cqAdvance(count: Int) {
        // waitCqe/peekCqe transfer ownership and advance exactly once.
        require(count >= 0)
    }

    /** Waits up to [timeoutMicros] for a CQE without consuming it: 0 once one is ready, -ETIME at the timeout. */
    fun awaitCqe(timeoutMicros: Long): Int {
        val currentRing = ring ?: return -platform.posix.EBADF
        return zlinux_uring.k_io_uring_await_cqe(currentRing, timeoutMicros)
    }

    override fun registerFanoutHandler(token: Long, handler: (UringCompletion) -> Unit) {
        handlers.getOrPut(token) { mutableListOf() }.add(handler)
    }

    override fun removeFanoutHandler(token: Long, handler: (UringCompletion) -> Unit) {
        handlers[token]?.remove(handler)
        if (handlers[token].isNullOrEmpty()) handlers.remove(token)
    }

    override fun drain(): Result<Unit> {
        if (ring == null) return Result.success(Unit)
        while (pendingSubmissions > 0) {
            val submitted = submit()
            if (submitted.isFailure) return Result.failure(submitted.exceptionOrNull()!!)
            if (submitted.getOrThrow() == 0) return failure("io_uring_submit (drain) made no progress")
        }
        while (inFlight > 0) {
            val completion = waitCqe()
            if (completion.isFailure) return Result.failure(completion.exceptionOrNull()!!)
        }
        return Result.success(Unit)
    }

    override fun close(): Result<Unit> {
        if (ring == null) return Result.success(Unit)
        val drained = drain()
        if (drained.isFailure) return drained
        exitRing()
        return Result.success(Unit)
    }

    private fun exitRing() {
        val currentRing = ring ?: return
        probe?.let { zlinux_uring.io_uring_free_probe(it) }
        probe = null
        io_uring_queue_exit(currentRing)
        nativeHeap.free(currentRing.rawValue)
        ring = null
        cqeSlot?.let { nativeHeap.free(it.rawPtr) }
        cqeSlot = null
        requests.clear()
        inFlight = 0
        handlers.clear()
    }

    override fun registerBuffers(buffers: Series<MemoryMapping>): Result<Unit> {
        val current = ring ?: return failure("ring is not open", -9)
        return memScoped {
            val vectors = allocArray<platform.posix.iovec>(buffers.size)
            for (index in 0 until buffers.size) {
                vectors[index].iov_base = buffers[index].address.toCPointer<ByteVar>()
                vectors[index].iov_len = buffers[index].length.toULong()
            }
            val rc = zlinux_uring.io_uring_register_buffers(current, vectors, buffers.size.toUInt())
            if (rc < 0) failure("io_uring_register_buffers failed", rc) else Result.success(Unit)
        }
    }

    override fun unregisterBuffers(): Result<Unit> {
        val current = ring ?: return failure("ring is not open", -9)
        val rc = zlinux_uring.io_uring_unregister_buffers(current)
        return if (rc < 0) failure("io_uring_unregister_buffers failed", rc) else Result.success(Unit)
    }

    fun prepSubmission(sub: UringOp.Companion.UringSubmission, address: Long, userData: Long = sub.userData): Result<Unit> {
        if (sub.flags != 0) return failure("SQE flags unsupported", -95)
        if (!supports(sub.opcode)) return failure("opcode not supported by kernel probe", -95)
        return prepare(userData) { sqe -> encode(sqe, sub, address) }
    }

    /**
     * [sub] into the next SQE with user_data [index], outside the per-request bookkeeping: [submitReap] settles it
     * before anything else enters this ring. False, with no SQE taken, when the ring is closed, the SQ is full or the
     * kernel lacks the op.
     */
    fun prepIndexed(sub: UringOp.Companion.UringSubmission, address: Long, index: Int): Boolean {
        val currentRing = ring ?: return false
        if (sub.flags != 0 || !supports(sub.opcode)) return false
        val sqe = io_uring_get_sqe(currentRing) ?: return false
        try { encode(sqe, sub, address) } catch (error: Throwable) {
            currentRing.pointed.sq.sqe_tail--
            throw error
        }
        sqe.pointed.user_data = index.toULong()
        return true
    }

    /** Returns the last [count] SQEs [prepIndexed] took, none of them submitted yet. */
    fun unprepIndexed(count: Int) {
        val currentRing = ring ?: return
        currentRing.pointed.sq.sqe_tail -= count.toUInt()
    }

    /**
     * Submits the [count] SQEs [prepIndexed] filled (indices 0 until [count]) in one enter and writes each CQE's res
     * at its index in [results]; returns once all of them are reaped, with the number of other CQEs met (0 normally).
     */
    fun submitReap(count: Int, results: CPointer<IntVar>): Int =
        zlinux_uring.k_io_uring_submit_reap(checkNotNull(ring) { "liburing ring is not open" }, count.toUInt(),
            if (submitAll) 1 else 0, results)

    private fun encode(sqe: CPointer<zlinux_uring.io_uring_sqe>, sub: UringOp.Companion.UringSubmission, address: Long) {
        val ptr = address.toCPointer<ByteVar>()
        when (sub.opcode) {
            UringOp.NOP -> zlinux_uring.io_uring_prep_nop(sqe)
            UringOp.OPENAT -> zlinux_uring.io_uring_prep_openat(sqe, sub.fd, ptr, openFlags(sub.offset.toInt()), sub.operationFlags.toUInt())
            UringOp.STATX -> zlinux_uring.io_uring_prep_statx(sqe, sub.fd, ptr, sub.operationFlags, sub.offset.toUInt(),
                (address + sub.len + 1).toCPointer<cnames.structs.statx>())
            UringOp.MKDIRAT -> zlinux_uring.io_uring_prep_mkdirat(sqe, sub.fd, ptr, sub.operationFlags.toUInt())
            UringOp.UNLINKAT -> zlinux_uring.io_uring_prep_unlinkat(sqe, sub.fd, ptr, sub.operationFlags)
            UringOp.RENAMEAT -> {
                // Both paths ride NUL-separated in the one copied buffer.
                val window = requireNotNull(sub.buffer)
                val start = window.arrayOffset() + window.position()
                val split = (0 until sub.len).first { window.array()[start + it] == 0.toByte() }
                zlinux_uring.io_uring_prep_renameat(sqe, sub.fd, ptr, sub.offset.toInt(),
                    (address + split + 1).toCPointer<ByteVar>(), sub.operationFlags.toUInt())
            }
            UringOp.READ -> {
                io_uring_prep_read(sqe, sub.fd, ptr, sub.len.toUInt(), sub.offset.toULong())
                zlinux_uring.k_io_uring_nowait_if_nonblocking(sqe, sub.fd, sub.offset)
            }
            UringOp.WRITE -> {
                io_uring_prep_write(sqe, sub.fd, ptr, sub.len.toUInt(), sub.offset.toULong())
                zlinux_uring.k_io_uring_nowait_if_nonblocking(sqe, sub.fd, sub.offset)
            }
            UringOp.READ_FIXED -> zlinux_uring.io_uring_prep_read_fixed(sqe, sub.fd, ptr, sub.len.toUInt(), sub.offset.toULong(), sub.bufferIndex)
            UringOp.WRITE_FIXED -> zlinux_uring.io_uring_prep_write_fixed(sqe, sub.fd, ptr, sub.len.toUInt(), sub.offset.toULong(), sub.bufferIndex)
            UringOp.FADVISE -> zlinux_uring.io_uring_prep_fadvise(sqe, sub.fd, sub.offset.toULong(), sub.len.toUInt(), sub.operationFlags)
            UringOp.MADVISE -> zlinux_uring.io_uring_prep_madvise(sqe, ptr, sub.len.toUInt(), sub.operationFlags)
            UringOp.SEND -> zlinux_uring.io_uring_prep_send(sqe, sub.fd, ptr, sub.len.toULong(), 0)
            UringOp.RECV -> zlinux_uring.io_uring_prep_recv(sqe, sub.fd, ptr, sub.len.toULong(), 0)
            // [address] is a msghdr; operationFlags are its msg flags (UringOp.MSG_DONTWAIT completes without a poll).
            UringOp.SENDMSG -> k_io_uring_prep_sendmsg(sqe, sub.fd, address.toCPointer<COpaque>(), sub.operationFlags.toUInt())
            UringOp.RECVMSG -> k_io_uring_prep_recvmsg(sqe, sub.fd, address.toCPointer<COpaque>(), sub.operationFlags.toUInt())
            UringOp.CLOSE -> io_uring_prep_close(sqe, sub.fd)
            UringOp.FSYNC -> io_uring_prep_fsync(sqe, sub.fd, sub.operationFlags.toUInt())
            UringOp.FTRUNCATE -> io_uring_prep_ftruncate(sqe, sub.fd, sub.offset)
            UringOp.SOCKET -> io_uring_prep_socket(sqe, sub.fd, sub.offset.toInt(), sub.len, 0u)
            UringOp.BIND -> io_uring_prep_bind(sqe, sub.fd, ptr?.reinterpret(), sub.len.toUInt())
            UringOp.LISTEN -> io_uring_prep_listen(sqe, sub.fd, sub.len)
            UringOp.ACCEPT -> io_uring_prep_accept(sqe, sub.fd, null, null, sub.operationFlags)
            UringOp.CONNECT -> io_uring_prep_connect(sqe, sub.fd, ptr?.reinterpret(), sub.len.toUInt())
            UringOp.SHUTDOWN -> io_uring_prep_shutdown(sqe, sub.fd, sub.len)
            UringOp.POLL_ADD -> io_uring_prep_poll_add(sqe, sub.fd, sub.operationFlags.toUInt())
            else -> error("No native encoder for ${sub.opcode}")
        }
    }

    /** The facade's asm-generic O_* values in this kernel ABI's numbering: arm64 moves O_DIRECTORY and O_NOFOLLOW. */
    fun openFlags(flags: Int): Int = if (Platform.cpuArchitecture != CpuArchitecture.ARM64) flags
        else (flags and (UringOp.O_DIRECTORY or UringOp.O_NOFOLLOW).inv()) or
            (if (flags and UringOp.O_DIRECTORY != 0) 0x4000 else 0) or (if (flags and UringOp.O_NOFOLLOW != 0) 0x8000 else 0)

    private inline fun prepare(userData: Long, block: (CPointer<zlinux_uring.io_uring_sqe>) -> Unit): Result<Unit> {
        val currentRing = ring ?: return failure("liburing ring is not open")
        val sqe = io_uring_get_sqe(currentRing) ?: return failure("io_uring_get_sqe returned null")
        try { block(sqe) } catch (error: Throwable) {
            // get_sqe reserves only the userspace tail; failed preparation was never published.
            currentRing.pointed.sq.sqe_tail--
            return Result.failure(error)
        }
        sqe.pointed.user_data = userData.toULong()
        inFlight++
        requests[userData] = (requests[userData] ?: 0) + 1
        return Result.success(Unit)
    }

    private fun settled(userData: Long) {
        val count = requests[userData] ?: return
        if (count == 1) requests.remove(userData) else requests[userData] = count - 1
        inFlight--
    }

    private fun publish(completion: UringCompletion) {
        if (handlers.isEmpty()) return
        handlers[completion.userData]?.toTypedArray()?.forEach { handler ->
            runCatching { handler(completion) }
        }
    }

    private fun CPointer<io_uring_cqe>.toCompletion(): UringCompletion =
        UringCompletion(
            userData = pointed.user_data.toLong(),
            res = pointed.res,
            flags = pointed.flags.toInt(),
        )
}

private fun <T> failure(message: String, rc: Int? = null): Result<T> =
    Result.failure(IllegalStateException(if (rc == null) message else "$message: $rc"))
