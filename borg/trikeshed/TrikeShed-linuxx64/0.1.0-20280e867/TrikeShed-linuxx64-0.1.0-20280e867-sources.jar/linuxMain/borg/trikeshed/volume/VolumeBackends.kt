package borg.trikeshed.volume

import borg.trikeshed.userspace.volume.Volume
import borg.trikeshed.userspace.volume.PosixVolume
import borg.trikeshed.userspace.volume.LiburingVolume

actual object VolumeBackends {
    actual fun openPosix(path: String, blockSize: Int, capacityBytes: Long): Volume =
        PosixVolume(path, blockSize, capacityBytes)

    actual fun openLiburing(path: String, blockSize: Int, capacityBytes: Long): Volume =
        LiburingVolume(path, blockSize, capacityBytes)
}
