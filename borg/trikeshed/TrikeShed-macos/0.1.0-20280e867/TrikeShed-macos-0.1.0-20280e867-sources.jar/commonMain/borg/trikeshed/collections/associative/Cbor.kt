package borg.trikeshed.collections.associative

import borg.trikeshed.lib.j

enum class CborLimitKind { BYTES, DEPTH, ITEMS }
class CborLimitException(val kind: CborLimitKind) : IllegalArgumentException("CBOR ${kind.name.lowercase()} limit")

/**
 * CBOR codec for Item -- RFC 8949.
 *
 * Encode: Item -> ByteArray
 * Decode: ByteArray -> Item
 *
 * Supports: unsigned/negative int, byte string, text string,
 * definite-length array, definite-length map, tag, bool, null, float64.
 * Indefinite-length decode supported (converted to definite).
 * Half/float32 decoded to full Double precision.
 */
object Cbor {

    fun encode(item: Item): ByteArray {
        val buf = ByteBuf()
        item.encode(buf)
        return buf.toByteArray()
    }

   fun Item.encode(buf: ByteBuf) {
        when (this) {
            is Item.Num -> {
                if (value >= 0) encodeHead(buf, 0, value)
                else encodeHead(buf, 1, -(value + 1))
            }
            is Item.Str -> {
                val bytes = value.encodeToByteArray()
                encodeHead(buf, 3, bytes.size.toLong())
                buf.write(bytes)
            }
            is Item.Bin -> {
                encodeHead(buf, 2, value.size.toLong())
                buf.write(value)
            }
            is Item.Arr -> {
                encodeHead(buf, 4, items.a.toLong())
                for (i in 0 until items.a) items.b(i).encode(buf)
            }
            is Item.Map -> {
                val sorted = ArrayList<EncodedMapEntry>(entries.a)
                for (i in 0 until entries.a) {
                    val entry = entries.b(i)
                    sorted.add(EncodedMapEntry(encodeMapKey(entry.a), entry.b))
                }
                sorted.sortWith { left, right -> compareUnsigned(left.keyBytes, right.keyBytes) }
                encodeHead(buf, 5, sorted.size.toLong())
                for (entry in sorted) {
                    buf.write(entry.keyBytes)
                    entry.value.encode(buf)
                }
            }
            is Item.Bool -> buf.write(if (value) 0xF5 else 0xF4)
            is Item.Nil -> buf.write(0xF6)
            is Item.Flt -> {
                buf.write(0xFB)
                buf.writeDouble(value)
            }
            is Item.Tag -> {
                encodeHead(buf, 6, tag.toLong())
                item.encode(buf)
            }
        }
    }

    /** [value] is the u64 argument; a tag above Long.MAX_VALUE arrives as its two's-complement Long. */
    fun encodeHead(buf: ByteBuf, major: Int, value: Long) {
        val mt = major shl 5
        val argument = value.toULong()
        when {
            argument < 24uL -> buf.write(mt or value.toInt())
            argument <= 0xFFuL -> { buf.write(mt or 24); buf.write(value.toInt()) }
            argument <= 0xFFFFuL -> { buf.write(mt or 25); buf.writeShort(value.toInt()) }
            argument <= 0xFFFFFFFFuL -> { buf.write(mt or 26); buf.writeInt(value.toInt()) }
            else -> { buf.write(mt or 27); buf.writeLong(value) }
        }
    }

        private data class EncodedMapEntry(val keyBytes: ByteArray, val value: Item)

        private fun encodeMapKey(key: String): ByteArray {
            val buf = ByteBuf()
            Item.Str(key).encode(buf)
            return buf.toByteArray()
        }

        private fun compareUnsigned(left: ByteArray, right: ByteArray): Int {
            val limit = minOf(left.size, right.size)
            for (i in 0 until limit) {
                val l = left[i].toInt() and 0xff
                val r = right[i].toInt() and 0xff
                if (l != r) return l - r
            }
            return left.size - right.size
        }

    fun decode(bytes: ByteArray): Item = Reader(bytes, 0).readItem()

    /** Opt-in bounded structural decoding for untrusted, JSON-shaped CBOR.
     * Depth counts edges from the root; this does not certify canonical key order.
     */
    fun decodeBounded(bytes: ByteArray, maxBytes: Int, maxDepth: Int = 64, maxItems: Int = 1_000_000): Item {
        require(maxBytes in 0..(16 * 1024 * 1024)) { "Invalid CBOR byte limit" }
        if (bytes.size > maxBytes) throw CborLimitException(CborLimitKind.BYTES)
        require(maxDepth in 0..64 && maxItems in 1..1_000_000) { "Invalid CBOR limits" }
        val snapshot = bytes.copyOf()
        val reader = Reader(snapshot, 0, maxDepth, maxItems).apply { strictStructure = true }
        val item = reader.readItem()
        require(reader.pos == snapshot.size) { "Trailing CBOR bytes" }
        return item
    }

   class Reader(val data: ByteArray, var pos: Int, val maxDepth: Int = Int.MAX_VALUE, val maxItems: Int = Int.MAX_VALUE) {
        internal var strictStructure: Boolean = false
        var depth = 0
        var items = 0

        fun readItem(): Item {
            if (strictStructure) {
                if (depth > maxDepth) throw CborLimitException(CborLimitKind.DEPTH)
                if (items >= maxItems) throw CborLimitException(CborLimitKind.ITEMS)
            } else require(depth <= maxDepth && items < maxItems) { "CBOR work limit" }
            items++
            depth++
            try { return readValue() } finally { depth-- }
        }

        fun readValue(): Item {
            val head = u8()
            val major = head shr 5
            val additional = head and 0x1F

            if (strictStructure) require(additional != 31 && major != 6 && !(major == 7 && additional == 23)) { "Unsupported CBOR structure" }
            if (additional == 31) return when (major) {
                2 -> readIndefBytes()
                3 -> readIndefText()
                4 -> readIndefArray()
                5 -> readIndefMap()
                else -> error("Indefinite length not supported for major type $major")
            }

            val argument = readArgument(additional)

            return when (major) {
                0, 1 -> if (argument < 0) error("u64 too large") else Item.Num(if (major == 0) argument else -1 - argument)
                2 -> Item.Bin(readBytes(length(argument)))
                3 -> Item.Str(readUtf8(length(argument)))
                4 -> readArray(length(argument))
                5 -> readMap(length(argument))
                6 -> Item.Tag(argument.toULong(), readItem())
                7 -> readSimple(additional, argument)
                else -> error("Invalid CBOR major type: $major at pos ${pos - 1}")
            }
        }

       /** Lengths and counts never exceed the bytes left: each byte, item and entry takes at least one. */
       fun length(argument: Long): Int =
           if (argument < 0 || argument > data.size - pos) error("unexpected end of input") else argument.toInt()

       fun readArgument(additional: Int): Long = when (additional) {
            in 0..23 -> additional.toLong()
            24 -> u8().toLong()
            25 -> u16().toLong()
            26 -> u32().toLong()
            27 -> u64()
            else -> error("Invalid CBOR additional info: $additional")
        }

       fun readArray(count: Int): Item.Arr {
            if (strictStructure && count > maxItems - items) throw CborLimitException(CborLimitKind.ITEMS)
            require(count <= maxItems - items) { "CBOR work limit" }
            val items = ArrayList<Item>(count)
            for (i in 0 until count) items.add(readItem())
            return Item.Arr(items.size j { items[it] })
        }

       fun readMap(count: Int): Item.Map {
            if (strictStructure && count > (maxItems - items) / 2) throw CborLimitException(CborLimitKind.ITEMS)
            require(count <= (maxItems - items) / 2) { "CBOR work limit" }
            val keys = ArrayList<String>(count)
            val vals = ArrayList<Item>(count)
            val seen = if (strictStructure) HashSet<String>() else null
            for (i in 0 until count) {
                val keyItem = readItem()
                if (strictStructure) require(keyItem is Item.Str) { "CBOR map key is not text" }
                val key = (keyItem as? Item.Str)?.value ?: keyItem.toString()
                if (seen != null) require(seen.add(key)) { "Duplicate CBOR map key" }
                keys.add(key)
                vals.add(readItem())
            }
            return Item.Map(keys.size j { keys[it] j vals[it] })
        }

       fun readIndefBytes(): Item.Bin {
            val chunks = ArrayList<ByteArray>()
            while (true) {
                if (u8() == 0xFF) break
                pos--
                val item = readItem()
                chunks.add((item as Item.Bin).value)
            }
            return Item.Bin(concat(chunks))
        }

       fun readIndefText(): Item.Str {
            val sb = StringBuilder()
            while (true) {
                if (u8() == 0xFF) break
                pos--
                val item = readItem()
                sb.append((item as Item.Str).value)
            }
            return Item.Str(sb.toString())
        }

       fun readIndefArray(): Item.Arr {
            val items = ArrayList<Item>()
            while (true) {
                if (u8() == 0xFF) break
                pos--
                items.add(readItem())
            }
            return Item.Arr(items.size j { items[it] })
        }

       fun readIndefMap(): Item.Map {
            val keys = ArrayList<String>()
            val vals = ArrayList<Item>()
            while (true) {
                if (u8() == 0xFF) break
                pos--
                val keyItem = readItem()
                keys.add((keyItem as? Item.Str)?.value ?: keyItem.toString())
                vals.add(readItem())
            }
            return Item.Map(keys.size j { keys[it] j vals[it] })
        }

       fun readSimple(additional: Int, argument: Long): Item = when (additional) {
            20 -> Item.Bool(false)
            21 -> Item.Bool(true)
            22 -> Item.Nil
            23 -> Item.Nil
            25 -> Item.Flt(readFloat16(argument.toInt()))
            26 -> Item.Flt(Float.fromBits(argument.toInt()).toDouble())
            27 -> Item.Flt(Double.fromBits(argument))
            else -> error("Unknown CBOR simple value: $additional")
        }

       fun u8(): Int = if (pos < data.size) data[pos++].toInt() and 0xFF else error("unexpected end of input")
       fun u16(): Int = (u8() shl 8) or u8()
       fun u32(): Long = ((u8().toLong() shl 24) or (u8().toLong() shl 16) or (u8().toLong() shl 8) or u8().toLong()) and 0xFFFFFFFFL
       fun u64(): Long = (u32() shl 32) or u32()

       fun readBytes(n: Int): ByteArray {
            val result = data.copyOfRange(pos, pos + n)
            pos += n
            return result
        }

       fun readUtf8(n: Int): String {
            val result = data.decodeToString(pos, pos + n, throwOnInvalidSequence = true)
            pos += n
            return result
        }

       fun readFloat16(bits: Int): Double {
            val sign = (bits shr 15) and 1
            val exp = (bits shr 10) and 0x1F
            val frac = bits and 0x3FF
            return when (exp) {
                0 -> (if (sign != 0) -1.0 else 1.0) * pow(2.0, -14) * (frac / 1024.0)
                31 -> {
                    if (frac == 0) {
                        if (sign != 0) Double.NEGATIVE_INFINITY else Double.POSITIVE_INFINITY
                    } else Double.NaN
                }
                else -> (if (sign != 0) -1.0 else 1.0) * pow(2.0, exp - 15) * (1.0 + frac / 1024.0)
            }
        }
    }
}
class ByteBuf {
   val buf = ArrayList<Byte>(256)
    fun write(b: Int) { buf.add(b.toByte()) }
    fun write(b: Byte) { buf.add(b) }
    fun write(bytes: ByteArray) { bytes.forEach { buf.add(it) } }
    fun writeShort(v: Int) { write((v shr 8) and 0xFF); write(v and 0xFF) }
    fun writeInt(v: Int) {
        write((v shr 24) and 0xFF); write((v shr 16) and 0xFF)
        write((v shr 8) and 0xFF); write(v and 0xFF)
    }
    fun writeLong(v: Long) { writeInt((v shr 32).toInt()); writeInt(v.toInt()) }
    fun writeDouble(v: Double) { writeLong(v.toRawBits()) }
    fun toByteArray(): ByteArray = buf.toByteArray()
}
fun concat(chunks: List<ByteArray>): ByteArray {
    val size = chunks.sumOf { it.size }
    val result = ByteArray(size)
    var off = 0
    for (c in chunks) { c.copyInto(result, off); off += c.size }
    return result
}
fun pow(base: Double, exp: Int): Double {
    if (exp < 0) return 1.0 / pow(base, -exp)
    var result = 1.0
    var b = base
    var e = exp
    while (e > 0) {
        if (e and 1 == 1) result *= b
        b *= b
        e = e shr 1
    }
    return result
}
