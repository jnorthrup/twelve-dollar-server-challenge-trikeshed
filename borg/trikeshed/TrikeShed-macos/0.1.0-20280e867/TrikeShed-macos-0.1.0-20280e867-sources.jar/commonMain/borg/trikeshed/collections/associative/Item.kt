@file:Suppress("UNCHECKED_CAST")

package borg.trikeshed.collections.associative

import borg.trikeshed.lib.Join
import borg.trikeshed.lib.Series
import borg.trikeshed.lib.j
import borg.trikeshed.lib.`▶`

/**
 * Item: the shared metamodel for JSON / YAML / CBOR.
 *
 * Every branch is either Join or Series -- no new abstract primitives.
 *   Map  = Series<Join<String, Item>>   (lazy key-value pairs)
 *   Arr  = Series<Item>                  (lazy sequence)
 *   Scalars: Str, Bin, Num, Flt, Bool, Nil
 *   Tag: CBOR tag (ignored by JSON/YAML)
 */
sealed interface Item {

    data class Map(val entries: Series<Join<String, Item>>) : Item {
        val size: Int get() = entries.a
        operator fun get(key: String): Item? {
            for (e in entries.`▶`) {
                if (e.a == key) return e.b
            }
            return null
        }
        /** Lazy Series — not List via (0 until).map */
        fun keys(): Series<String> = entries.a j { entries.b(it).a }
        fun values(): Series<Item> = entries.a j { entries.b(it).b }
        fun containsKey(key: String): Boolean = get(key) != null

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Map) return false
            if (size != other.size) return false
            for (i in 0 until size) {
                val key = entries.b(i).a
                val val1 = entries.b(i).b
                val val2 = other[key]
                if (val1 != val2) return false
            }
            return true
        }
        override fun hashCode(): Int {
            var result = 0
            for (i in 0 until size) {
                val e = entries.b(i)
                result += e.a.hashCode() xor e.b.hashCode()
            }
            return result
        }
    }

    data class Arr(val items: Series<Item>) : Item {
        val size: Int get() = items.a
        operator fun get(index: Int): Item = items.b(index)

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Arr) return false
            if (size != other.size) return false
            for (i in 0 until size) {
                if (items.b(i) != other.items.b(i)) return false
            }
            return true
        }
        override fun hashCode(): Int {
            var result = 1
            for (i in 0 until size) {
                result = 31 * result + items.b(i).hashCode()
            }
            return result
        }
    }

    data class Str(val value: String) : Item
    data class Bin(val value: ByteArray) : Item {
        override fun equals(other: Any?): Boolean = other is Bin && value.contentEquals(other.value)
        override fun hashCode(): Int = value.contentHashCode()
    }
    data class Num(val value: Long) : Item
    data class Flt(val value: Double) : Item
    data class Bool(val value: Boolean) : Item
    object Nil : Item
    data class Tag(val tag: ULong, val item: Item) : Item
}

fun itemMapOf(vararg pairs: Pair<String, Item>): Item.Map =
    Item.Map(pairs.size j { pairs[it].first j pairs[it].second })

fun itemMapOf(map: Map<String, Item>): Item.Map {
    val entries = map.entries.toList()
    return Item.Map(entries.size j { entries[it].key j entries[it].value })
}

fun itemArrayOf(vararg items: Item): Item.Arr = Item.Arr(items.size j { items[it] })
fun itemArrayOf(items: List<Item>): Item.Arr = Item.Arr(items.size j { items[it] })

fun Any?.toItem(): Item = when (this) {
    null -> Item.Nil
    is Item -> this
    is String -> Item.Str(this)
    is Long -> Item.Num(this)
    is Int -> Item.Num(this.toLong())
    is Short -> Item.Num(this.toLong())
    is Byte -> Item.Num(this.toLong())
    is Double -> Item.Flt(this)
    is Float -> Item.Flt(this.toDouble())
    is Boolean -> Item.Bool(this)
    is ByteArray -> Item.Bin(this)
    is Map<*, *> -> {
        val entries = entries.toList()
        Item.Map(entries.size j {
            val e = entries[it]
            (e.key?.toString() ?: "") j (e.value.toItem())
        })
    }
    is List<*> -> Item.Arr(size j { this[it].toItem() })
    is Array<*> -> Item.Arr(size j { this[it].toItem() })
    else -> Item.Str(toString())
}

fun Item.toAny(): Any? = when (this) {
    is Item.Nil -> null
    is Item.Str -> value
    is Item.Num -> value
    is Item.Flt -> value
    is Item.Bool -> value
    is Item.Bin -> value
    is Item.Map -> {
        val m = LinkedHashMap<String, Any?>(size)
        for (e in entries.`▶`) {
            m[e.a] = e.b.toAny()
        }
        m
    }
    is Item.Arr -> {
        val n = items.a
        List(n) { items.b(it).toAny() }  // Any boundary freeze; size known
    }
    is Item.Tag -> item.toAny()
}

val Item?.strValue: String? get() = (this as? Item.Str)?.value
val Item?.longValue: Long? get() = (this as? Item.Num)?.value
val Item?.boolValue: Boolean? get() = (this as? Item.Bool)?.value
