package borg.trikeshed.couch

import borg.trikeshed.parse.jsonOf

import borg.trikeshed.job.CasStore
import borg.trikeshed.cas.FileTreeManifest
import borg.trikeshed.job.ContentId
import borg.trikeshed.lib.get
import borg.trikeshed.lib.size
import borg.trikeshed.lib.view
import kotlinx.coroutines.channels.Channel

/**
 * CouchDatabase — one CouchDB 1.6/1.7-shaped database over the CAS-collapsed [CouchStore].
 *
 * Everything a peer can ask for is a blob or an index over blobs:
 *   - a document revision `gen-<hex>` names the CAS blob holding its canonical body
 *     (see [CouchStoreFactory.casBacked]);
 *   - an attachment document carries `contentId`; its bytes are the CAS blob of that id and
 *     surface on the wire as a 1.x `_attachments` stub (`digest: "sha256-<hex>"`);
 *   - `_changes` is the committed-frame log; `_revs_diff` asks which revisions (= blobs) a node
 *     lacks; `_bulk_docs new_edits=false` lands foreign revisions; `_local/…` holds replication
 *     checkpoints and is never replicated.
 *
 * commonMain, no sockets, no clock: the HTTP worker hands `(method, path, query, body)` in and
 * renders the JSON map back. Sequence numbers on the wire are 1-based (`frame.sequence + 1`) so
 * `since=0` means "everything" and `since=update_seq` means "nothing", as in 1.x.
 */
class Couch(
    val name: String,
    val store: CouchStore,
    val cas: CasStore,
    /**
     * Durable backing for `_local` documents (replication checkpoints). Null =
     * the in-memory map below; a [borg.trikeshed.couch.persistence.CouchCommitStore]
     * adapter makes checkpoints survive restart, closing the E02 "checkpoints"
     * boundary alongside heads/revisions/deletions.
     */
    private val localBacking: LocalBacking? = null,
) {
    /** Per-node `_local` persistence seam; the in-memory default lives in [locals]. */
    interface LocalBacking {
        fun get(id: String): Map<String, Any?>?
        fun put(id: String, body: Map<String, Any?>): Map<String, Any?>
        fun delete(id: String): Boolean
    }

    // ── _local documents (checkpoints): per-node, never in _changes ──
    private val locals = mutableMapOf<String, Map<String, Any?>>()
    private var localSeq = 0L

    /** Design-doc rewrites: read from `_design/forge` so the app's routing is itself a document. */
    val designId = "_design/forge"

    // ── info ──────────────────────────────────────────────────────

    /** 1-based update sequence; 0 for an empty database. */
    val updateSeq: Long
        get() = store.changes.lastCommittedSequence + 1

    fun info(): Map<String, Any?> {
        // Avoiding materializing full documents in memory just to count them reduces GC pressure.
        var docCount = 0
        val ids = store.ids()
        for (i in 0 until ids.a) {
            val id = ids.b(i)
            if (!store.head.isDeleted(id) && !id.startsWith("_design/")) {
                docCount++
            }
        }
        return mapOf(
            "db_name" to name,
            "doc_count" to docCount,
            "update_seq" to updateSeq,
            "instance_start_time" to "0",
        )
    }

    // ── documents ─────────────────────────────────────────────────

    /** The document as its 1.x JSON body, or null when absent/deleted. */
    fun docJson(id: String): Map<String, Any?>? {
        val doc = store.get(id) ?: return null
        if (isTombstone(doc)) return null
        return render(doc, store.head.getRev(id))
    }

    /** 201 {ok,id,rev} | 409 conflict. */
    fun put(id: String, body: Map<String, Any?>, rev: String?): Map<String, Any?> {
        val doc = toDocument(id, body)
        val ok = store.put(doc, rev ?: body["_rev"] as? String)
        return if (ok) mapOf("ok" to true, "id" to id, "rev" to store.head.getRev(id)) else conflict(id)
    }

    fun delete(id: String, rev: String?): Map<String, Any?> {
        if (store.get(id) == null || isTombstone(store.get(id)!!)) return mapOf("error" to "not_found", "reason" to "missing")
        if (rev == null) return conflict(id)
        return if (store.delete(id, rev)) mapOf("ok" to true, "id" to id, "rev" to store.head.getRev(id)) else conflict(id)
    }

    /** `GET /{db}/_all_docs` — ids in collation order, `{id,key,value:{rev}}` rows. */
    fun allDocs(
        startkey: String? = null,
        endkey: String? = null,
        limit: Int = Int.MAX_VALUE,
        skip: Int = 0,
        descending: Boolean = false,
        includeDocs: Boolean = false,
        keys: List<String>? = null,
        prefix: String? = null,
        delimiter: String? = null,
    ): Map<String, Any?> {
        val storeIds = store.ids()
        val rawIds = ArrayList<String>()
        for (i in 0 until storeIds.a) {
            val id = storeIds.b(i)
            if (!store.head.isDeleted(id)) {
                rawIds.add(id)
            }
        }

        var ids = rawIds.sorted()
        if (prefix != null) ids = ids.filter { it.startsWith(prefix) }
        // A delimiter folds every id past its next delimiter into that folder: a path-shaped id space read
        // as a hierarchy (`prefixes` are the folders directly under [prefix], `rows` the documents in it).
        val folders = if (delimiter.isNullOrEmpty()) null else LinkedHashSet<String>()
        if (folders != null) {
            val p = prefix.orEmpty()
            ids = ids.filter { id ->
                val at = id.indexOf(delimiter!!, p.length)
                if (at < 0) true else { folders.add(id.substring(0, at + delimiter.length)); false }
            }
        }
        if (keys != null) {
            val set = keys.toSet(); ids = keys.filter { it in set }
        } else {
            if (startkey != null) ids = ids.filter { if (descending) it <= startkey else it >= startkey }
            if (endkey != null) ids = ids.filter { if (descending) it >= endkey else it <= endkey }
            if (descending) ids = ids.reversed()
        }
        val total = rawIds.size
        val page = ids.drop(skip).take(limit)
        return linkedMapOf(
            "total_rows" to total,
            "offset" to skip.coerceAtMost(ids.size),
            "rows" to page.map { id ->
                val rev = store.head.getRev(id)
                val row = linkedMapOf<String, Any?>("id" to id, "key" to id, "value" to mapOf("rev" to rev))
                if (includeDocs) row["doc"] = docJson(id)
                row
            },
        ).also { r -> if (folders != null) { r["prefixes"] = folders.sorted(); r["documents"] = ids.size } }
    }

    // ── _changes ──────────────────────────────────────────────────

    /** One 1.x change row. */
    fun changeRow(frame: CouchCommittedFrame, includeDocs: Boolean): Map<String, Any?> {
        val row = linkedMapOf<String, Any?>(
            "seq" to frame.sequence + 1,
            "id" to frame.docId,
            "changes" to listOf(mapOf("rev" to frame.rev)),
        )
        if (frame.deleted) row["deleted"] = true
        if (includeDocs) row["doc"] = if (frame.deleted) mapOf("_id" to frame.docId, "_rev" to frame.rev, "_deleted" to true) else frame.doc?.let { render(it, frame.rev) }
        return row
    }

    /** Frames with external seq > [since], newest last. */
    suspend fun framesSince(since: Long, limit: Int = Int.MAX_VALUE): List<CouchCommittedFrame> {
        require(limit >= 0) { "Negative Couch changes limit" }
        val s = store.changes.afterSequence(since - 1)
        return List(minOf(s.size, limit)) { s[it] }
    }

    suspend fun changes(since: Long, limit: Int = Int.MAX_VALUE, includeDocs: Boolean = false): Map<String, Any?> {
        val frames = framesSince(since, limit)
        val last = if (frames.isEmpty()) since else frames.last().sequence + 1
        return mapOf("results" to frames.map { changeRow(it, includeDocs) }, "last_seq" to last)
    }

    /** A wake-up channel for feed=continuous|longpoll: one token per commit, conflated. */
    fun commitSignal(): Pair<Channel<Unit>, () -> Unit> {
        val ch = Channel<Unit>(Channel.CONFLATED)
        val cancel = store.changes.subscribe { ch.trySend(Unit) }
        return ch to cancel
    }

    // ── replication primitives ────────────────────────────────────

    /** `POST /{db}/_revs_diff` — which of the offered revisions this node lacks (head-only rev tree). */
    fun revsDiff(offered: Map<String, List<String>>): Map<String, Any?> {
        val out = linkedMapOf<String, Any?>()
        for ((id, revs) in offered) {
            val head = store.head.getRev(id)
            val missing = revs.filter { it != head }
            if (missing.isNotEmpty()) out[id] = mapOf("missing" to missing)
        }
        return out
    }

    /** `POST /{db}/_bulk_docs` — `new_edits=false` lands foreign revisions; otherwise ordinary puts. */
    fun bulkDocs(docs: List<Map<String, Any?>>, newEdits: Boolean): List<Map<String, Any?>> = docs.map { body ->
        val id = body["_id"] as? String ?: ContentId.of(jsonOf(body).encodeToByteArray()).hex
        val deleted = body["_deleted"] == true
        if (!newEdits) {
            val rev = body["_rev"] as? String ?: return@map mapOf("id" to id, "error" to "bad_request", "reason" to "new_edits=false requires _rev")
            val doc = if (deleted) null else toDocument(id, body)
            if (doc != null && field(doc, "contentType") == FileTreeManifest.CONTENT_TYPE) {
                val failure = runCatching { referencedCids(doc, requirePresent = true) }.exceptionOrNull()
                if (failure != null) return@map mapOf("id" to id, "error" to "invalid_attachment", "reason" to failure.message)
            }
            val ok = store.putReplicated(doc, id, rev, deleted)
            // The landed revision must also exist as a blob here, whoever minted the rev.
            if (ok && doc != null && (revToCid(rev)?.let { cas.get(it) } == null)) cas.put(CouchStoreFactory.canonicalBody(doc))
            if (ok) mapOf("ok" to true, "id" to id, "rev" to rev) else mapOf("id" to id, "error" to "conflict", "reason" to "newer revision present")
        } else if (deleted) {
            delete(id, body["_rev"] as? String)
        } else {
            put(id, body, body["_rev"] as? String)
        }
    }

    // ── _local ────────────────────────────────────────────────────

    fun localGet(id: String): Map<String, Any?>? = localBacking?.get(id) ?: locals[id]

    fun localPut(id: String, body: Map<String, Any?>): Map<String, Any?> {
        localBacking?.let { backing ->
            val stored = backing.put(id, body)
            return mapOf("ok" to true, "id" to "_local/$id", "rev" to (stored["_rev"] ?: ""))
        }
        val rev = "0-${++localSeq}"
        locals[id] = linkedMapOf<String, Any?>("_id" to "_local/$id", "_rev" to rev) + body.filterKeys { it != "_id" && it != "_rev" }
        return mapOf("ok" to true, "id" to "_local/$id", "rev" to rev)
    }

    fun localDelete(id: String): Map<String, Any?> {
        localBacking?.let { backing ->
            return if (backing.delete(id)) mapOf("ok" to true, "id" to "_local/$id")
            else mapOf("error" to "not_found", "reason" to "missing")
        }
        return if (locals.remove(id) != null) mapOf("ok" to true, "id" to "_local/$id") else mapOf("error" to "not_found", "reason" to "missing")
    }

    // ── blobs: attachments, bodies, raw blocks ────────────────────

    /**
     * Attachment bytes for a path document: `(content_type, bytes)`; null if absent, deleted or blob
     * missing. [rev] reads a specific revision through the CAS — `gen-sha256:<hex>` names the canonical
     * body blob ([bodyBlob]), whose `contentId` names the attachment blob; null or the head rev reads
     * the live document.
     */
    fun attachment(id: String, rev: String? = null): Pair<String, ByteArray>? {
        val doc = when {
            rev == null || rev == store.head.getRev(id) -> store.get(id)?.takeUnless { isTombstone(it) }
            else -> bodyBlob(rev)?.let { CouchStoreFactory.documentFromBody(it) }?.takeIf { it.id == id }
        } ?: return null
        val cid = field(doc, "contentId") as? String ?: return null
        val bytes = cas.get(ContentId(cid)) ?: return null
        return (field(doc, "contentType") as? String ?: "application/octet-stream") to bytes
    }

    /** The canonical body blob a revision names, if this node holds it. */
    fun bodyBlob(rev: String): ByteArray? = revToCid(rev)?.let { cas.get(it) }

    fun blockGet(cid: String): ByteArray? = runCatching { ContentId(cid) }.getOrNull()?.let { cas.get(it) }
    fun blockPut(bytes: ByteArray): ContentId = cas.put(bytes)

    /** Attachment root and its file-tree extents; [requirePresent] validates publication readiness. */
    fun referencedCids(body: Map<String, Any?>, requirePresent: Boolean = false): List<String> =
        referencedCids(body["contentId"] as? String, body["contentType"] as? String, body["length"], requirePresent)

    /** Same, from a decoded [Document]. */
    fun referencedCids(doc: Document, requirePresent: Boolean = false): List<String> =
        referencedCids(field(doc, "contentId") as? String, field(doc, "contentType") as? String, field(doc, "length"), requirePresent)

    private fun referencedCids(contentId: String?, contentType: String?, length: Any?, requirePresent: Boolean): List<String> {
        val fileTree = contentType == FileTreeManifest.CONTENT_TYPE
        val root = contentId?.takeIf { it.startsWith("sha256:") }
        if (root == null) {
            require(!fileTree) { "File-tree publication has no content identity" }
            return emptyList()
        }
        if (!fileTree && !requirePresent) return listOf(root)
        val cid = ContentId(root)
        // Pull first acquires the root, then resolves this graph again before publishing the revision.
        val bytes = cas.get(cid)
        if (bytes == null) {
            check(!requirePresent) { "Missing attachment root: $root" }
            return listOf(root)
        }
        check(ContentId.of(bytes) == cid) { "Attachment root does not match its content identity" }
        if (!fileTree) return listOf(root)
        require(length is Number && length.toLong() == bytes.size.toLong() && length.toDouble() == bytes.size.toDouble()) {
            "File-tree root length mismatch"
        }
        val manifest = FileTreeManifest.decode(bytes)
        if (requirePresent) for ((_, extent) in manifest.entries.view) {
            if (extent == null) continue
            val child = cas.get(extent.a)
            check(child != null && child.size.toLong() == extent.b && ContentId.of(child) == extent.a) {
                "Missing or corrupt file-tree extent: ${extent.a.value}"
            }
        }
        return listOf(root) + manifest.references().view.map { it.value }
    }

    // ── rewrites (CouchApp) ───────────────────────────────────────

    /** Seed `_design/forge` with the rewrite table that hoists `docs/` to `/`. Idempotent. */
    fun ensureDesignDoc(vhostRoot: String = "docs/") {
        if (store.get(designId)?.let { !isTombstone(it) } == true) return
        val rewrites = listOf(
            mapOf("from" to "/", "to" to "${vhostRoot}index.html"),
            mapOf("from" to "/*", "to" to "$vhostRoot*"),
        )
        store.put(Document(designId, listOf(Field("language", "confix"), Field("rewrites", rewrites), Field("vhost_root", vhostRoot))))
    }

    /**
     * Apply `_design/forge.rewrites` to a request path (`/`, `/styles.css`, `/build/live/...`) and
     * return the logical attachment id under [prefix]. Rules: exact `from`, or `from` ending in `*`.
     */
    fun rewrite(path: String, prefix: String): String? {
        val design = store.get(designId) ?: return null
        val rules = asList(field(design, "rewrites")) ?: return null
        val p = if (path.isEmpty()) "/" else path
        for (rule in rules) {
            val r = rule as? Map<*, *> ?: continue
            val from = r["from"] as? String ?: continue
            val to = r["to"] as? String ?: continue
            if (from == p) return prefix + to
            if (from.endsWith("*") && p.startsWith(from.dropLast(1))) {
                val rest = p.removePrefix(from.dropLast(1))
                val target = if (to.endsWith("*")) to.dropLast(1) + rest else to
                if (rest.isEmpty() || rest.endsWith("/")) continue
                return prefix + target
            }
        }
        return null
    }

    // ── helpers ───────────────────────────────────────────────────

    fun isTombstone(doc: Document): Boolean =
        doc.fields.any { (it.name == "_deleted" && it.value == true) }

    private fun field(doc: Document, name: String): Any? = doc.fields.firstOrNull { it.name == name }?.value

    private fun conflict(id: String) = mapOf("error" to "conflict", "reason" to "Document update conflict.", "id" to id)

    fun render(doc: Document, rev: String?): Map<String, Any?> {
        val m = linkedMapOf<String, Any?>("_id" to doc.id, "_rev" to rev)
        for (f in doc.fields) if (!f.name.startsWith("_")) m[f.name] = f.value
        val cid = field(doc, "contentId") as? String
        if (cid != null && cid.startsWith("sha256:")) {
            m["_attachments"] = mapOf(
                "content" to mapOf(
                    "content_type" to (field(doc, "contentType") ?: "application/octet-stream"),
                    // JSON PUTs land length as a Double (reify reifies numbers so), the
                    // attachment gateway as a String — the stub must be right either way.
                    "length" to (field(doc, "length").let { l -> (l as? Number)?.toLong() ?: (l as? String)?.toLongOrNull() } ?: 0L),
                    "digest" to "sha256-${cid.removePrefix("sha256:")}",
                    "cid" to cid,
                    "stub" to true,
                ),
            )
        }
        return m
    }

    fun toDocument(id: String, body: Map<String, Any?>): Document =
        Document(id, body.entries.filter { !it.key.startsWith("_") && it.value != null }.map { Field(it.key, it.value!!) })

    companion object {
        /** JSON arrays arrive as `Array<Any?>` from reify and as `List` from CBOR/Kotlin; accept both. */
        fun asList(v: Any?): List<Any?>? = when (v) {
            is List<*> -> v
            is Array<*> -> v.toList()
            else -> null
        }

        /** `gen-sha256:<hex>` (this store's minting) or `gen-<hex>`; null for foreign/short hashes. */
        fun revToCid(rev: String): ContentId? {
            val hex = rev.substringAfter("-", "").removePrefix("sha256:")
            return if (hex.length == 64) runCatching { ContentId("sha256:$hex") }.getOrNull() else null
        }
    }
}
