package borg.trikeshed.couch

import borg.trikeshed.parse.jsonOf
import borg.trikeshed.context.*

import borg.trikeshed.lib.*
import borg.trikeshed.collections.MutableSeries
import borg.trikeshed.collections.mutableSeriesOf
import borg.trikeshed.cursor.Cursor
import kotlinx.serialization.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import borg.trikeshed.lib.emptySeries
val couchStoreScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

/**
 * Couch K-V Document Store — minimal in-memory implementation backed by MutableSeries.
 * 
 * Document = Join<DocId, Series<Field>>
 * Field = Join<FieldName, FieldValue>
 * 
 * Uses COWArrayBackend for O(1) reads, copy-on-write mutations.
 * Pluggable persistence interface for future durability.
 */
@Serializable
data class Field(
    val name: String,
    @Contextual
    val value: Any // Serialized as JSON string for generality
)

@Serializable
data class Document(
    val id: String,
    val fields: List<Field>
)

/**
 * Query result — wraps a Cursor for composability with CursorOps.
 */
data class QueryResult(
    val cursor: Cursor,
    val totalCount: Long
)

interface CouchIngress {
    fun putIntent(doc: Document, expectedRev: String?): Boolean
    fun deleteIntent(docId: String, expectedRev: String?): Boolean

    /**
     * Replication target lane (`_bulk_docs` with `new_edits=false`): commit [doc] under a revision
     * minted elsewhere. CouchDB 1.x winner rule — higher generation wins, ties break on the hash.
     * Returns true when the rev is now (or already was) the head; false when a newer head exists.
     * Default: not supported.
     */
    fun putReplicated(doc: Document?, docId: String, rev: String, deleted: Boolean): Boolean = false
}

/**
 * CouchStore — minimal K-V document store with:
 * - put/get/delete by docId
 * - query(ConfixCursor) — Cursor algebra over documents
 * - subscribe to mutations via MutableSeries observer
 * - flush/drain for durability hooks
 */
class CouchStore(
    private val ingress: CouchIngress,
    val head: CouchHeadProjection,
    val changes: CouchChangesProjection
) {

    sealed interface MutationEvent {
        data class Inserted(val doc: Document) : MutationEvent
        data class Updated(val doc: Document) : MutationEvent
        data class Deleted(val docId: String) : MutationEvent
    }
    
    /**
     * Put a document — insert or replace.
     */
    fun put(document: Document, expectedRev: String? = null): Boolean {
        return ingress.putIntent(document, expectedRev)
    }
    
    /** Replication lane — see [CouchIngress.putReplicated]. */
    fun putReplicated(doc: Document?, docId: String, rev: String, deleted: Boolean): Boolean =
        ingress.putReplicated(doc, docId, rev, deleted)

    /**
     * Get a document by id.
     */
    fun get(docId: String): Document? {
        if (head.isDeleted(docId)) return null // 1.x: a deleted document reads as missing; the tombstone stays in head/_changes
        return head.get(docId)
    }
    
    /**
     * Delete a document by id.
     */
    fun delete(docId: String, expectedRev: String? = null): Boolean {
        return ingress.deleteIntent(docId, expectedRev)
    }

    /**
     * Check if document exists.
     */
    fun contains(docId: String): Boolean = head.contains(docId) && !head.isDeleted(docId)
    
    /**
     * Total document count.
     */
    val size: Int get() = head.size
    
    /**
     * All document ids.
     */
    fun ids(): Join<Int, (Int) -> String> = head.ids()

    /**
     * Get all documents as a list.
     */
    fun all(): List<Document> = head.all()
    
    /**
     * Query — projects all documents to a Cursor (rows = docs, cols = _id + fields).
     */
    fun query(): QueryResult {
        return head.query()
    }

    /** Query by field value equality. */
    fun query(fieldName: String, value: Any): QueryResult {
        return head.query(fieldName, value)
    }

    /**
     * Subscribe to mutation events.
     * Returns cancel function to unsubscribe.
     */
    fun subscribeMutations(observer: (MutationEvent) -> Unit): () -> Unit {
        var lastSeen = 0
        return changes.subscribe { twin: Twin<Series<CouchCommittedFrame>> ->
            // (before, after): the frames as they now stand are the after side.
            val series: Series<CouchCommittedFrame> = twin.b
            while (lastSeen < series.size) {
                val frame = series[lastSeen]
                lastSeen++
                if (frame.deleted) {
                    observer(MutationEvent.Deleted(frame.docId))
                } else if (frame.doc != null) {
                    if (frame.rev.startsWith("1-")) {
                         observer(MutationEvent.Inserted(frame.doc))
                    } else {
                         observer(MutationEvent.Updated(frame.doc))
                    }
                }
            }
        }
    }

    /** Subscribe to mutation events as Twin<Series<MutationEvent>> (for MutableSeries DSL). */
    fun subscribeMutationsSeries(observer: (Twin<Series<MutationEvent>>) -> Unit): () -> Unit {
        return changes.subscribe { twin: Twin<Series<CouchCommittedFrame>> ->
            val src: Series<CouchCommittedFrame> = twin.b
            // create an ephemeral projection to matching types
            val mapped: Series<MutationEvent> = src.size j { i: Int ->
                val f = src[i]
                if (f.deleted) MutationEvent.Deleted(f.docId)
                else if (f.rev.startsWith("1-")) MutationEvent.Inserted(f.doc!!)
                else MutationEvent.Updated(f.doc!!)
            }
            // For now, this is a leaky abstraction that wraps Series inside a Twin dummy view.
            observer(mapped j mapped)
        }
    }

    /**
     * Flush pending mutations to persistence.
     * Idempotent — safe to call repeatedly.
     */
    fun flush(): Unit {
        // persistence is now handled by the ingress / pipeline
    }
    
    /**
     * Drain — stop accepting new mutations, process remaining.
     * For in-memory store, this is a no-op; persistence implementations may override.
     */
    fun drain(): Unit {
    }
    
    /**
     * Close the store — drain and release resources.
     */
    fun close(): Unit {
        drain()
    }

    companion object {
        fun create(parentScope: kotlinx.coroutines.CoroutineScope, capacity: Int = 64,
                   synchronization: Synchronization = Synchronization.MONITOR): CouchStore {
            return CouchStoreFactory.inMemory(synchronization)
        }
    }
}

/**
 * Persistence interface — pluggable backend for durability.
 */
interface CouchPersistence {
    suspend fun persist(key: String, value: ByteArray)
    suspend fun delete(key: String)
    suspend fun flush()
    suspend fun drainStore(): Series<String>
    suspend fun close()
}

/**
 * No-op persistence for pure in-memory operation.
 */
object NoOpPersistence : CouchPersistence {
    override suspend fun persist(key: String, value: ByteArray) {}
    override suspend fun delete(key: String) {}
    override suspend fun flush() {}
    override suspend fun drainStore(): Series<String> = emptySeries()
    override suspend fun close() {}
}

/**
 * Factory functions for CouchStore creation.
 * File-backed store uses [FileOperations] (userspace.nio) — JVM is only the nio adapter.
 */
object CouchStoreFactory {
    class SyncTestIngress(val head: CouchHeadProjection, val changes: CouchChangesProjection, val persistence: CouchPersistence) : CouchIngress {
        var seq: Long = 0
        override fun putIntent(doc: Document, expectedRev: String?): Boolean {
            val existingRev = head.getRev(doc.id)
            val isDeleted = head.isDeleted(doc.id)
            if (expectedRev != null && existingRev != expectedRev) {
                return false // reject stale
            }

            val contentIdFn = { d: Document -> borg.trikeshed.job.ContentId.of(d.fields.joinToString { it.value.toString() }.encodeToByteArray()) }
            val cid = contentIdFn(doc)
            val gen = existingRev?.substringBefore("-")?.toIntOrNull() ?: 0
            val nextGen = gen + 1
            val newRev = "$nextGen-${cid.value}"
            val frame = CouchCommittedFrame(seq, doc.id, newRev, false, doc)
            seq++

            head.applyCommit(frame)
            changes.applyCommit(frame)
            couchStoreScope.launch {
                persistence.persist(doc.id, jsonOf(doc).encodeToByteArray())
            }
            return existingRev == null || isDeleted
        }

        override fun deleteIntent(docId: String, expectedRev: String?): Boolean {
            val existingRev = head.getRev(docId) ?: return false
            val isDeleted = head.isDeleted(docId)
            if (isDeleted) return false // already deleted

            if (expectedRev != null && existingRev != expectedRev) {
                return false // reject stale
            }

            val gen = existingRev.substringBefore("-").toIntOrNull() ?: 0
            val nextGen = gen + 1
            val newRev = "$nextGen-deleted"
            val frame = CouchCommittedFrame(seq, docId, newRev, true, null)
            seq++

            head.applyCommit(frame)
            changes.applyCommit(frame)
            couchStoreScope.launch {
                persistence.delete(docId)
            }
            return true
        }
    }

    /** NONE requires caller-serialized mutations; independently shared CAS/projection owners retain their contracts. */
    fun inMemory(synchronization: Synchronization = Synchronization.MONITOR): CouchStore {
        val head = CouchHeadProjection()
        val changes = CouchChangesProjection()
        val ingress = ProductionCouchIngress(head, { frame -> head.applyCommit(frame); changes.applyCommit(frame); }, { doc -> borg.trikeshed.job.ContentId.of(doc.fields.joinToString { it.value.toString() }.encodeToByteArray()) }, synchronization = synchronization)
        return CouchStore(ingress, head, changes)
    }

    /**
     * CAS-collapsed store: every committed body is written to [cas] as canonical CBOR and the
     * revision hash IS that blob's ContentId (`gen-<sha256 hex>`). Replication of a revision is
     * then a block fetch; nothing about a document exists outside the CAS. JSON is only the wire
     * commutation ([Couch] renders it in and out).
     */
    fun casBacked(cas: borg.trikeshed.job.CasStore, synchronization: Synchronization = Synchronization.MONITOR): CouchStore {
        val head = CouchHeadProjection()
        val changes = CouchChangesProjection(cas)
        val ingress = ProductionCouchIngress(
            head,
            { frame -> head.applyCommit(frame); changes.applyCommit(frame) },
            { doc -> cas.put(canonicalBody(doc)) },
            synchronization = synchronization,
        )
        return CouchStore(ingress, head, changes)
    }

    /**
     * Durable CAS-collapsed store: [casBacked] semantics plus recovery of heads,
     * revisions, deletions, and local checkpoint documents across restarts.
     * Every committed frame is filed into [commits] (an immutable CAS event
     * chain with an atomically published HEAD root and an exclusive writer
     * lease); at construction the recovered frames replay into the head and
     * changes projections and the ingress resumes after the last sequence.
     *
     * [commits] must be DURABLE-mode (its own constructor enforces a durable
     * CAS and durable filesystem) — a VOLATILE commit store here would be the
     * memory projection this factory exists to replace.
     */
    fun durableCasBacked(cas: borg.trikeshed.job.CasStore, commits: borg.trikeshed.couch.persistence.CouchCommitStore,
                         synchronization: Synchronization = commits.synchronization): CouchStore {
        require(commits.durability == borg.trikeshed.userspace.nio.file.spi.StorageDurability.DURABLE) {
            "durableCasBacked requires a DURABLE commit store"
        }
        return committed(cas, commits.recoveredFrames, synchronization) { frame ->
            commits.commit(frame)
            frame
        }
    }

    /** One ingress/projection contract for durable representations; publication precedes visibility. */
    internal fun committed(cas: borg.trikeshed.job.CasStore, recovered: Series<CouchCommittedFrame>,
                           synchronization: Synchronization = Synchronization.MONITOR,
                           publish: (CouchCommittedFrame) -> CouchCommittedFrame): CouchStore {
        val head = CouchHeadProjection()
        val changes = CouchChangesProjection(cas)
        var maxSequence = -1L
        for (frame in recovered.view) {
            head.applyCommit(frame)
            changes.applyCommit(frame)
            if (frame.sequence > maxSequence) maxSequence = frame.sequence
        }
        val ingress = ProductionCouchIngress(
            head,
            { frame ->
                val captured = publish(frame)
                head.applyCommit(captured)
                changes.applyCommit(captured)
            },
            { doc -> cas.put(canonicalBody(doc)) },
            initialSequence = maxSequence + 1,
            synchronization = synchronization,
        )
        return CouchStore(ingress, head, changes)
    }

    /** Canonical body bytes: CBOR, `_id` plus fields, sorted keys — stable across nodes. */
    fun canonicalBody(doc: Document): ByteArray {
        val m = linkedMapOf<String, Any?>("_id" to doc.id)
        for (f in doc.fields) m[f.name] = f.value
        return borg.trikeshed.job.CanonicalCbor.encodeMap(m)
    }

    /** Inverse of [canonicalBody]. */
    fun documentFromBody(bytes: ByteArray): Document? =
        documentFromBody(borg.trikeshed.job.CanonicalCbor.decodeMap(bytes))

    /** Project an already decoded body without decoding its bytes again. */
    fun documentFromBody(m: Map<String, Any?>): Document? {
        val id = m["_id"] as? String ?: return null
        return Document(id, m.entries.filter { it.key != "_id" && it.value != null }.map { Field(it.key, it.value!!) })
    }

    fun withPersistence(persistence: CouchPersistence, synchronization: Synchronization = Synchronization.MONITOR): CouchStore {
        val head = CouchHeadProjection()
        val changes = CouchChangesProjection()
        val ingress = ProductionCouchIngress(head, { frame -> 
            head.applyCommit(frame)
            changes.applyCommit(frame)
            couchStoreScope.launch {
                val docToPersist = frame.doc ?: Document(frame.docId, emptyList())
                persistence.persist(docToPersist.id, jsonOf(docToPersist).encodeToByteArray())
            }
        }, { doc -> borg.trikeshed.job.ContentId.of(doc.fields.joinToString { it.value.toString() }.encodeToByteArray()) }, synchronization = synchronization)
        return CouchStore(ingress, head, changes)
    }
}

/**
 * Extension for Cursor → Document reconstruction.
 * Known row size — Field list freeze per row (Document takes List).
 */
fun Cursor.toDocuments(): MutableSeries<Document> {
    val result = mutableSeriesOf<Document>()
    for (i in 0 until size) {
        val row = this[i]
        val fields = ArrayList<Field>(row.size)
        var docId = "reconstructed-$i"
        for (colIdx in 0 until row.size) {
            val cell = row.b(colIdx)
            val name = cell.b().name.toString()
            if (name == "_id") {
                docId = cell.a?.toString() ?: docId
            } else if (name == "_rev") {
                // Ignore _rev for Document fields
            } else {
                fields.add(Field(name, cell.a ?: ""))
            }
        }
        result.append(Document(docId, fields))
    }
    return result
}
