package borg.trikeshed.couch

import borg.trikeshed.parse.reify
import borg.trikeshed.parse.reifyStrict
import borg.trikeshed.parse.jsonOf

import borg.trikeshed.util.io.ContentTypes
import borg.trikeshed.relaxfactory.CouchHttpSurface
import borg.trikeshed.relaxfactory.RequestFactoryHandler
import borg.trikeshed.relaxfactory.RequestFactoryReactorElement
import borg.trikeshed.ipns.IpnsCid
import borg.trikeshed.ipns.IpnsDht
import borg.trikeshed.ipns.IpnsDhtFailure
import borg.trikeshed.ipns.IpnsEncoding
import borg.trikeshed.ipns.IpnsName
import borg.trikeshed.ipns.IpnsPublisher
import borg.trikeshed.ipns.IpnsPublishReport
import borg.trikeshed.ipns.IpnsRecord
import borg.trikeshed.lib.size
import borg.trikeshed.lib.view
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlin.time.Clock

/** A rendered reply: status, content type, raw bytes. Binary-safe so attachments and blocks can flow. */
data class WireReply(val status: Int, val contentType: String, val bytes: ByteArray) {
    companion object {
        fun json(status: Int, value: Any?): WireReply =
            WireReply(status, "application/json; charset=utf-8", jsonOf(value).encodeToByteArray())
        fun notFound(reason: String = "missing") = json(404, mapOf("error" to "not_found", "reason" to reason))
        fun badRequest(reason: String) = json(400, mapOf("error" to "bad_request", "reason" to reason))
        fun methodNotAllowed(m: String) = json(405, mapOf("error" to "method_not_allowed", "reason" to m))
    }
}

/**
 * CouchWireRouter — the CouchDB 1.6/1.7 HTTP shape over one [Couch], plus the two lanes
 * that collapse it onto the CAS: `_cas/{cid}` blocks and the IPFS `/api/v0/block/…` aliases.
 * commonMain: no sockets; the litebike HTTP worker hands (method, path, body) in and writes the
 * [WireReply] back. `feed=continuous|longpoll` is the JVM wire's job (it needs the connection).
 *
 *   GET    /                                      welcome {couchdb, version:"1.6.2"}
 *   GET    /{db}                                  info
 *   POST   /{db}                                  bare document put, or a RequestFactory envelope
 *   POST   /{db}/_relax                           Couch operations, or an original RequestFactory envelope
 *   POST   /{db}/_requestfactory                  original RequestFactory wire payload
 *   POST   /gwtRequest                           original RelaxFactory RequestFactory mount
 *   GET    /{db}/_all_docs[?startkey&endkey&limit&skip&descending&include_docs]   POST with {keys}
 *   GET    /{db}/_changes[?since&limit&include_docs]
 *   POST   /{db}/_revs_diff                       {id:[rev…]} → {id:{missing:[…]}}
 *   POST   /{db}/_bulk_docs                       {docs:[…], new_edits?}
 *   GET    /{db}/_projects[/{id}][?under=]        project headings ([ProjectPath], [Projects])
 *   GET|PUT|DELETE /{db}/_local/{id}              checkpoints (never replicated)
 *   GET    /{db}/_cas/{cid}   POST /{db}/_cas     raw blocks; POST body is the block → {cid}
 *   POST   /{db}/_cas/_bulk {cids:[…]}             many blocks in one exchange (see [CasBulkCodec])
 *   GET    /{db}/_design/{d}/_rewrite/{path}      CouchApp: attachment bytes via the ddoc's rewrites
 *   GET|PUT|DELETE /{db}/{id…}                    document JSON (`_attachments` stubs rendered)
 *   GET    /{db}/{id…}/content[?rev]              attachment bytes of a path document (rev = a CAS-held revision)
 *   GET    /api/v0/block/get?arg={cid}  POST /api/v0/block/put     IPFS-shaped aliases of _cas
 *   POST   /api/v0/name/publish?arg={path}   POST /api/v0/name/republish    configured native IPNS publisher
 *   GET|POST /api/v0/name/resolve?arg={name}   GET /api/v0/name/status     verified DHT result / local lifecycle
 *   GET    /{anything}                            vhost: rewrite of the root ddoc → attachment bytes
 *
 * [attachmentPrefix] is the logical prefix rewrites resolve under (`projects/trikeshed/`).
 */
class CouchWireRouter(
    val db: Couch,
    val attachmentPrefix: String,
    /** Bound so the envelope's `replicate` operation can drive m2m sync; null leaves it unimplemented. */
    val replicator: borg.trikeshed.couch.replicate.CouchReplicator? = null,
    /**
     * The ReportServer. Attached, every view this router runs — over `_view` or inside a
     * RequestFactory `query` — emits its map and reduce facts onto the CCEK report bus, which is
     * what spec C3 means by a report being pointcut-observable. Null keeps views silent.
     */
    val report: CouchReportReactorElement? = null,
    /** Host-owned Kotlin targets callable through the RequestFactory `rpc` operation. */
    val rpcTargets: Map<String, borg.trikeshed.relaxfactory.RequestFactoryRpcTarget> = emptyMap(),
    /** The actual RequestFactory server processor, admitted by its commonMain channel owner. */
    val requestFactoryHandler: RequestFactoryHandler? = null,
    /** P2 registry seam: null means eager route, preserving every existing caller. */
    val incrementalView: (ddoc: String, view: String) -> IncrementalViewElement? = { _, _ -> null },
) {
    /** One observed engine behind both askers, so a view reports the same way whoever ran it. */
    private val viewServer: ViewServer by lazy { ViewServer(report) }

    /**
     * The batched RequestFactory face of this same database. Not a second store and not a second
     * engine: `put` here mints the revision `PUT /{db}/{id}` would, `query` maps the projection
     * `_view` maps, and `changes`/`revs_diff`/`bulk_docs`/`block_*` are the envelope spelling of
     * the routes below. That is what lets one commonMain proxy address local and remote state.
     */
    val requestFactory: borg.trikeshed.relaxfactory.CouchRequestFactory by lazy {
        borg.trikeshed.relaxfactory.CouchRequestFactory.forDatabase(db, replicator, viewServer, rpcTargets)
    }

    suspend fun handle(method: String, rawPath: String, body: ByteArray, contentType: String? = null): WireReply? {
        val m = method.uppercase()
        val path = rawPath.substringBefore('?')
        val query = CouchHttpSurface.parseQuery(rawPath.substringAfter('?', ""))
        val segments = path.trim('/').split('/').filter { it.isNotEmpty() }.map { CouchHttpSurface.percentDecode(it) }

        if (segments == listOf("gwtRequest")) return requestFactoryWire(m, body, contentType)
        if (segments.isEmpty()) return if (m == "GET") vhost("/") ?: welcome() else WireReply.methodNotAllowed(m)
        if (segments[0] == "api" && segments.getOrNull(1) == "v0") return ipfs(m, segments.drop(2), query, body)
        if (segments[0] != db.name) return if (m == "GET") vhost(path) else null

        val rest = segments.drop(1)
        if (rest.isEmpty()) return when (m) {
            "GET" -> WireReply.json(200, db.info())
            "POST" -> {
                val doc = parseMap(body) ?: return WireReply.badRequest("invalid JSON body")
                // An envelope and a bare document share this route, as they do on CouchHttpSurface,
                // so a client written against either mounting works against both. The sniff is
                // narrower than "has the key": `operations` must be a list, which a document
                // carrying a scalar or object under that name is not.
                if (requestFactoryEnvelope(doc)) requestFactoryWire(m, body, contentType)
                else if (Couch.asList(doc["operations"]) != null) envelope(body)
                else {
                    val id = doc["_id"] as? String ?: borg.trikeshed.job.ContentId.of(body).hex
                    val r = db.put(id, doc, doc["_rev"] as? String)
                    WireReply.json(if (r["ok"] == true) 201 else 409, r)
                }
            }
            else -> WireReply.methodNotAllowed(m)
        }

        return when (rest[0]) {
            "_requestfactory" -> if (rest.size != 1) WireReply.notFound() else requestFactoryWire(m, body, contentType)
            "_relax" -> if (m != "POST") WireReply.methodNotAllowed(m) else {
                if (parseMap(body)?.let(::requestFactoryEnvelope) == true) requestFactoryWire(m, body, contentType)
                else envelope(body)
            }
            "_all_docs" -> allDocs(m, query, body)
            "_changes" -> if (m != "GET") WireReply.methodNotAllowed(m) else WireReply.json(
                200,
                db.changes(
                    since = query["since"]?.toLongOrNull() ?: 0L,
                    limit = query["limit"]?.toIntOrNull() ?: Int.MAX_VALUE,
                    includeDocs = query["include_docs"] == "true",
                ),
            )
            "_revs_diff" -> {
                if (m != "POST") return WireReply.methodNotAllowed(m)
                val offered = parseMap(body) ?: return WireReply.badRequest("invalid JSON body")
                WireReply.json(200, db.revsDiff(offered.mapValues { (_, v) -> Couch.asList(v)?.map { it.toString() } ?: emptyList() }))
            }
            "_bulk_docs" -> {
                if (m != "POST") return WireReply.methodNotAllowed(m)
                val req = parseMap(body) ?: return WireReply.badRequest("invalid JSON body")
                @Suppress("UNCHECKED_CAST")
                val docs = Couch.asList(req["docs"])?.mapNotNull { it as? Map<String, Any?> } ?: return WireReply.badRequest("docs required")
                WireReply.json(201, db.bulkDocs(docs, newEdits = req["new_edits"] != false))
            }
            // The project headings: what namespaces this database holds, declared or merely in use.
            "_projects" -> if (m != "GET") WireReply.methodNotAllowed(m) else {
                val p = Projects(db)
                val one = rest.getOrNull(1)
                if (one == null) WireReply.json(200, mapOf("rows" to p.summaries()))
                else WireReply.json(200, p.summary(one) + ("documents" to p.documents(one, query["under"] ?: "")))
            }
            "_local" -> local(m, rest.drop(1).joinToString("/"), body)
            "_cas" -> cas(m, rest.getOrNull(1), body)
            "_design" -> design(m, rest, query, body)
            else -> document(m, rest, query, body)
        }
    }

    // ── pieces ────────────────────────────────────────────────────

    /**
     * Always 200: a RequestFactory batch reports per-operation, so a failed operation is a receipt
     * with `ok:false`, never a status that would discard the receipts beside it.
     */
    private suspend fun envelope(body: ByteArray): WireReply =
        WireReply.json(200, requestFactory.process(body.decodeToString()))

    // The factory marker selects the protocol even when its remaining fields are malformed.
    // Validation belongs to RF; a rejected RF invocation must never become an implicit Couch put.
    private fun requestFactoryEnvelope(root: Map<String, Any?>): Boolean = root["F"] is String

    /** RF returns its own protocol error envelope; it is never re-encoded as Couch receipts. */
    private suspend fun requestFactoryWire(method: String, body: ByteArray, contentType: String?): WireReply {
        if (method != "POST") return WireReply.methodNotAllowed(method)
        if (contentType != null && contentType.substringBefore(';').trim().lowercase() != "application/json") {
            return WireReply.json(415, mapOf("error" to "unsupported_media_type", "reason" to "RequestFactory requires application/json"))
        }
        val payload = try { body.decodeToString(throwOnInvalidSequence = true) }
        catch (failure: Exception) { return WireReply.badRequest("invalid UTF-8 body") }
        val root = try { reifyStrict(payload) }
        catch (failure: Exception) { return WireReply.badRequest("invalid JSON body") }
        if (root !is Map<*, *>) return WireReply.badRequest("RequestFactory requires a JSON object")
        val handler = requestFactoryHandler ?: currentCoroutineContext()[RequestFactoryReactorElement]
            ?: return WireReply.json(501, mapOf("error" to "requestfactory_unavailable", "reason" to "RequestFactory server processor is not configured"))
        return try {
            WireReply(200, "application/json; charset=utf-8", handler.processRequest(payload).encodeToByteArray())
        } catch (failure: CancellationException) {
            throw failure
        } catch (failure: Exception) {
            WireReply.json(500, mapOf("error" to "requestfactory_failure", "reason" to (failure.message ?: "RequestFactory processor failed")))
        }
    }

    private fun welcome() = WireReply.json(200, mapOf("couchdb" to "Welcome", "version" to CouchHttpSurface.COUCH_VERSION, "vendor" to mapOf("name" to "TrikeShed", "version" to "oroboros")))

    private fun allDocs(m: String, query: Map<String, String>, body: ByteArray): WireReply {
        val keys = if (m == "POST") Couch.asList(parseMap(body)?.get("keys"))?.map { it.toString() } else null
        if (m != "GET" && m != "POST") return WireReply.methodNotAllowed(m)
        return WireReply.json(
            200,
            db.allDocs(
                startkey = query["startkey"]?.let(::unquote),
                endkey = query["endkey"]?.let(::unquote),
                limit = query["limit"]?.toIntOrNull() ?: Int.MAX_VALUE,
                skip = query["skip"]?.toIntOrNull() ?: 0,
                descending = query["descending"] == "true",
                includeDocs = query["include_docs"] == "true",
                keys = keys,
                prefix = query["prefix"]?.let(::unquote),
                delimiter = query["delimiter"]?.let(::unquote),
            ),
        )
    }

    private fun local(m: String, id: String, body: ByteArray): WireReply {
        if (id.isEmpty()) return WireReply.badRequest("_local id required")
        return when (m) {
            "GET" -> db.localGet(id)?.let { WireReply.json(200, it) } ?: WireReply.notFound()
            "PUT" -> WireReply.json(201, db.localPut(id, parseMap(body) ?: emptyMap()))
            "DELETE" -> db.localDelete(id).let { WireReply.json(if (it["ok"] == true) 200 else 404, it) }
            else -> WireReply.methodNotAllowed(m)
        }
    }

    private fun cas(m: String, cid: String?, body: ByteArray): WireReply = when {
        m == "POST" && cid == "_bulk" -> {
            val want = Couch.asList(parseMap(body)?.get("cids"))?.map { it.toString() } ?: return WireReply.badRequest("cids required")
            // Cap one reply by BYTES, not block count: jar-sized blobs make a 64-block reply tens of
            // megabytes. Omitted blocks are re-requested (bulk again or singles) by the reader.
            var budget = 8 * 1024 * 1024
            val blocks = mutableListOf<Pair<String, ByteArray>>()
            for (c in want) {
                val b = db.blockGet(c) ?: continue
                if (blocks.isNotEmpty() && b.size > budget) break
                blocks += c to b
                budget -= b.size
                if (budget <= 0) break
            }
            WireReply(200, CasBulkCodec.CONTENT_TYPE, CasBulkCodec.encode(blocks))
        }
        m == "GET" && cid != null -> db.blockGet(cid)?.let { WireReply(200, "application/octet-stream", it) } ?: WireReply.notFound("no such block")
        m == "POST" && cid == null -> db.blockPut(body).let { WireReply.json(201, mapOf("ok" to true, "cid" to it.value, "size" to body.size)) }
        else -> WireReply.methodNotAllowed(m)
    }

    /** Block aliases stay local; name routes use the configured native IPNS context elements. */
    private suspend fun ipfs(m: String, rest: List<String>, query: Map<String, String>, body: ByteArray): WireReply? {
        if (rest.getOrNull(0) == "name") return ipns(m, rest, query)
        if (rest.getOrNull(0) != "block") return null
        return when (rest.getOrNull(1)) {
            "get" -> query["arg"]?.let { db.blockGet(it) }?.let { WireReply(200, "application/octet-stream", it) } ?: WireReply.notFound("no such block")
            "put" -> if (m != "POST") WireReply.methodNotAllowed(m) else db.blockPut(body).let { WireReply.json(200, mapOf("Key" to it.value, "Size" to body.size)) }
            else -> null
        }
    }

    private suspend fun ipns(m: String, rest: List<String>, query: Map<String, String>): WireReply? {
        if (rest.size != 2) return null
        val operation = rest[1]
        val permitted = when (operation) {
            "publish", "republish" -> m == "POST"
            "resolve" -> m == "GET" || m == "POST"
            "status" -> m == "GET"
            else -> return null
        }
        if (!permitted) return WireReply.methodNotAllowed(m)
        val context = currentCoroutineContext()
        return when (operation) {
            "publish" -> {
                val value = query["arg"] ?: return WireReply.badRequest("arg is required")
                try { ipnsPath(value) }
                catch (failure: IllegalArgumentException) { return WireReply.badRequest(failure.message ?: "invalid IPNS value") }
                val publisher = context[IpnsPublisher] ?: return ipnsUnavailable("IPNS publisher is not configured")
                ipnsOperation { ipnsPublication(publisher.publish(value)) }
            }
            "republish" -> {
                val publisher = context[IpnsPublisher] ?: return ipnsUnavailable("IPNS publisher is not configured")
                if (publisher.latest == null) return WireReply.badRequest("no IPNS record has been published")
                ipnsOperation { ipnsPublication(publisher.republish()) }
            }
            "resolve" -> {
                val argument = query["arg"] ?: return WireReply.badRequest("arg is required")
                val name = try { IpnsName.parse(argument) }
                catch (failure: IllegalArgumentException) { return WireReply.badRequest(failure.message ?: "invalid IPNS name") }
                val dht = context[IpnsDht] ?: return ipnsUnavailable("IPNS DHT is not configured")
                ipnsOperation {
                    val result = dht.resolveReport(name, Clock.System.now())
                    val value = mutableMapOf<String, Any?>(
                        "Name" to name.toString(), "quorumReached" to result.quorumReached,
                        "validResponses" to result.valid.size, "quorumRequired" to result.quorumRequired,
                        "lookupExhausted" to result.lookup.exhausted, "queryLimitReached" to result.lookup.queryLimitReached,
                        "candidateLimitReached" to result.lookup.candidateLimitReached,
                        "rejectedPeerAdvertisements" to result.lookup.replies.view.sumOf { it.message?.rejectedPeers ?: 0 },
                        "peers" to result.valid.view.map { mapOf("id" to IpnsEncoding.base58(it.peer.id),
                            "sequence" to it.record.sequence.toString(), "validUntil" to it.record.validUntil.toString()) },
                        "failures" to result.failures.view.map(::ipnsFailure),
                        "repairAcknowledgements" to result.repairs.view.count { it.failure == null },
                        "repairFailures" to result.repairs.view.mapNotNull { it.failure?.let(::ipnsFailure) })
                    result.selected?.let {
                        value[if (result.quorumReached) "Path" else "candidatePath"] = it.value
                        value["sequence"] = it.sequence.toString()
                        value["validUntil"] = it.validUntil.toString()
                    }
                    when {
                        result.quorumReached -> WireReply.json(200, value)
                        result.absent -> WireReply.json(404, value + mapOf("error" to "not_found", "reason" to "IPNS record not found"))
                        else -> WireReply.json(503, value + mapOf("error" to "ipns_quorum_incomplete",
                            "reason" to "${result.valid.size} of ${result.quorumRequired} required valid responses"))
                    }
                }
            }
            else -> {
                val publisher = context[IpnsPublisher] ?: return ipnsUnavailable("IPNS publisher is not configured")
                // Snapshot each observation once; status does not enqueue or perform publication.
                val latest = publisher.latest
                val lastReport = publisher.lastReport
                val lastFailure = publisher.lastFailure
                WireReply.json(200, mapOf("Name" to publisher.name.toString(), "closed" to publisher.supervisor.isCompleted,
                    "latest" to latest?.let(::ipnsRecord), "lastReport" to lastReport?.let(::ipnsPublicationValue),
                    "lastFailure" to lastFailure?.let { mapOf("type" to it::class.simpleName, "reason" to it.message) }))
            }
        }
    }

    private fun ipnsPath(value: String) {
        require(value.length <= 4096 && value.encodeToByteArray().size <= 8192 && value.none { it < ' ' || it == '\u007f' }) { "invalid IPNS path length or control character" }
        val parts = value.split('/', limit = 4)
        require(parts.size >= 3 && parts[0].isEmpty() && parts[2].isNotEmpty()) { "arg must be /ipfs/CID or /ipns/name" }
        when (parts[1]) {
            "ipfs" -> IpnsCid.parse(parts[2])
            "ipns" -> IpnsName.parse(parts[2])
            else -> throw IllegalArgumentException("arg must be /ipfs/CID or /ipns/name")
        }
    }

    private fun ipnsRecord(record: IpnsRecord): Map<String, Any?> = mapOf("Name" to record.name.toString(),
        "Value" to record.value, "sequence" to record.sequence.toString(), "validUntil" to record.validUntil.toString())

    private fun ipnsFailure(failure: IpnsDhtFailure): Map<String, Any?> = mapOf(
        "peer" to IpnsEncoding.base58(failure.peer.id), "stage" to failure.stage.name, "reason" to failure.reason)

    private fun ipnsPublicationValue(report: IpnsPublishReport): Map<String, Any?> = ipnsRecord(report.record) + mapOf(
        "complete" to report.complete, "acknowledgements" to report.acknowledgements.size, "replicaTarget" to report.replicaTarget,
        "primaryAcknowledgements" to report.primaryAcknowledgements.size, "replacementAcknowledgements" to report.replacementAcknowledgements.size,
        "putAttempts" to report.putAttempts, "lookupExhausted" to report.lookup.exhausted,
        "queryLimitReached" to report.lookup.queryLimitReached, "candidateLimitReached" to report.lookup.candidateLimitReached,
        "rejectedPeerAdvertisements" to report.lookup.replies.view.sumOf { it.message?.rejectedPeers ?: 0 },
        "peers" to report.acknowledgements.view.map { IpnsEncoding.base58(it.id) },
        "replacementPeers" to report.replacementAcknowledgements.view.map { IpnsEncoding.base58(it.id) },
        "failures" to report.failures.view.map(::ipnsFailure))

    private fun ipnsPublication(report: IpnsPublishReport): WireReply {
        val value = ipnsPublicationValue(report)
        return if (report.complete) WireReply.json(200, value) else WireReply.json(503,
            value + mapOf("error" to "ipns_replication_incomplete", "reason" to "${report.acknowledgements.size} of ${report.replicaTarget} required acknowledgements"))
    }

    private fun ipnsUnavailable(reason: String) = WireReply.json(503, mapOf("error" to "ipns_unavailable", "reason" to reason))

    private suspend fun ipnsOperation(action: suspend () -> WireReply): WireReply = try {
        action()
    } catch (failure: CancellationException) {
        // A child operation timeout is reportable; cancellation of this HTTP request must propagate.
        currentCoroutineContext().ensureActive()
        ipnsUnavailable("${failure::class.simpleName}: ${failure.message}")
    } catch (failure: Exception) {
        ipnsUnavailable("${failure::class.simpleName}: ${failure.message}")
    }

    private fun design(m: String, rest: List<String>, query: Map<String, String>, body: ByteArray): WireReply {
        if (rest.size < 2) return WireReply.notFound()
        val id = "_design/${rest[1]}"
        val tail = rest.drop(2)
        if (tail.isEmpty()) return document(m, listOf("_design", rest[1]), query, body)
        if (tail[0] == "_rewrite") {
            if (m != "GET") return WireReply.methodNotAllowed(m)
            return vhost("/" + tail.drop(1).joinToString("/")) ?: WireReply.notFound("no rewrite matched")
        }
        if (tail[0] == "_view") {
            if (m != "GET") return WireReply.methodNotAllowed(m)
            if (tail.size != 2) return WireReply.notFound("missing_named_view")
            val viewName = tail[1]
            val incremental = incrementalView(id, viewName)
            if (incremental != null && designMarksIncremental(id, viewName)) {
                // Registry element owns map/reduce/checkpoint state. Delivery-time windowing
                // remains route work; no eager docs.all() scan occurs here.
                val result = incremental.answer()
                val skip = query["skip"]?.toIntOrNull()?.coerceAtLeast(0) ?: 0
                val limit = query["limit"]?.toIntOrNull()?.coerceAtLeast(0) ?: Int.MAX_VALUE
                val rows = ArrayList<Map<String, Any?>>()
                var seen = 0
                for (row in result.rows) {
                    if (seen++ < skip) continue
                    if (rows.size >= limit) break
                    rows.add(mapOf("id" to row.docId, "key" to row.key, "value" to row.value))
                }
                return WireReply.json(200, mapOf(
                    "total_rows" to result.size, "offset" to skip.coerceAtMost(result.size), "rows" to rows,
                    "update_seq" to db.updateSeq, "incremental" to true,
                ))
            }
            val r = viewRoute.handle(id, viewName, query)
            return WireReply.json(r.status, r.json)
        }
        return WireReply.notFound("unsupported design handler ${tail[0]} on $id")
    }

    /** A design doc opts in explicitly: views.<name>.incremental == true. */
    private fun designMarksIncremental(ddoc: String, view: String): Boolean {
        val doc = db.docJson(ddoc) ?: return false
        val views = doc["views"] as? Map<*, *> ?: return false
        val spec = views[view] as? Map<*, *> ?: return false
        return spec["incremental"] == true || spec["incremental"]?.toString() == "true"
    }

    /** The `_view` route core mounted over this database — the same engine `CouchHttpSurface` serves. */
    private val viewRoute: borg.trikeshed.relaxfactory.ViewRoute by lazy {
        borg.trikeshed.relaxfactory.ViewRoute(borg.trikeshed.relaxfactory.ViewDocs.of(db), viewServer)
    }

    private fun document(m: String, rest: List<String>, query: Map<String, String>, body: ByteArray): WireReply {
        val id = rest.joinToString("/")
        return when (m) {
            "GET" -> db.docJson(id)?.let { WireReply.json(200, it) }
                ?: attachmentReply(id.removeSuffix("/content").takeIf { rest.size >= 2 && rest.last() == "content" }, query["rev"])
                ?: WireReply.notFound()
            "PUT" -> {
                val doc = parseMap(body) ?: return WireReply.badRequest("Document must be a JSON object")
                val r = db.put(id, doc, query["rev"] ?: doc["_rev"] as? String)
                WireReply.json(if (r["ok"] == true) 201 else 409, r)
            }
            "DELETE" -> db.delete(id, query["rev"]).let { WireReply.json(if (it["ok"] == true) 200 else if (it["error"] == "not_found") 404 else 409, it) }
            else -> WireReply.methodNotAllowed(m)
        }
    }

    private fun attachmentReply(id: String?, rev: String? = null): WireReply? {
        val (ct, bytes) = db.attachment(id ?: return null, rev) ?: return null
        return WireReply(200, ct.ifEmpty { ContentTypes.forPath(id) }, bytes)
    }

    /** Root vhost: the ddoc's rewrites map a request path to an attachment under [attachmentPrefix]. */
    fun vhost(path: String): WireReply? {
        val target = db.rewrite(path, attachmentPrefix) ?: return null
        return attachmentReply(target)
    }

    @Suppress("UNCHECKED_CAST")
    private fun parseMap(body: ByteArray): Map<String, Any?>? =
        runCatching { reify(body) as? Map<String, Any?> }.getOrNull()

    private fun unquote(s: String): String = if (s.length >= 2 && s.startsWith("\"") && s.endsWith("\"")) s.substring(1, s.length - 1) else s
}

/**
 * Wire framing for `_cas/_bulk`: a sequence of `<cid>\n<length>\n<bytes>` frames. Blocks the node
 * does not hold are simply absent; the reader verifies every block against its cid anyway.
 */
object CasBulkCodec {
    const val CONTENT_TYPE = "application/x-trikeshed-cas-bulk"

    fun encode(blocks: List<Pair<String, ByteArray>>): ByteArray {
        var total = 0
        val heads = blocks.map { (cid, bytes) -> "$cid\n${bytes.size}\n".encodeToByteArray().also { total += it.size + bytes.size } }
        val out = ByteArray(total)
        var pos = 0
        for (i in blocks.indices) {
            heads[i].copyInto(out, pos); pos += heads[i].size
            blocks[i].second.copyInto(out, pos); pos += blocks[i].second.size
        }
        return out
    }

    fun decode(bytes: ByteArray): List<Pair<String, ByteArray>> {
        val out = mutableListOf<Pair<String, ByteArray>>()
        var pos = 0
        fun line(): String? {
            val start = pos
            while (pos < bytes.size && bytes[pos] != '\n'.code.toByte()) pos++
            if (pos >= bytes.size) return null
            return bytes.decodeToString(start, pos).also { pos++ }
        }
        while (pos < bytes.size) {
            val cid = line() ?: break
            val len = line()?.toIntOrNull() ?: break
            if (pos + len > bytes.size) break
            out += cid to bytes.copyOfRange(pos, pos + len)
            pos += len
        }
        return out
    }
}
