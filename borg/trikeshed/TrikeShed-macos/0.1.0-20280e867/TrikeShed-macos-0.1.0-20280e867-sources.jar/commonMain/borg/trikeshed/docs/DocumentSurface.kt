package borg.trikeshed.docs

import borg.trikeshed.lib.*
import borg.trikeshed.job.ContentId
import borg.trikeshed.wiki.WikiSurface

/**
 * THE DOCUMENT SURFACE: the muggle half of Forge, and the first page whose logic lives in
 * commonMain and reaches the browser through the Kotlin/JS bundle (the owner's 2026-09-06
 * ruling: emulate GWT, hand-written JS only for dire dependency access).
 *
 * It is patterned after the workspace-and-page products a stranger already knows: a sidebar
 * that nests a workspace's pages under it, a breadcrumb, a page whose title is its own
 * heading, and a table view of the same rows for when the workspace IS the data. What is
 * underneath is not theirs: a page is a document in a project database with a cid, a rev and
 * a sequence, and a fenced `lcnc-run` block in it is a build target (see [RunBlock]).
 *
 * Every function here is pure: JSON in (as the parser's maps and lists), HTML strings out.
 * The jsMain page only fetches, mounts and forwards clicks.
 */
data class ProjectRow(val name: String, val kind: String, val docs: Int, val path: String)

data class DocRow(val id: String, val cid: String, val rev: String, val seq: Long, val length: Long, val contentType: String,
    val contentStatus: String? = null)

data class DocRevision(val project: String, val id: String, val cid: String, val rev: String, val seq: Long)

data class SourceRetentionState(val revision: DocRevision, val pending: Boolean, val message: String? = null)

data class DocView(
    val project: String,
    val id: String,
    val cid: String,
    val rev: String,
    val seq: Long,
    val contentType: String,
    val text: String,
    /** The miner's `.extract.md` twin when one sits beside the document. */
    val extract: String? = null,
    val hasRevisionDetails: Boolean = false,
    val sourceRevision: DocRevision? = null,
    val displayTextRevision: DocRevision? = null,
    val extractionRevision: DocRevision? = null,
    val canRetainSource: Boolean = false,
)

/** Page reads one document; Table reads the whole project as rows. Both are the same data. */
enum class SurfaceView { PAGE, TABLE }

// ── curation: the reader's own text, sent through the same curator the projects use ──────

data class CurationDestination(val model: String, val provider: String, val url: String)

data class CurationRecordRow(val receiptCid: String, val name: String)

data class CurationProposal(
    val subject: String?, val predicate: String?, val obj: String?,
    val quote: String?, val reasons: List<String>, val submitted: Boolean, val duplicate: Boolean,
    val ordinal: Int = -1, val quotationBegin: Int? = null, val quotationEnd: Int? = null,
)

data class CurationAxiom(
    val antecedent: String?, val predicate: String?, val consequent: String?,
    val quote: String?, val label: String?,
)

/** Read-side projections of retained receipts; missing fields never imply a successful call. */
data class CurationStageReceipt(val stage: String?, val status: String?, val tool: String?, val receiptCid: String?)

data class CurationModelReceipt(
    val receiptId: String?, val modelId: String?, val providerId: String?,
    val httpStatus: Int?, val latencyMs: Long?, val cachedHit: Boolean?, val errorClass: String?,
)

data class CurationResult(
    val receiptCid: String, val name: String, val text: String,
    val proposals: List<CurationProposal>, val reasons: List<String>, val axioms: List<CurationAxiom>,
    val stages: Series<CurationStageReceipt> = emptySeriesOf(),
    val modelReceipt: CurationModelReceipt? = null,
    val project: String? = null,
    val documentId: String? = null,
    val sourceRevision: DocRevision? = null,
    val extractionRevision: DocRevision? = null,
    val originalCid: String? = null,
    val extractedTextCid: String? = null,
)

data class DocumentPassage(val receiptCid: String, val ordinal: Int, val source: DocRevision,
    val textRevision: DocRevision, val begin: Int, val end: Int, val quote: String,
    val contextBegin: Int, val contextEnd: Int, val context: String)

/** The table's sortable columns, each with the header a reader sees. */
enum class DocColumn(val key: String, val label: String) {
    NAME("name", "Name"), TYPE("type", "Type"), SIZE("size", "Size"), SEQ("seq", "Sequence");

    companion object {
        fun of(key: String?): DocColumn = entries.firstOrNull { it.key == key } ?: NAME
    }
}

object DocumentSurface {
    const val ROOT_ID = "document-surface"
    const val SIDE_ID = "ds-side"
    const val CRUMB_ID = "ds-crumb"
    const val CONTENT_ID = "ds-content"
    const val DIGEST_HREF = "/harness?load=preset-corpus"
    const val CURATION_HASH = "curation"
    private val cidPattern = Regex("^sha256:[0-9a-f]{64}$")

    private fun revision(value: Any?): DocRevision? {
        val r = value as? Map<*, *> ?: return null
        val seq = (r["seq"] as? Number)?.toDouble() ?: return null
        if (!seq.isFinite() || seq < -1 || seq > 9_007_199_254_740_991.0 || seq % 1.0 != 0.0) return null
        return DocRevision(r["project"] as? String ?: return null, r["id"] as? String ?: return null,
            r["cid"] as? String ?: return null, r["rev"] as? String ?: return null,
            seq.toLong())
    }

    private fun offset(value: Any?): Int? {
        val n = (value as? Number)?.toDouble() ?: return null
        return if (n.isFinite() && n >= 0 && n <= Int.MAX_VALUE.toDouble() && n % 1.0 == 0.0) n.toInt() else null
    }

    private fun exact(text: String, begin: Int, end: Int, quote: String): Boolean {
        fun split(at: Int) = at > 0 && at < text.length && text[at - 1] in '\uD800'..'\uDBFF' && text[at] in '\uDC00'..'\uDFFF'
        return begin >= 0 && end > begin && end <= text.length && !split(begin) && !split(end) && text.substring(begin, end) == quote
    }

    /** Split before URL decoding so an encoded slash stays inside the project or document ID. */
    fun fragmentParts(fragment: String): Pair<String, String> {
        val raw = fragment.removePrefix("#")
        return Pair(raw.substringBefore('/'), raw.substringAfter('/', ""))
    }

    // ── parsing the routes' JSON ────────────────────────────────────────────

    fun projects(json: Any?): List<ProjectRow> {
        val scopes = (json as? Map<*, *>)?.get("scopes") as? List<*> ?: return emptyList()
        return scopes.mapNotNull { row ->
            val m = row as? Map<*, *> ?: return@mapNotNull null
            ProjectRow(
                name = m["name"]?.toString() ?: return@mapNotNull null,
                kind = m["kind"]?.toString().orEmpty(),
                docs = (m["docs"] as? Number)?.toInt() ?: 0,
                path = m["path"]?.toString().orEmpty(),
            )
        }
    }

    fun docs(json: Any?): List<DocRow> {
        val docs = (json as? Map<*, *>)?.get("docs") as? List<*> ?: return emptyList()
        return docs.mapNotNull { row ->
            val m = row as? Map<*, *> ?: return@mapNotNull null
            DocRow(
                id = m["id"]?.toString() ?: return@mapNotNull null,
                cid = m["cid"]?.toString().orEmpty(),
                rev = m["rev"]?.toString().orEmpty(),
                seq = (m["seq"] as? Number)?.toLong() ?: -1L,
                length = (m["length"] as? Number)?.toLong() ?: 0L,
                contentType = m["contentType"]?.toString().orEmpty(),
                contentStatus = m["contentStatus"] as? String,
            )
        }
    }

    fun document(json: Any?): DocView? {
        val m = json as? Map<*, *> ?: return null
        if (m["error"] != null) return null
        val id = m["id"]?.toString() ?: return null
        return DocView(
            project = m["project"]?.toString().orEmpty(),
            id = id,
            cid = m["cid"]?.toString().orEmpty(),
            rev = m["rev"]?.toString().orEmpty(),
            seq = (m["seq"] as? Number)?.toLong() ?: -1L,
            contentType = m["contentType"]?.toString().orEmpty(),
            text = m["text"]?.toString().orEmpty(),
            extract = m["extract"]?.toString(),
            hasRevisionDetails = m.containsKey("sourceRevision") || m.containsKey("displayTextRevision"),
            sourceRevision = revision(m["sourceRevision"]),
            displayTextRevision = revision(m["displayTextRevision"]),
            extractionRevision = revision(m["extractionRevision"]),
            canRetainSource = m["canRetainSource"] == true,
        )
    }

    fun documentError(json: Any?): String? {
        val error = (json as? Map<*, *>)?.get("error") as? String ?: return null
        return if (error == "source_unavailable_or_changed")
            "Document unavailable or changed; its listed metadata has not been verified."
        else "Document unavailable: $error"
    }

    fun documentErrorHtml(error: String): String = "<p class=\"ds-empty\">" + esc(error) + "</p>"

    // ── curation: /api/documents and /api/documents/curate ─────────────────

    fun curationAvailable(json: Any?): Boolean = (json as? Map<*, *>)?.get("available") as? Boolean ?: false

    fun curationDestination(json: Any?): CurationDestination? {
        val m = (json as? Map<*, *>)?.get("destination") as? Map<*, *> ?: return null
        val model = m["model"]?.toString() ?: return null
        return CurationDestination(model, m["provider"]?.toString().orEmpty(), m["url"]?.toString().orEmpty())
    }

    fun curationList(json: Any?): List<CurationRecordRow> {
        val records = (json as? Map<*, *>)?.get("records") as? List<*> ?: return emptyList()
        return records.mapNotNull { row ->
            val m = row as? Map<*, *> ?: return@mapNotNull null
            CurationRecordRow(
                receiptCid = m["receiptCid"]?.toString() ?: return@mapNotNull null,
                name = m["name"]?.toString().orEmpty(),
            )
        }
    }

    /** [json] is a full `/api/documents?cid=` (or curate) response: `record` plus top-level `nlpAxioms`. */
    fun curationResult(json: Any?): CurationResult? {
        val m = json as? Map<*, *> ?: return null
        val receiptCid = m["receiptCid"]?.toString() ?: return null
        val record = m["record"] as? Map<*, *> ?: return null
        val source = record["source"] as? Map<*, *> ?: emptyMap<Any?, Any?>()
        val projectRevision = source["project"] as? Map<*, *>
        val submittedCids = (record["submitted"] as? List<*>)?.map { it.toString() }?.toSet().orEmpty()
        val duplicateCids = (record["duplicates"] as? List<*>)?.map { it.toString() }?.toSet().orEmpty()
        val proposals = (record["proposals"] as? List<*> ?: emptyList<Any?>()).mapIndexedNotNull { ordinal, row ->
            val p = row as? Map<*, *> ?: return@mapIndexedNotNull null
            CurationProposal(
                subject = p["subject"] as? String, predicate = p["predicate"] as? String, obj = p["object"] as? String,
                quote = p["quote"] as? String,
                reasons = (p["reasons"] as? List<*>)?.map { it.toString() }.orEmpty(),
                submitted = p["receiptCid"]?.toString()?.let { it in submittedCids } ?: false,
                duplicate = p["receiptCid"]?.toString()?.let { it in duplicateCids } ?: false,
                ordinal = ordinal, quotationBegin = offset(p["quotationBegin"]), quotationEnd = offset(p["quotationEnd"]),
            )
        }
        val axioms = (m["nlpAxioms"] as? List<*> ?: emptyList<Any?>()).mapNotNull { row ->
            val a = row as? Map<*, *> ?: return@mapNotNull null
            CurationAxiom(
                antecedent = a["antecedent"]?.toString(), predicate = a["predicate"]?.toString(),
                consequent = a["consequent"]?.toString(), quote = a["quote"]?.toString(), label = a["label"]?.toString(),
            )
        }
        return CurationResult(
            receiptCid = receiptCid, name = source["name"]?.toString().orEmpty(), text = (source["text"] as? String).orEmpty(),
            proposals = proposals, reasons = (record["reasons"] as? List<*>)?.map { it.toString() }.orEmpty(),
            axioms = axioms,
            stages = ((record["toolReceipts"] as? List<*>) ?: emptyList<Any?>()).toSeries() α { row ->
                val r = row as? Map<*, *>
                CurationStageReceipt(r?.get("stage") as? String, r?.get("status") as? String,
                    r?.get("tool") as? String, r?.get("receiptCid") as? String)
            },
            modelReceipt = (record["receipt"] as? Map<*, *>)?.let { r -> CurationModelReceipt(
                r["receiptId"] as? String, r["modelId"] as? String, r["providerId"] as? String,
                (r["httpStatus"] as? Number)?.toInt(), (r["latencyMs"] as? Number)?.toLong(),
                r["cachedHit"] as? Boolean, r["errorClass"] as? String,
            ) },
            project = projectRevision?.get("project") as? String,
            documentId = projectRevision?.get("id") as? String,
            sourceRevision = revision(source["project"]), extractionRevision = revision(source["extraction"]),
            originalCid = source["originalCid"] as? String, extractedTextCid = source["extractedTextCid"] as? String,
        )
    }

    /** Only an exact retained quotation tied to known source and text revisions can be offered. */
    private fun textValid(result: CurationResult): Boolean {
        if (result.sourceRevision == null) return false
        val cid = result.extractedTextCid ?: return false
        var i = 0
        while (i < result.text.length) {
            val ch = result.text[i]
            if (ch in '\uD800'..'\uDBFF') {
                if (i + 1 >= result.text.length || result.text[i + 1] !in '\uDC00'..'\uDFFF') return false
                i++
            } else if (ch in '\uDC00'..'\uDFFF') return false
            i++
        }
        return cidPattern.matches(cid) && ContentId.of(result.text.encodeToByteArray()).value == cid
    }

    fun passage(result: CurationResult, ordinal: Int): DocumentPassage? =
        result.proposals.firstOrNull { it.ordinal == ordinal }?.let { passage(result, it, textValid(result)) }

    private fun passage(result: CurationResult, proposal: CurationProposal, validText: Boolean): DocumentPassage? {
        if (!cidPattern.matches(result.receiptCid)) return null
        val source = result.sourceRevision ?: return null
        val textRevision = result.extractionRevision ?: source
        fun valid(r: DocRevision) = r.project.isNotBlank() && r.id.isNotBlank() && r.rev.isNotBlank() && r.seq >= 0 && cidPattern.matches(r.cid)
        if (!valid(source) || !valid(textRevision) || source.project != textRevision.project ||
            source.project == CURATION_HASH || source.cid != result.originalCid || textRevision.cid != result.extractedTextCid || !validText) return null
        val begin = proposal.quotationBegin ?: return null
        val end = proposal.quotationEnd ?: return null
        val quote = proposal.quote ?: return null
        if (!exact(result.text, begin, end, quote)) return null
        var before = maxOf(0, begin - 120)
        var after = minOf(result.text.length.toLong(), end.toLong() + 120).toInt()
        if (before > 0 && result.text[before] in '\uDC00'..'\uDFFF' && result.text[before - 1] in '\uD800'..'\uDBFF') before--
        if (after < result.text.length && result.text[after] in '\uDC00'..'\uDFFF' && result.text[after - 1] in '\uD800'..'\uDBFF') after++
        return DocumentPassage(result.receiptCid, proposal.ordinal, source, textRevision, begin, end, quote,
            before, after, result.text.substring(before, after))
    }

    /** Match both recorded revisions and the returned preview; no text search or head substitution. */
    fun passageHtml(view: DocView?, selected: DocumentPassage?): String {
        val context = selected?.let { SourceSelection.from(it).html() }.orEmpty()
        fun unavailable() = context + "<section data-passage-result=\"1\"><p>Passage unavailable: the saved quotation or current document revision does not match.</p></section>"
        if (view == null || selected == null || view.project != selected.source.project || view.id != selected.source.id ||
            view.sourceRevision != selected.source) return unavailable()
        val text = when (selected.textRevision) {
            view.displayTextRevision -> view.text
            view.extractionRevision -> view.extract
            else -> null
        } ?: return unavailable()
        if (!exact(text, selected.begin, selected.end, selected.quote) || selected.contextBegin < 0 ||
            selected.contextBegin > selected.begin || selected.contextEnd < selected.end || selected.contextEnd > text.length ||
            text.substring(selected.contextBegin, selected.contextEnd) != selected.context) return unavailable()
        return context + "<section data-passage-result=\"1\"><h2>Selected passage</h2><p>Matched to the saved text and document revisions. Original-page accuracy and review are not established.</p><pre>" +
            esc(text.substring(selected.contextBegin, selected.begin)) + "<mark>" + esc(selected.quote) + "</mark>" +
            esc(text.substring(selected.end, selected.contextEnd)) + "</pre></section>"
    }

    /** Both the list read (`error` at the top) and the curate write (`error` on a 503) land the same way. */
    fun curationError(json: Any?): String? = (json as? Map<*, *>)?.get("error")?.toString()

    // ── curation: the form, the saved list, and a result ───────────────────

    fun curationHtml(
        available: Boolean,
        destination: CurationDestination?,
        records: List<CurationRecordRow>,
        pendingName: String,
        pendingText: String,
        formError: String?,
        listError: String?,
        busy: Boolean,
        result: CurationResult?,
        resultError: String?,
    ): String = buildString {
        append("<div class=\"ds-page ds-page-wide\">")
        append("<h1 class=\"ds-title\">Curate</h1>")
        append("<p class=\"ds-sub\">Paste text in and the curator reads out statements and conditional readings, ")
            .append("each tied to the quote it came from.</p>")
        if (!available) append("<p class=\"ds-curate-warn\">The curation engine is not available right now.</p>")
        if (listError != null) append("<p class=\"ds-curate-error\">").append(esc(listError)).append("</p>")
        append("<form class=\"ds-curate-form\" data-curate-form=\"1\">")
        append("<label class=\"ds-curate-label\" for=\"ds-curate-name\">Document name (optional)</label>")
        append("<input class=\"ds-curate-name\" id=\"ds-curate-name\" type=\"text\" value=\"")
            .append(esc(pendingName)).append("\" placeholder=\"Untitled\">")
        append("<label class=\"ds-curate-label\" for=\"ds-curate-text\">Text</label>")
        append("<textarea class=\"ds-curate-text\" id=\"ds-curate-text\" rows=\"10\" placeholder=\"Paste or write the text to curate…\">")
            .append(esc(pendingText)).append("</textarea>")
        append("<div class=\"ds-curate-dest\">")
        if (destination != null) append("Destination model: <strong>").append(esc(destination.model)).append("</strong>")
            .append(" <span class=\"ds-dim\">(").append(esc(destination.provider)).append(")</span>")
        else append("<span class=\"ds-dim\">No curation destination is available.</span>")
        append("</div>")
        if (formError != null) append("<p class=\"ds-curate-error\">").append(esc(formError)).append("</p>")
        append("<button type=\"submit\" class=\"ds-curate-submit\" data-curate-submit=\"1\"")
        if (busy || destination == null || !available) append(" disabled")
        append(">").append(if (busy) "Curating…" else "Curate").append("</button>")
        append("</form>")
        if (records.isNotEmpty()) {
            append("<h2 class=\"ds-curate-h2\">Saved attempts</h2><ul class=\"ds-curate-list\">")
            for (r in records) {
                val open = r.receiptCid == result?.receiptCid
                append("<li><a class=\"ds-curate-item").append(if (open) " ds-selected" else "").append('"')
                append(" href=\"#").append(CURATION_HASH).append('/').append(esc(r.receiptCid))
                    .append("\" data-curate-open=\"").append(esc(r.receiptCid)).append("\">")
                append(esc(r.name.ifBlank { "Untitled" })).append(" <span class=\"ds-dim\">")
                    .append(esc(shortCid(r.receiptCid))).append("</span></a></li>")
            }
            append("</ul>")
        }
        if (resultError != null) append("<p class=\"ds-curate-error\">").append(esc(resultError)).append("</p>")
        if (result != null) append(curationResultHtml(result))
        append("</div>")
    }

    fun curationResultHtml(result: CurationResult): String = buildString {
        append("<section class=\"ds-curate-result\">")
        append("<h2 class=\"ds-curate-h2\">").append(esc(result.name.ifBlank { "Untitled" })).append("</h2>")
        append("<p class=\"ds-sub\">Saved attempt · <code class=\"ds-cid\" title=\"")
            .append(esc(result.receiptCid)).append("\">").append(esc(shortCid(result.receiptCid))).append("</code></p>")
        val project = result.project?.takeIf { it.isNotBlank() && it != CURATION_HASH }
        val documentId = result.documentId?.takeIf { it.isNotBlank() }
        if (project != null && documentId != null) {
            append("<p><a href=\"/documents#").append(WikiSurface.encode(project)).append('/').append(WikiSurface.encode(documentId))
                .append("\" data-source-project=\"").append(esc(project)).append("\" data-source-document=\"")
                .append(esc(documentId)).append("\">Open current project document</a> ")
                .append("(it may have changed since this attempt).</p>")
        }
        append(curationConfixLink(result.receiptCid, "Inspect retained attempt in Confix"))
        append(curationReceiptsHtml(result))
        append("<details class=\"ds-curate-source\"><summary>Source text</summary><pre>")
            .append(esc(result.text)).append("</pre></details>")
        val statements = result.proposals.filter { it.subject != null && it.predicate != null && it.obj != null }
        if (statements.isNotEmpty()) {
            val validText = textValid(result)
            append("<h3 class=\"ds-curate-h3\">Proposed statements</h3><ul class=\"ds-curate-proposals\">")
            for (p in statements) {
                append("<li class=\"ds-curate-proposal").append(if (p.submitted) " ds-curate-admitted" else " ds-curate-review").append("\">")
                append("<div class=\"ds-curate-triple\">").append(esc(p.subject!!)).append(" <span class=\"ds-dim\">")
                    .append(esc(p.predicate!!)).append("</span> ").append(esc(p.obj!!)).append("</div>")
                if (!p.quote.isNullOrBlank()) append("<blockquote class=\"ds-curate-quote\">“").append(esc(p.quote)).append("”</blockquote>")
                val passage = passage(result, p, validText)
                if (passage != null) append("<p><a data-passage-receipt=\"").append(esc(passage.receiptCid)).append("\" href=\"")
                    .append(esc(SourceSelection.from(passage).documentsHref()))
                    .append("\">Show passage in project document</a></p>")
                append("<div class=\"ds-curate-status\">")
                    .append(when {
                        p.submitted -> "Submitted as source attribution"
                        p.duplicate -> "Previously recorded source attribution"
                        else -> "Needs review"
                    }).append("</div>")
                if (p.reasons.isNotEmpty()) append("<div class=\"ds-curate-reasons\">").append(esc(p.reasons.joinToString("; "))).append("</div>")
                append("</li>")
            }
            append("</ul>")
        }
        if (result.axioms.isNotEmpty()) {
            append("<h3 class=\"ds-curate-h3\">Conditional / causal readings</h3><ul class=\"ds-curate-axioms\">")
            for (a in result.axioms) {
                append("<li class=\"ds-curate-axiom\">")
                append("<div class=\"ds-curate-triple\">")
                if (a.predicate == "implies") append("If ").append(esc(a.antecedent.orEmpty()))
                    .append(" then ").append(esc(a.consequent.orEmpty()))
                else append(esc(a.antecedent.orEmpty())).append(" <span class=\"ds-dim\">")
                    .append(esc(a.predicate.orEmpty())).append("</span> ").append(esc(a.consequent.orEmpty()))
                append("</div>")
                if (!a.quote.isNullOrBlank()) append("<blockquote class=\"ds-curate-quote\">“").append(esc(a.quote)).append("”</blockquote>")
                append("<div class=\"ds-curate-status\">").append(esc(a.label ?: "admission candidate")).append("</div>")
                append("</li>")
            }
            append("</ul>")
        }
        val unparsed = result.proposals.filter { it.subject == null || it.predicate == null || it.obj == null }
        for (p in unparsed) {
            append("<p class=\"ds-curate-error\">Needs review: ")
                .append(esc(p.reasons.joinToString("; ").ifBlank { "The model response could not be read as a statement." }))
                .append("</p>")
        }
        if (result.proposals.isEmpty() && result.axioms.isEmpty())
            append("<p class=\"ds-empty\">No statements are retained in this attempt.</p>")
        if (result.reasons.isNotEmpty()) {
            append("<h3 class=\"ds-curate-h3\">Notes on this document</h3><ul class=\"ds-curate-notes\">")
            for (r in result.reasons) append("<li>").append(esc(r)).append("</li>")
            append("</ul>")
        }
        append("</section>")
    }

    /** Status belongs to each recorded stage, not to HTTP success or to the enclosing LCNC run. */
    fun curationReceiptsHtml(result: CurationResult): String = buildString {
        append("<div class=\"ds-curate-receipts\"><h3 class=\"ds-curate-h3\">Recorded stage outcomes</h3>")
        append("<p class=\"ds-curate-status\">A saved attempt is not a verification of its statements. ")
            .append("Stages without a receipt have no recorded outcome.</p>")
        if (result.stages.size == 0) append("<p class=\"ds-curate-warn\">No stage receipts are available for this attempt.</p>")
        else {
            append("<ul class=\"ds-curate-notes\">")
            for (r in result.stages.view) {
                val status = when (r.status) {
                    "SUCCESS" -> "succeeded"
                    "FAILURE" -> "failed"
                    "SKIPPED" -> "skipped"
                    null, "" -> "status unavailable"
                    else -> "unrecognized status: ${r.status}"
                }
                append("<li><strong class=\"").append(when (r.status) {
                    "FAILURE" -> "ds-curate-error"
                    "SUCCESS" -> "ds-curate-status"
                    else -> "ds-curate-warn"
                }).append("\">").append(esc(r.stage ?: "Unknown stage")).append(" · ")
                    .append(esc(status)).append("</strong>")
                r.tool?.let { append(" · ").append(esc(it)) }
                append("<div class=\"ds-cid\">").append(esc(r.receiptCid ?: "Stage receipt CID unavailable")).append("</div>")
                append(curationConfixLink(r.receiptCid, "Inspect stage receipt in Confix"))
                append("</li>")
            }
            append("</ul>")
        }
        append("<h3 class=\"ds-curate-h3\">Model call receipt</h3>")
        val receipt = result.modelReceipt
        if (receipt == null) append("<p class=\"ds-curate-status\">No model-call receipt is available; a call is not established.</p>")
        else {
            append("<dl class=\"ds-run-meta\"><dt>Receipt</dt><dd class=\"ds-cid\">")
                .append(esc(receipt.receiptId ?: "Unavailable")).append("</dd>")
            append("<dt>Model</dt><dd>").append(esc(receipt.modelId ?: "Unavailable")).append("</dd>")
            append("<dt>Provider</dt><dd>").append(esc(receipt.providerId ?: "Unavailable")).append("</dd>")
            append("<dt>Transport</dt><dd>").append(when (receipt.httpStatus) {
                null -> "HTTP status unavailable"
                0 -> "No HTTP response (status 0)"
                else -> "HTTP ${receipt.httpStatus}"
            }).append("</dd>")
            append("<dt>Latency</dt><dd>").append(receipt.latencyMs?.let { "$it ms" } ?: "Unavailable").append("</dd>")
            append("<dt>Cache</dt><dd>").append(when (receipt.cachedHit) {
                true -> "Cached response"
                false -> "Uncached call"
                null -> "Cache status unavailable"
            }).append("</dd>")
            receipt.errorClass?.let { append("<dt>Error class</dt><dd class=\"ds-curate-error\">").append(esc(it)).append("</dd>") }
            append("</dl>")
        }
        append("</div>")
    }

    /** Curator and stage receipts are canonical CBOR, never a guessed JSON or live program. */
    fun curationConfixLink(cid: String?, label: String): String =
        if (cid == null || !Regex("sha256:[0-9a-f]{64}").matches(cid)) ""
        else "<a href=\"/panels?content=$cid&amp;syntax=CBOR\" target=\"_blank\" rel=\"noopener\">${esc(label)}</a>"

    // ── the shell ───────────────────────────────────────────────────────────

    /** Sidebar and a main column of breadcrumb over content; the page fills the three by id. */
    fun layout(): String =
        "<aside class=\"ds-side\" id=\"$SIDE_ID\" aria-label=\"Workspace\"></aside>" +
        "<main class=\"ds-main\">" +
            "<div class=\"ds-crumb\" id=\"$CRUMB_ID\"></div>" +
            "<div class=\"ds-content\" id=\"$CONTENT_ID\"></div>" +
        "</main>"

    // ── the sidebar ─────────────────────────────────────────────────────────

    /**
     * One tree: every mounted project, with the selected project's pages nested under it.
     * Only the open project carries its children, which is what keeps a workspace of many
     * projects readable and is why [docs] is fetched per project rather than all at once.
     */
    fun sidebarHtml(
        projects: List<ProjectRow>,
        selected: String?,
        docs: List<DocRow> = emptyList(),
        selectedDoc: String? = null,
        curationActive: Boolean = false,
    ): String = buildString {
        append("<div class=\"ds-brand\">Forge</div>")
        append("<a class=\"ds-curate-link").append(if (curationActive) " ds-selected" else "").append('"')
        if (curationActive) append(" aria-current=\"true\"")
        append(" href=\"#").append(CURATION_HASH).append("\" data-curate=\"1\">Curate</a>")
        append("<div class=\"ds-side-label\">Workspaces</div>")
        if (projects.isEmpty()) {
            append("<p class=\"ds-empty\">No project is mounted. Drop a folder on the harness, or POST its path to /api/projects.</p>")
            return@buildString
        }
        append("<ul class=\"ds-tree\">")
        for (p in projects) {
            val open = p.name == selected
            append("<li><a class=\"ds-proj").append(if (open) " ds-selected" else "").append('"')
            if (open) append(" aria-current=\"true\"")
            append(" href=\"#").append(esc(p.name)).append("\" data-project=\"").append(esc(p.name)).append("\">")
            append("<span class=\"ds-caret\">").append(if (open) "▾" else "▸").append("</span>")
            append("<span class=\"ds-name\">").append(esc(p.name)).append("</span>")
            append("<span class=\"ds-count\">").append(p.docs).append("</span></a>")
            if (open) append(pagesHtml(p.name, docs, selectedDoc))
            append("</li>")
        }
        append("</ul>")
    }

    /** The open project's pages. A page is a document; the icon says which kind at a glance. */
    fun pagesHtml(project: String, rows: List<DocRow>, selectedId: String?): String = buildString {
        if (rows.isEmpty()) { append("<p class=\"ds-empty ds-empty-pages\">No pages yet.</p>"); return@buildString }
        append("<ul class=\"ds-pages\">")
        for (d in rows) {
            append("<li><a class=\"ds-page").append(if (d.id == selectedId) " ds-selected" else "").append('"')
            if (d.id == selectedId) append(" aria-current=\"true\"")
            append(" href=\"#").append(esc(project)).append('/').append(esc(d.id))
            append("\" data-doc=\"").append(esc(d.id)).append("\" title=\"")
            if (d.contentStatus == "unchecked-metadata") append("Unchecked metadata: ")
            append(esc(d.cid)).append("\">")
            append("<span class=\"ds-ico\">").append(if (isMarkdownName(d.id)) "▤" else "▢").append("</span>")
            append("<span class=\"ds-name\">").append(esc(d.id)).append("</span></a></li>")
        }
        append("</ul>")
    }

    // ── the breadcrumb and the view switch ──────────────────────────────────

    fun curationCrumbHtml(result: CurationResult?): String = buildString {
        append("<div class=\"ds-crumbs\"><span class=\"ds-here\">Curate</span>")
        if (result != null) append("<span class=\"ds-sep\">/</span><span class=\"ds-here\">")
            .append(esc(result.name.ifBlank { "Untitled" })).append("</span>")
        append("</div>")
    }

    fun crumbHtml(project: String?, docId: String?, view: SurfaceView): String = buildString {
        append("<div class=\"ds-crumbs\">")
        if (project == null) append("<span class=\"ds-dim\">Pick a workspace</span>")
        else {
            append("<a href=\"#").append(esc(project)).append("\" data-project=\"").append(esc(project)).append("\">")
                .append(esc(project)).append("</a>")
            if (docId != null && view == SurfaceView.PAGE)
                append("<span class=\"ds-sep\">/</span><span class=\"ds-here\">").append(esc(docId)).append("</span>")
        }
        append("</div><div class=\"ds-views\">")
        for (v in SurfaceView.entries) {
            val on = v == view
            append("<button type=\"button\" class=\"ds-view").append(if (on) " ds-on" else "").append('"')
            if (on) append(" aria-pressed=\"true\"")
            append(" data-view=\"").append(v.name.lowercase()).append("\">")
                .append(if (v == SurfaceView.PAGE) "Page" else "Table").append("</button>")
        }
        append("</div>")
    }

    // ── the table view: the project read as its own database ────────────────

    /** Sorting is a projection, never an edit: the rows come back in the order asked for. */
    fun sortDocs(rows: List<DocRow>, column: DocColumn, ascending: Boolean): List<DocRow> {
        val ordered = when (column) {
            DocColumn.NAME -> rows.sortedBy { it.id.lowercase() }
            DocColumn.TYPE -> rows.sortedWith(compareBy({ it.contentType }, { it.id.lowercase() }))
            DocColumn.SIZE -> rows.sortedBy { it.length }
            DocColumn.SEQ -> rows.sortedBy { it.seq }
        }
        return if (ascending) ordered else ordered.reversed()
    }

    fun tableHtml(
        project: String?,
        rows: List<DocRow>,
        column: DocColumn = DocColumn.NAME,
        ascending: Boolean = true,
        selectedId: String? = null,
    ): String = buildString {
        if (project == null) { append("<p class=\"ds-empty\">Pick a workspace.</p>"); return@buildString }
        // A database reads wider than prose: the table view gets the room, the page keeps its column.
        append("<div class=\"ds-page ds-page-wide\"><h1 class=\"ds-title\">").append(esc(project)).append("</h1>")
        append("<p class=\"ds-sub\">").append(rows.size).append(if (rows.size == 1) " page" else " pages")
        append(" · <a href=\"").append(DIGEST_HREF).append("\">Digest this workspace in the harness</a></p>")
        if (rows.any { it.contentStatus == "unchecked-metadata" })
            append("<p class=\"ds-sub\">Some listed CIDs are unchecked metadata; opening a document verifies its bytes when available.</p>")
        if (rows.isEmpty()) { append("<p class=\"ds-empty\">No pages yet.</p></div>"); return@buildString }
        append("<table class=\"ds-table\"><thead><tr>")
        for (c in DocColumn.entries) {
            val on = c == column
            append("<th class=\"ds-th").append(if (on) if (ascending) " ds-asc" else " ds-desc" else "").append('"')
            append(" data-sort=\"").append(c.key).append("\">").append(c.label)
            if (on) append("<span class=\"ds-arrow\">").append(if (ascending) "↑" else "↓").append("</span>")
            append("</th>")
        }
        append("<th class=\"ds-th ds-th-cid\">Cid</th></tr></thead><tbody>")
        for (d in sortDocs(rows, column, ascending)) {
            append("<tr class=\"ds-row").append(if (d.id == selectedId) " ds-selected" else "").append('"')
            append(" data-doc=\"").append(esc(d.id)).append("\">")
            append("<td class=\"ds-cell-name\"><span class=\"ds-ico\">")
                .append(if (isMarkdownName(d.id)) "▤" else "▢").append("</span>")
                .append("<span class=\"ds-name\">").append(esc(d.id)).append("</span></td>")
            append("<td class=\"ds-dim\">").append(esc(d.contentType)).append("</td>")
            append("<td class=\"ds-num\">").append(bytes(d.length)).append("</td>")
            append("<td class=\"ds-num\">").append(d.seq).append("</td>")
            append("<td class=\"ds-cid\" title=\"").append(esc(d.cid)).append("\">").append(esc(shortCid(d.cid)))
            if (d.contentStatus == "unchecked-metadata") append(" <span class=\"ds-dim\">(unchecked metadata)</span>")
            append("</td>")
            append("</tr>")
        }
        append("</tbody></table></div>")
    }

    // ── the page ────────────────────────────────────────────────────────────

    /**
     * [runs] is what the read route said about this page's `lcnc-run` blocks, keyed by the ordinal
     * [RunBlock.scan] hands out. An ordinal with no state renders its frame unread — the reader
     * sees the block exists before the daemon has answered, and never a lamp nobody was told.
     */
    fun retainableRevision(view: DocView): DocRevision? = view.sourceRevision?.takeIf {
        view.canRetainSource && it.project == view.project && it.id == view.id &&
            it.cid == view.cid && it.rev == view.rev && it.seq == view.seq && it.seq >= 0 && it.rev.isNotBlank() &&
            cidPattern.matches(it.cid) && view.id.substringAfterLast('.', "").lowercase() in _s["txt", "md"]
    }

    fun documentHtml(view: DocView?, runs: Map<Int, RunBlock.State> = emptyMap(), retention: SourceRetentionState? = null): String {
        if (view == null) return "<p class=\"ds-empty\">Pick a page.</p>"
        val sb = StringBuilder()
        sb.append("<div class=\"ds-page\">")
        sb.append("<h1 class=\"ds-title\">").append(esc(view.id)).append("</h1>")
        retainableRevision(view)?.let { revision ->
            val state = retention?.takeIf { it.revision == revision }
            sb.append("<button type=\"button\" class=\"ds-curate-submit\" data-retain-source=\"1\"")
            if (state?.pending == true) sb.append(" disabled aria-busy=\"true\"")
            sb.append(">Retain source for review</button>")
            state?.message?.let { sb.append("<p class=\"ds-retain-status\" role=\"status\">").append(esc(it)).append("</p>") }
        }
        fun showRevision(label: String, revision: DocRevision?) {
            sb.append("<p class=\"ds-sub\">").append(esc(label)).append(": ")
            if (revision == null) sb.append("unavailable") else sb.append(esc(revision.id))
                .append(" · sequence ").append(revision.seq)
                .append(" · <code class=\"ds-cid\" title=\"").append(esc(revision.cid)).append("\">")
                .append(esc(shortCid(revision.cid))).append("</code>")
                .append(" · rev <code title=\"").append(esc(revision.rev)).append("\">")
                .append(esc(shortRev(revision.rev))).append("</code>")
            sb.append("</p>")
        }
        if (view.hasRevisionDetails) {
            sb.append("<p class=\"ds-sub\">").append(esc(view.contentType.ifBlank { "document" })).append("</p>")
            showRevision("Source document", view.sourceRevision)
            showRevision("Displayed text", view.displayTextRevision)
            sb.append("<p class=\"ds-sub\">Text may be a preview. Revisions are read separately; an extraction is not verified against this source here.</p>")
        } else {
            sb.append("<p class=\"ds-sub\">").append(esc(view.contentType.ifBlank { "document" }))
                .append(" · sequence ").append(view.seq)
                .append(" · <code class=\"ds-cid\" title=\"").append(esc(view.cid)).append("\">")
                .append(esc(shortCid(view.cid))).append("</code>")
                .append(" · rev <code title=\"").append(esc(view.rev)).append("\">")
                .append(esc(shortRev(view.rev))).append("</code></p>")
        }
        sb.append("<article class=\"ds-body\">")
        if (isMarkdown(view)) {
            var ordinal = 0
            sb.append(DocumentMarkdown.render(view.text) { info, body ->
                if (info != RunBlock.INFO) null else RunBlock.blockHtml(RunBlock.parse(ordinal++, body), runs)
            })
        } else sb.append("<pre>").append(DocumentMarkdown.escape(view.text)).append("</pre>")
        sb.append("</article>")
        view.extract?.let { twin ->
            if (view.hasRevisionDetails && view.extractionRevision != null && view.extractionRevision == view.displayTextRevision) return@let
            sb.append("<section class=\"ds-extract\"><h2>Extract (the miner's twin)</h2>")
            if (view.hasRevisionDetails) showRevision("Extracted text", view.extractionRevision)
            sb.append(DocumentMarkdown.render(twin)).append("</section>")
        }
        sb.append("</div>")
        return sb.toString()
    }

    fun isMarkdown(view: DocView): Boolean =
        view.contentType.startsWith("text/markdown") || isMarkdownName(view.id)

    fun isMarkdownName(id: String): Boolean =
        id.endsWith(".md", ignoreCase = true) || id.endsWith(".markdown", ignoreCase = true)

    /** Bytes as a reader says them, so a table column stays one glance wide. */
    fun bytes(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> ((n * 10 / 1024).toDouble() / 10).toString() + " KB"
        else -> ((n * 10 / (1024 * 1024)).toDouble() / 10).toString() + " MB"
    }

    /** A revision is a generation and a hash; the generation is the part a reader uses. */
    fun shortRev(rev: String): String {
        val dash = rev.indexOf('-')
        return if (dash <= 0) shortCid(rev) else rev.take(dash + 1) + shortCid(rev.substring(dash + 1))
    }

    fun shortCid(cid: String): String {
        val hex = cid.substringAfter(':', cid)
        return if (hex.length > 12) cid.substringBefore(':', "").let { if (it.isEmpty()) "" else "$it:" } + hex.take(12) else cid
    }

    fun esc(s: String): String = DocumentMarkdown.escape(s)
}
