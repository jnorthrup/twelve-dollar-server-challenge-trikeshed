package borg.trikeshed.forge.server

import borg.trikeshed.parse.reify
import borg.trikeshed.parse.jsonOf

import borg.trikeshed.forge.ForgeApp
import borg.trikeshed.kanban.ForgeKanbanIngest
import kotlinx.datetime.Clock

/**
 * ForgeRoutes — commonMain-sourced route table for `runKanbanHttpServerJvm`.
 *
 * Every live usecase of KanbanServerMain + JvmKanbanServer is registered here,
 * even the VM-concordant ones. The *table* lives in commonMain; only the
 * execution of tier=VM_DELEGATED / JVM_ONLY delegates to a live host.
 *
 * Tiers:
 *  - PORTABLE — pure Kotlin, no host. Bakes on GH Pages via ForgeApp.renderHtml / generateForgeAssets.
 *               These are the "more powerful long-term" top-level investments.
 *  - VM_DELEGATED — route table + validation in commonMain, eval/spawn needs live VmHost.
 *                   GH Pages bakes the *projection* (hosts.vms sheet, vm-terminal.html shell).
 *  - JVM_ONLY — Tika/ffmpeg extraction, NIO bind; one `expect` actual. Shape gate stays common.
 */
object ForgeRoutes {

    enum class Tier { PORTABLE, VM_DELEGATED, JVM_ONLY }

    data class RouteMeta(
        val method: String,
        val path: String,
        val tier: Tier,
        val description: String,
    )

    /**
     * The canonical registry — every usecase from triage #1-25.
     * Adding a live path without an entry here is a parity failure (ForgeHostSpecParityTest).
     */
    val registry: List<RouteMeta> = listOf(
        // ── Shell + PWA assets (PORTABLE, baked in docs/) ──
        RouteMeta("GET", "/", Tier.PORTABLE, "Forge shell → ForgeApp.renderHtml + {{SEED}}"),
        RouteMeta("GET", "/index.html", Tier.PORTABLE, "alias of /"),
        RouteMeta("GET", "/forge", Tier.PORTABLE, "Forge shell alias for the operator board port"),
        RouteMeta("GET", "/styles.css", Tier.PORTABLE, "PWA asset web/styles.css"),
        RouteMeta("GET", "/kotlin/*", Tier.PORTABLE, "Compiled Kotlin browser app bundles"),
        RouteMeta("GET", "/manifest.webmanifest", Tier.PORTABLE, "PWA manifest"),
        RouteMeta("GET", "/icons/*", Tier.PORTABLE, "PWA icons"),
        // ── Board / health / caps (PORTABLE) ──
        RouteMeta("GET", "/api/health", Tier.PORTABLE, "liveness probe {ok,server,now}"),
        RouteMeta("GET", "/api/cap", Tier.PORTABLE, "protocols + capabilities"),
        RouteMeta("GET", "/api/board", Tier.PORTABLE, "ForgeKanbanIngest.loadProjection → {title,userId,items}"),
        RouteMeta("GET", "/api/metrics", Tier.PORTABLE, "retired flywheel metrics stub (?format=json)"),
        // ── Jules (PORTABLE projection, live driver freshens it) ──
        RouteMeta("GET", "/api/jules/surface", Tier.PORTABLE, "SessionBlackboardAdapter.projectFullSurface (historical board only)"),
        RouteMeta("GET", "/api/jules/events", Tier.PORTABLE, "retired flywheel SSE — answers 410 Gone"),
        // ── Ingest (PORTABLE gate, JVM_ONLY extract actual) ──
        RouteMeta("POST", "/api/submit", Tier.JVM_ONLY, "ingest body → ForgeKanbanIngest.persistMarkdown (Tika actual)"),
        RouteMeta("POST", "/api/donor", Tier.JVM_ONLY, "alias of /api/submit"),
        RouteMeta("POST", "/api/invoke", Tier.PORTABLE, "command queue {commands:[…]} → {accepted,sequence}"),
        // ── Blackboard (PORTABLE) ──
        RouteMeta("GET", "/blackboard/facts", Tier.PORTABLE, "ConfixBlackboard.changes SSE (bounded ring 256)"),
        RouteMeta("POST", "/blackboard/assert", Tier.PORTABLE, "blackboard.put(k,v,ide)"),
        RouteMeta("GET", "/blackboard/sites", Tier.PORTABLE, "keys().filter pointcut/owner/"),
        // ── VM harness (table portable, execution delegated) ──
        RouteMeta("GET", "/api/vm", Tier.VM_DELEGATED, "VM sheet VM_COLUMNS rows"),
        RouteMeta("POST", "/api/vm/spawn", Tier.VM_DELEGATED, "VmHost.spawn(VmSpec) → {id,tier,terminal}"),
        RouteMeta("POST", "/api/vm/{id}/eval", Tier.VM_DELEGATED, "VmHandle.eval → {cid,value:Teleported}"),
        RouteMeta("POST", "/api/vm/{id}/revoke", Tier.VM_DELEGATED, "VmHost.revoke"),
        RouteMeta("GET", "/api/vm/events", Tier.VM_DELEGATED, "VmHost.events SSE"),
        RouteMeta("GET", "/vm-terminal", Tier.VM_DELEGATED, "VT220 page web/vm-terminal.html"),
        RouteMeta("GET", "/api/vm/{id}/terminal", Tier.VM_DELEGATED, "VmTerminalRegistry snapshot"),
        RouteMeta("POST", "/api/vm/{id}/terminal/input", Tier.VM_DELEGATED, "per-vm Channel<TerminalCommand>"),
        RouteMeta("POST", "/api/vm/{id}/terminal/resize", Tier.VM_DELEGATED, "cols×rows → patches"),
        RouteMeta("GET", "/api/vm/terminals", Tier.VM_DELEGATED, "snapshots list"),
        RouteMeta("GET", "/api/vm/terminal/events", Tier.VM_DELEGATED, "VmTerminalRegistry.events SSE"),
    )

    /** Exact/prefix match helper (query stripped). */
    fun match(method: String, path: String): RouteMeta? {
        val p = path.substringBefore('?')
        return registry.firstOrNull { r ->
            r.method == method && when {
                r.path.endsWith("/*") -> p.startsWith(r.path.removeSuffix("/*"))
                r.path.contains("{id}") -> {
                    val prefix = r.path.substringBefore("{id}")
                    val suffix = r.path.substringAfter("{id}")
                    p.startsWith(prefix) && p.endsWith(suffix) && p.length > prefix.length + suffix.length - 1
                }
                else -> p == r.path
            }
        }
    }

    // ── Portable handlers (no host) ──

    fun healthJson(nowMs: Long = Clock.System.now().toEpochMilliseconds()): HttpForwarderResponse =
        HttpForwarderResponse(200, body = """{"ok":true,"server":"kanban","now":$nowMs}""".encodeToByteArray())

    fun capJson(): HttpForwarderResponse =
        HttpForwarderResponse(200, body = """{"protocols":["Http","Json","Socks5","Tls","Bonjour","Upnp"],"capabilities":["Process@local","Cas@local","Wireproto@lan.localhost"]}""".encodeToByteArray())

    /**
     * Fossil-parser fallback — served only when no KanbanModule claims /api/board.
     * NEVER 500s: a plan doc the parser refuses (the "6. Work packages" require)
     * degrades to an empty canonical board with the reason attached. The live
     * board is the module's WAL-backed store, not this re-parse.
     */
    fun boardJson(): HttpForwarderResponse {
        val json = runCatching {
            val reduction = ForgeKanbanIngest.loadProjection("jim")
            jsonOf(linkedMapOf(
                "title" to reduction.source.title,
                "userId" to reduction.source.userId,
                "items" to reduction.board.cards.sortedBy { it.order }.map { card ->
                    linkedMapOf("id" to card.id.value, "title" to card.title, "status" to card.columnId.value)
                },
                "correlations" to reduction.correlations.size,
            ))
        }.getOrElse {
            jsonOf(linkedMapOf(
                "title" to "Board (degraded)",
                "userId" to "jim",
                "items" to emptyList<Any?>(),
                "degraded" to (it.message ?: "plan parse failed"),
            ))
        }
        return HttpForwarderResponse(200, body = json.encodeToByteArray())
    }

    fun metricsResponse(acceptJson: Boolean): HttpForwarderResponse =
        if (acceptJson) {
            HttpForwarderResponse(200, body = """{"retired":"flywheel metrics removed 2026-08-24"}""".encodeToByteArray())
        } else {
            HttpForwarderResponse(200, headers = mapOf("Content-Type" to "text/plain; version=0.0.4; charset=utf-8"), body = "# flywheel metrics retired 2026-08-24\n".encodeToByteArray())
        }

    fun invokeJson(payload: String): HttpForwarderResponse {
        val raw = payload.substringAfter("\r\n\r\n", "").ifEmpty { payload.substringAfter("\n\n", "") }
        if (raw.isBlank()) return HttpForwarderResponse(400, body = """{"error":"empty_body"}""".encodeToByteArray())
        val parsed = runCatching { reify(raw) }.getOrNull()
            ?: return HttpForwarderResponse(400, body = """{"error":"bad_json"}""".encodeToByteArray())
        val commands: List<*> = when (parsed) {
            is Map<*, *> -> (parsed["commands"] as? List<*>) ?: listOf(parsed)
            is List<*> -> parsed
            else -> emptyList<Any?>()
        }
        // sequence is ephemeral in commonMain; jvm side increments atomically. Here we just echo size.
        val keys = commands.mapNotNull { (it as? Map<*, *>)?.get("idempotencyKey") as? String }
        val json = jsonOf(linkedMapOf("ok" to true, "accepted" to commands.size, "idempotencyKeys" to keys))
        return HttpForwarderResponse(202, body = json.encodeToByteArray())
    }

    // The shell render re-parses the sheet seed via Confix on every call — ~45s of
    // CPU once the store holds a full worktree. The shell is a SEED page (the forge
    // Kotlin/JS bundle hydrates live state over the APIs), so a short-TTL memo is
    // semantically free and turns / from a 46-second request into a byte-copy.
    @kotlin.concurrent.Volatile
    private var shellCache: Pair<Long, ByteArray>? = null
    private const val SHELL_TTL_MS = 60_000L

    /** The staged forge assembly — the page's only behavior source since the script.js excision. */
    val SHELL_BUNDLES: List<String> = listOf("./kotlin/forge/forge.js")

    fun shellHtml(userId: String = "jim"): HttpForwarderResponse {
        val now = Clock.System.now().toEpochMilliseconds()
        shellCache?.let { (at, bytes) ->
            if (now - at < SHELL_TTL_MS) {
                return HttpForwarderResponse(200, headers = mapOf("Content-Type" to "text/html; charset=utf-8"), body = bytes)
            }
        }
        val html = runCatching { ForgeApp.renderHtml(userId = userId, bundles = SHELL_BUNDLES) }
            .getOrElse { ex -> "<html><body><h1>Forge shell failed</h1><pre>${ex.message}</pre></body></html>" }
        val bytes = html.encodeToByteArray()
        shellCache = now to bytes
        return HttpForwarderResponse(200, headers = mapOf("Content-Type" to "text/html; charset=utf-8"), body = bytes)
    }

    /** Boot-time prewarm so the FIRST / request is already served from the memo. */
    fun prewarmShell(userId: String = "jim") { shellHtml(userId) }
}
