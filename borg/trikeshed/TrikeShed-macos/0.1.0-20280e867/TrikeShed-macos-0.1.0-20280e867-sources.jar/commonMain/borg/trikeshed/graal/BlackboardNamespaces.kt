package borg.trikeshed.graal

/**
 * BlackboardNamespaces — the first enumeration of the daemon blackboard's key
 * prefixes, and the DEFAULT admit list for [BlackboardChangesFactElement].
 *
 * The blackboard has never had a schema: every writer picks a `prefix/…` key
 * ad hoc and the readers (BlackboardWire, graal.html, the LCNC blackboard
 * nodes) carry tribal lists of what those prefixes mean. This object is a data
 * object in the plain sense — a table, not code — so the admit list can change
 * by editing a row rather than a predicate, and every prefix has its meaning
 * and its producer written next to it.
 *
 * Admission rule: a key is admitted into the `blackboard` fact partition unless
 * one of [excludedByDefault] is a prefix of it. The three excluded prefixes are
 * the OUTPUTS of rule firing — receipts the production sink and the NARS
 * curation write back onto the blackboard. Admitting them would make every
 * firing a fresh fact, every fresh fact a rule evaluation, and every evaluation
 * a firing: the blackboard → rete → sink → blackboard loop the merger brief
 * names as its first hazard. They stay receipt-only on the board (readable
 * through `/blackboard/board`, never watchable through a production).
 */
data object BlackboardNamespaces {

    /** One row of the table: a key prefix, what lives under it, and who writes it. */
    data class Namespace(
        val prefix: String,
        val meaning: String,
        val producer: String,
        /** False for rule-firing outputs; these never enter the fact plane by default. */
        val admitted: Boolean = true,
    )

    /**
     * Every prefix a `blackboard.put` in the source tree writes today, longest
     * prefix first so [namespaceOf] resolves `narsese/curation/` before
     * `narsese/`. Add a row when a new writer appears; flip `admitted` to false
     * for anything a production's firing produces.
     */
    val known: List<Namespace> = listOf(
        Namespace("headhunter/", "versioned professional evidence, sources, listings, relationships, artifacts and activity", "HeadhunterStore"),
        Namespace("narsese/curation/", "belief-bag curation receipts, one per (kind, angular) reviewed downstream of a rule firing", "BoardReviewBridge via the production sink", admitted = false),
        Namespace("narsese/rete/firing/", "NARS rete firing receipts keyed by firing cid", "OroborosDaemon narsese firing collector", admitted = false),
        Namespace("kanban/rule/", "production-sink activation receipts: bindings + salience per (ruleId, activationId)", "KanbanModule productionSink", admitted = false),
        Namespace("kanban/claim/", "claim receipts per jobId: {owner, model, ok, content|error, atMs, revision} — the brain's answer a human reads in REVIEW", "BoardClaimWorker"),
        Namespace("agent/run/", "coding-agent run receipts per runId (Forge genesis, Cut A): {agent, cli, version, model, repo, base, exit, ok, killed, truncated, transcriptCid, patchCid, patchBytes, filesChanged, summary, error} — the evidence id a MUST met by a file change cites", "AgentLegos / BoardClaimWorker agent lane"),
        Namespace("kanban/fanout/", "fan-out receipts per parent jobId: {models, children, submitted, readied, join, ok, startedAtMs, finishedAtMs, atMs, revision} — how a MODELS:/FANOUT: card was split into child cards (Delta 2026-09-05); admitted like kanban/claim/, so the plane can cite the split", "BoardFanOutWorker"),
        Namespace("kanban/committed/", "board store commit receipts per (jobId, sequence)", "KanbanModule committed collector"),
        Namespace("kanban/review/", "kanban-nars review gloss per angular", "KanbanModule review bridge"),
        Namespace("kanban/drift/", "board drift observations stamped by the module clock", "KanbanModule ticker"),
        Namespace("kanban/", "kanban module surface (anything not under a narrower kanban/ row)", "KanbanModule"),
        Namespace("lcnc/prompt/", "stored prompt heads {name, cid, previousCid, role, variables, tags, chars, text, savedAtMs} per prompt", "LcncPublisher.publishPrompt"),
        Namespace("lcnc/publish/", "publish outcomes per program (Forge genesis, Cut C): {verdict, reason?, cid?, previousCid?, baseCid?, currentCid?, atMs, actor} — a stale-base refusal is a receipt, board-only", "PatchWire via LcncPublisher.publishOutcome", admitted = false),
        Namespace("lcnc/stale/", "one marker per completed run whose consumed inputs moved since it read them (Forge genesis, Cut S): {runId, receiptKey, receiptCid, programKey, programCid, inputs[], count, atMs} — a rule firing's output, kept off the fact plane", "KanbanModule productionSink via LcncStaleMarker", admitted = false),
        Namespace("lcnc/snapshot/", "the workspace snapshot head: {cid, previousCid, atMs, note, counts} — the whole workspace named at one instant (Forge genesis, Cut C)", "WorkspaceSnapshotService via LcncPublisher.publishSnapshot"),
        Namespace("lcnc/program/", "typed program entries {name, document, cables, violations, sourceCid} per canvas", "LcncPublisher.publishProgram"),
        Namespace("lcnc/vocabulary", "the node-type vocabulary the canvases are built from", "LcncPublisher.publishAll"),
        Namespace("lcnc/", "LCNC surface (anything not under a narrower lcnc/ row)", "LcncPublisher"),
        Namespace("pointcut-def/", "pointcut definitions written through the assert funnel; enabled=false suppresses a runtime site", "PointcutDefinitionWriter.applyFunnelDoc"),
        Namespace("pointcut/", "pointcut landings keyed pointcut/<typedef>/<method>/<siteIdx>, value is a PointcutLanding", "PointcutBlackboardAdapter.put (Hypervisor and daemon adapters)"),
        Namespace("hermes/python/pointcut/import/", "GraalPy import-site pointcuts observed in the Hermes sleeve", "HermesPythonPort"),
        Namespace("hermes/python/gap/", "gaps between the Hermes source root and the sleeve, per root", "HermesPythonPort"),
        Namespace("hermes/python/pen/", "pen verbs delegated to the Hermes sleeve, per verb and ordinal", "HermesPenDelegates"),
        Namespace("hermes/console/signal/", "console signals raised by the Hermes xterm session", "HermesVmConsole"),
        Namespace("hermes/wiki-trainer/", "wiki trainer corpus roots", "HermesWikiTrainerCorpus"),
        Namespace("hermes/", "Hermes surface (anything not under a narrower hermes/ row)", "Hermes bridges"),
        Namespace("construction-kif/", "KIF minted by the construction reader, keyed by content cid", "OroborosDaemon reader lane"),
        Namespace("nal-kif/", "KIF minted from NAL, keyed by content cid", "OroborosDaemon nal.mint lane"),
        Namespace("legal-kif/", "KIF ingested from legal text or recorded by the council, keyed by content cid", "OroborosDaemon legal.ingest and council.record lanes"),
        Namespace("kif-ledger/", "durable KIF ledger entries mirrored from couch", "NarsDurableLedger thaw"),
        Namespace("rete-rule/", "rete rule definitions keyed by rule cid", "OroborosDaemon rule lane"),
        Namespace("council-case/", "council case documents per caseId", "CouncilNodes"),
        Namespace("hook-intake/", "webhook intake receipts per (program, node, port, nuid)", "CouchWebhookBindings"),
        Namespace("hook-run/", "webhook run receipts per (program, node, port, nuid), status field carries the outcome", "CouchWebhookBindings"),
        Namespace("hook-receipt/", "webhook delivery receipts per (subscription, nuid)", "CouchChangesWebhookBridge"),
        Namespace("hook-delivery-out/", "outbound hook delivery ledger entries", "CausalHookDeliveryLedger"),
        Namespace("hook-delivery/", "inbound hook delivery ledger entries", "CausalHookDeliveryLedger"),
        Namespace("context-receipt/", "ACE context chunk receipts keyed by chain head", "AceContextNodes"),
        Namespace("camel/route/", "one entry per LONG-LIVED camel route: {id, module, from, to, status, routes, exchanges, startedAtMs, lastExchangeAtMs} on start and stop, and `camel/route/<id>/exchange` {route, seq, body, truncated, from, to, atMs} once per Exchange that crosses the tap — INPUT to the fact plane, not a rule firing's output, which is why it is admitted: a route is the daemon's intake and a fact per arrival is the whole reason it is watchable", "CamelRouteLegos via CamelRuntime"),
        Namespace("camel/", "camel surface (anything not under a narrower camel/ row)", "CamelRouteLegos"),
        Namespace("mux/key/", "REDACTED working key entries keyed by sha256(keyId) fingerprint: {provider, label, status, lastModel, lastUsedMs, accessCount, leasedTo, leaseExpiresAt} — the keyId never crosses, the ReactorSource lane treats it as credential material", "MuxBlackboardProjection via the daemon flowState collector"),
        Namespace("mux/model/", "working model entries {provider, contextWindow, available} per modelId", "MuxBlackboardProjection"),
        Namespace("mux/quota/", "provider quota windows {limit, spent, remaining, exhausted, windowStartMs, windowMs} from the legion's standings", "MuxBlackboardProjection"),
        Namespace("mux/health/", "provider health {successRate, recentLatencyMs, updatedAt}", "MuxBlackboardProjection"),
        Namespace("mux/state", "the working-set summary {keys, activeKeys, availableKeys, models, running, queueDepth, tickSequence, lastTickMs}", "MuxBlackboardProjection"),
        Namespace("mux/", "mux surface (anything not under a narrower mux/ row)", "MuxBlackboardProjection"),
        Namespace("document/curation/", "one summary per retained curation record, keyed by the record cid's hex: {receiptCid, name, originalCid, textCid, model, proposals, submitted, quotationsSubmitted, stages, rules, stageReceiptCids, reasons}; the full provenance is the `documents` fact partition under curationCid", "DocumentCurationWire.publish"),
        Namespace("document/stage/", "per-correlation stage receipts: `document/stage/<correlation>/<stage>` is the retained DocumentToolReceipt of that stage (tool, implementation, status, times, input/output cids, error, receiptCid); the observer's boundary heartbeats use the same prefix with the curator's boundary names", "DocumentCurationWire.publish and the DocumentCuratorObserver"),
        Namespace("document/", "document curation surface (anything not under a narrower document/ row)", "DocumentCurationWire"),
        Namespace("module/", "module supervisor receipts: attached, detached, attach-failed", "ModuleSupervisor"),
        Namespace("daemon/", "daemon boot and index receipts (daemon/boot/*, daemon/linecas-index)", "OroborosDaemon"),
        Namespace("oroboros/", "reserved for daemon-lane receipts; no writer in the source tree today", "none yet"),
        Namespace("narsese/", "NARS surface (anything not under a narrower narsese/ row)", "OroborosDaemon narsese lanes"),
    )

    /** Prefixes that never enter the fact plane by default: the rule-firing outputs (the loop surface). */
    val excludedByDefault: List<String> = known.filter { !it.admitted }.map { it.prefix }

    /** The default admit predicate for [BlackboardChangesFactElement]: true unless an excluded prefix starts the key. */
    fun admitByDefault(key: String): Boolean {
        for (p in excludedByDefault) if (key.startsWith(p)) return false
        return true
    }

    /** The most specific known row for a key, or null for a key no row describes. */
    fun namespaceOf(key: String): Namespace? {
        var best: Namespace? = null
        for (n in known) if (key.startsWith(n.prefix) && (best == null || n.prefix.length > best.prefix.length)) best = n
        return best
    }
}
