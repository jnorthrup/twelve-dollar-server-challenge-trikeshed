package borg.trikeshed.graph.query

/**
 * A basic generic directed graph interface.
 */
interface Graph<N, E> {
    val nodes: Set<N>
    fun outEdges(node: N): Map<N, E>
    fun inEdges(node: N): Map<N, E>
}

/**
 * A generic mutable graph.
 */
interface MutableGraph<N, E> : Graph<N, E> {
    fun addNode(node: N): Boolean
    fun removeNode(node: N): Boolean
    fun addEdge(from: N, to: N, edge: E)
    fun removeEdge(from: N, to: N): Boolean
}

/**
 * Basic in-memory adjacency list graph implementation.
 */
class AdjacencyListGraph<N, E> : MutableGraph<N, E> {
    private val outAdj = mutableMapOf<N, MutableMap<N, E>>()
    private val inAdj = mutableMapOf<N, MutableMap<N, E>>()

    override val nodes: Set<N> get() = outAdj.keys

    override fun outEdges(node: N): Map<N, E> = outAdj[node] ?: emptyMap()

    override fun inEdges(node: N): Map<N, E> = inAdj[node] ?: emptyMap()

    override fun addNode(node: N): Boolean {
        if (outAdj.containsKey(node)) return false
        outAdj[node] = mutableMapOf()
        inAdj[node] = mutableMapOf()
        return true
    }

    override fun removeNode(node: N): Boolean {
        if (!outAdj.containsKey(node)) return false

        // Remove incoming edges to this node from other nodes
        inAdj[node]?.keys?.forEach { from ->
            outAdj[from]?.remove(node)
        }

        // Remove outgoing edges from this node to other nodes
        outAdj[node]?.keys?.forEach { to ->
            inAdj[to]?.remove(node)
        }

        outAdj.remove(node)
        inAdj.remove(node)
        return true
    }

    override fun addEdge(from: N, to: N, edge: E) {
        addNode(from)
        addNode(to)
        outAdj[from]!![to] = edge
        inAdj[to]!![from] = edge
    }

    override fun removeEdge(from: N, to: N): Boolean {
        val removedOut = outAdj[from]?.remove(to) != null
        val removedIn = inAdj[to]?.remove(from) != null
        return removedOut && removedIn
    }
}

/**
 * Query builder to traverse graphs.
 */
class GraphQuery<N, E>(private val graph: Graph<N, E>, private val currentNodes: Set<N>) {

    /** Filter current nodes by a predicate. */
    fun filter(predicate: (N) -> Boolean): GraphQuery<N, E> {
        return GraphQuery(graph, currentNodes.filter(predicate).toSet())
    }

    /** Traverse outbound edges from the current nodes. */
    fun out(): GraphQuery<N, E> {
        val nextNodes = mutableSetOf<N>()
        for (node in currentNodes) {
            nextNodes.addAll(graph.outEdges(node).keys)
        }
        return GraphQuery(graph, nextNodes)
    }

    /** Traverse inbound edges from the current nodes. */
    fun `in`(): GraphQuery<N, E> {
        val nextNodes = mutableSetOf<N>()
        for (node in currentNodes) {
            nextNodes.addAll(graph.inEdges(node).keys)
        }
        return GraphQuery(graph, nextNodes)
    }

    /** Traverse out filtering edges by a predicate. */
    fun outE(predicate: (E) -> Boolean): GraphQuery<N, E> {
        if (currentNodes.isEmpty()) return this
        val nextNodes = mutableSetOf<N>()
        for (node in currentNodes) {
            for (entry in graph.outEdges(node)) {
                if (predicate(entry.value)) nextNodes.add(entry.key)
            }
        }
        return GraphQuery(graph, nextNodes)
    }
}