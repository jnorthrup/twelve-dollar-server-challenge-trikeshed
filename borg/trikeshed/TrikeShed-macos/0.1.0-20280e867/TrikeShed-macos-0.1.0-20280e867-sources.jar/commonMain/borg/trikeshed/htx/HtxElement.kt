package borg.trikeshed.htx

import borg.trikeshed.context.Drain
import borg.trikeshed.lib.forEach
import borg.trikeshed.lib.Join
import borg.trikeshed.lib.Series
import borg.trikeshed.lib.emptySeriesOf
import borg.trikeshed.lib.j
import borg.trikeshed.lib.toSeries
import borg.trikeshed.userspace.FanoutEvent
import borg.trikeshed.userspace.FanoutEventSubscriber
import borg.trikeshed.userspace.nio.spi.NioSupervisor
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlin.coroutines.CoroutineContext

typealias HtxFrames = Series<HtxFrame>
typealias HtxExchangeResult = Join<HtxExchangeState, HtxFrames>

fun emptyHtxFrames(): HtxFrames = emptySeriesOf()

fun htxFrames(vararg frames: HtxFrame): HtxFrames = frames.toSeries() // Bolt: Use .toSeries() directly to avoid intermediate List allocation

fun HtxExchangeResult(
    state: HtxExchangeState,
    frames: HtxFrames = emptyHtxFrames(),
): HtxExchangeResult = state j frames

val HtxExchangeResult.state: HtxExchangeState get() = a
val HtxExchangeResult.frames: HtxFrames get() = b

enum class HtxFlowStage {
    REQUEST,
    RESPONSE,
    FAILURE,
}

sealed class DhtxMessage {
    abstract val correlationId: String
}

data class DhtxReq(
    override val correlationId: String,
    val payload: Series<Byte>
) : DhtxMessage()

data class DhtxRes(
    override val correlationId: String,
    val payload: Series<Byte>
) : DhtxMessage()

data class DhtxExchange(
    val req: DhtxReq,
    val res: DhtxRes?,
    val elapsedNanos: Long?
)

enum class HtxExchangeLifecycle {
    CREATED,
    REQUESTED,
    RESPONDED,
    FAILED,
    CLOSED,
}

data class HtxExchangeState(
    val exchangeOrdinal: Long = 0,
    val baseUrl: String = "",
    val lifecycle: HtxExchangeLifecycle = HtxExchangeLifecycle.CREATED,
    val request: HtxRequest? = null,
    val response: HtxResponse? = null,
    val failure: String? = null,
    /** The exception behind [failure], so a caller can tell a TLS codec failure from an outage. */
    val cause: Throwable? = null,
)

data class HtxFrame(
    val exchangeOrdinal: Long,
    val stage: HtxFlowStage,
    val request: HtxRequest? = null,
    val response: HtxResponse? = null,
    val failure: String? = null,
) : FanoutEvent {
    override val eventType: Int = 0x485458
}

interface HtxFrameSubscriber {
    suspend fun onHtxFrames(frames: HtxFrames)
}

interface HtxRouteService : CoroutineContext.Element {
    companion object Key : CoroutineContext.Key<HtxRouteService>
    override val key: CoroutineContext.Key<*> get() = Key

    suspend fun exchange(
        state: HtxExchangeState,
        request: HtxRequest,
    ): HtxExchangeResult
}

object HtxKey : CoroutineContext.Key<HtxElement>

open class HtxElement(
    val baseUrl: String = "",
    private val routeService: HtxRouteService,
    parentJob: Job? = null,
    private val ownedSupervisor: NioSupervisor? = null,
    private val ownedRouteService: Drain? = null,
    val fanoutSubscribers: List<CoroutineContext.Element> = emptyList(),
) : CoroutineContext.Element, Drain {
    override val key: CoroutineContext.Key<*> get() = HtxKey
    val supervisor: CompletableJob = SupervisorJob(parentJob)

    private var nextExchangeOrdinal: Long = 1

    open suspend fun exchange(
        request: HtxRequest,
    ): HtxExchangeResult {
        val normalizedRequest = request.copy(
            target = request.target.copy(
                requestPath = normalizePath(request.target.requestPath),
            ),
        )
        val exchangeState = HtxExchangeState(
            exchangeOrdinal = nextExchangeOrdinal++,
            baseUrl = baseUrl,
            lifecycle = HtxExchangeLifecycle.CREATED,
        )
        val result = routeService.exchange(exchangeState, normalizedRequest)
        channelize(result.frames)
        return result
    }

    open suspend fun request(request: HtxRequest): HtxResponse {
        val result = exchange(request)

        return result.state.response ?: error(
            result.state.failure ?: "HTX route service did not produce a response.",
        )
    }

    open suspend fun request(
        method: String,
        path: String,
        headers: HtxHeaders = emptyHtxHeaders(),
    ): HtxResponse =
        request(
            parseHtxRequest(
                url = resolveRequestUrl(path),
                method = methodFromToken(method),
            ).copy(
                headers = headers,
            ),
        )

    /**
     * Request that returns [Result] shaped by 200/non-200 status.
     * [Result.success] for 2xx, [Result.failure] with status + body for non-2xx.
     */
    open suspend fun requestResult(request: HtxRequest): Result<HtxResponse> {
        val resp = request(request)
        return if (resp.status in 200..299) {
            Result.success(resp)
        } else {
            val body = resp.body.toArray().decodeToString().take(500)
            Result.failure(borg.trikeshed.htx.HtxHttpError(resp.status, body))
        }
    }

    internal suspend fun channelize(frames: HtxFrames) {
        fanoutSubscribers.forEach {
            if (it is HtxFrameSubscriber) {
                it.onHtxFrames(frames)
            }
        }

        // Bolt: Prevent intermediate List allocations with filterIsInstance<T>()
        // and avoid O(F*S) scaling by fast-path checking subscriber presence first
        if (fanoutSubscribers.any { it is FanoutEventSubscriber }) {
            frames.forEach { frame ->
                fanoutSubscribers.forEach {
                    if (it is FanoutEventSubscriber) {
                        it.onFanoutEvent(frame)
                    }
                }
            }
        }
    }

    /** Completes the supervisor once its children finish, then closes. */
    override suspend fun drain() {
        supervisor.complete()
        supervisor.join()
        close()
    }

    suspend fun close() {
        ownedRouteService?.drain()
        ownedSupervisor?.close()
        supervisor.cancelAndJoin()
    }
}

suspend fun openHtxElement(
    baseUrl: String = "",
    routeService: HtxRouteService? = null,
    nioSupervisor: NioSupervisor? = null,
    parentJob: Job? = null,
    subscribers: List<CoroutineContext.Element> = emptyList(),
): HtxElement {
    val contextRouteService = currentCoroutineContext()[HtxRouteService.Key]
    val contextSupervisor = currentCoroutineContext()[NioSupervisor.Key]
    val activeSupervisor = nioSupervisor ?: contextSupervisor ?: NioSupervisor()
    val ownsSupervisor = nioSupervisor == null && contextSupervisor == null

    if (!activeSupervisor.opened.isCompleted && activeSupervisor.admission.isActive) {
        activeSupervisor.open()
    }

    val resolvedService = routeService
        ?: contextRouteService
        ?: activeSupervisor.service<HtxRouteService>()
        ?: error("No HtxRouteService in the coroutine context or the NioSupervisor.")

    return HtxElement(
        baseUrl = baseUrl,
        routeService = resolvedService,
        parentJob = parentJob,
        ownedSupervisor = activeSupervisor.takeIf { ownsSupervisor },
        fanoutSubscribers = subscribers,
    )
}

private fun normalizePath(path: String): String =
    if (path.startsWith("/")) path else "/$path"

private fun methodFromToken(method: String): HtxMethod =
    when (method.uppercase()) {
        "GET" -> HtxMethod.GET
        "HEAD" -> HtxMethod.HEAD
        "POST" -> HtxMethod.POST
        "PUT" -> HtxMethod.PUT
        "PATCH" -> HtxMethod.PATCH
        "DELETE" -> HtxMethod.DELETE
        "OPTIONS" -> HtxMethod.OPTIONS
        else -> error("Unsupported HTX method: $method")
    }

private fun HtxElement.resolveRequestUrl(path: String): String {
    if ("://" in path) {
        return path
    }
    val normalizedPath = normalizePath(path)
    val origin = if (baseUrl.isBlank()) "http://127.0.0.1" else baseUrl.trimEnd('/')
    return origin + normalizedPath
}
