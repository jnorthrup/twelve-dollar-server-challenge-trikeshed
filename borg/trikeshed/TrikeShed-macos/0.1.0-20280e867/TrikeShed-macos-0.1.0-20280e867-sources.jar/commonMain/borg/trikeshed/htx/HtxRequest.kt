package borg.trikeshed.htx

import borg.trikeshed.lib.*

typealias HtxHeader = Join<String, String>
typealias HtxHeaders = Series<HtxHeader>
typealias HtxAuthority = Join<String, Int>
typealias HtxBody = ByteSeries

fun emptyHtxHeaders(): HtxHeaders = emptySeriesOf()
fun emptyHtxBody(): HtxBody = ByteSeries(byteArrayOf())
fun htxHeaders(vararg headers: HtxHeader): HtxHeaders = headers.toSeries() // Bolt: Use .toSeries() directly to avoid intermediate List allocation

enum class HtxScheme {
    HTTP,
    HTTPS,
    IPFS,
}

enum class HtxTransportProtocol {
    HTTP,
    HTTPS,
}

enum class HtxMethod {
    GET,
    HEAD,
    POST,
    PUT,
    PATCH,
    DELETE,
    OPTIONS,
}

enum class HtxFetchStyle {
    CURL,
    ARIA2,
    IPFS_GATEWAY,
}

data class HtxRange(
    val startInclusive: Long,
    val endInclusive: Long,
)

data class HtxTarget(
    val scheme: HtxScheme,
    val transportProtocol: HtxTransportProtocol,
    val authority: HtxAuthority,
    val requestPath: String,
    val resourceId: String? = null,
) {
    val host: String get() = authority.a
    val port: Int get() = authority.b
}

data class HtxRequest(
    val target: HtxTarget,
    val method: HtxMethod = HtxMethod.GET,
    val fetchStyle: HtxFetchStyle = HtxFetchStyle.CURL,
    val headers: HtxHeaders = emptyHtxHeaders(),
    val range: HtxRange? = null,
    val body: HtxBody = emptyHtxBody(),
    /** Whole transport exchange budget, including TLS and the response body. */
    val timeoutMs: Long = DEFAULT_TIMEOUT_MS,
    /** Maximum HTTP response bytes, including headers/framing; checked before accumulator growth. */
    val maxResponseBytes: Int = Int.MAX_VALUE,
) {
    init {
        require(timeoutMs in 1..Int.MAX_VALUE.toLong()) {
            "HTX timeout must be between 1 and ${Int.MAX_VALUE} ms"
        }
        require(maxResponseBytes > 0) { "HTX response byte limit must be positive" }
    }

    companion object {
        const val DEFAULT_TIMEOUT_MS: Long = 30_000L
    }
}

data class HtxResponse(
    val status: Int,
    val body: HtxBody = emptyHtxBody(),
    val headers: HtxHeaders = emptyHtxHeaders(),
)

data class HtxClientConfig(
    val ipfsGatewayProtocol: HtxTransportProtocol = HtxTransportProtocol.HTTP,
    val ipfsGatewayHost: String = "127.0.0.1",
    val ipfsGatewayPort: Int = 8080,
)

fun parseHtxRequest(
    url: String,
    config: HtxClientConfig = HtxClientConfig(),
    range: HtxRange? = null,
    method: HtxMethod = HtxMethod.GET,
    body: HtxBody = emptyHtxBody(),
): HtxRequest {
    val scheme = when (url.substringBefore("://").lowercase()) {
        "http" -> HtxScheme.HTTP
        "https" -> HtxScheme.HTTPS
        "ipfs" -> HtxScheme.IPFS
        else -> error("Unsupported HTX scheme in URL: $url")
    }

    return HtxRequest(
        target = when (scheme) {
            HtxScheme.HTTP -> parseHttpTarget(url, scheme, HtxTransportProtocol.HTTP, 80)
            HtxScheme.HTTPS -> parseHttpTarget(url, scheme, HtxTransportProtocol.HTTPS, 443)
            HtxScheme.IPFS -> parseIpfsTarget(url, config)
        },
        method = method,
        fetchStyle = when {
            scheme == HtxScheme.IPFS -> HtxFetchStyle.IPFS_GATEWAY
            range != null -> HtxFetchStyle.ARIA2
            else -> HtxFetchStyle.CURL
        },
        range = range,
        body = body,
    )
}

fun HtxRequest.renderWireRequest(): String {
    val methodToken = method.wireToken()
    val hostHeader = if (target.port == target.transportProtocol.defaultPort()) {
        target.host
    } else {
        "${target.host}:${target.port}"
    }

    return buildString {
        append(methodToken)
        append(' ')
        append(target.requestPath)
        append(" HTTP/1.1\r\n")
        append("Host: ")
        append(hostHeader)
        append("\r\n")
        headers.forEach { header ->
            append(header.a)
            append(": ")
            append(header.b)
            append("\r\n")
        }
        if (body.rem > 0 && headerValue("Content-Length") == null) {
            append("Content-Length: ")
            append(body.rem)
            append("\r\n")
        }
        append("Connection: close\r\n")
        range?.let {
            append("Range: bytes=${it.startInclusive}-${it.endInclusive}\r\n")
        }
        append("\r\n")
    }
}

fun HtxRequest.headerValue(name: String): String? = headers.headerValue(name)

fun HtxRequest.withHeader(name: String, value: String): HtxRequest {
    val preserved = headers.toList().filterNot { it.a.equals(name, ignoreCase = true) }
    return copy(headers = (preserved + (name j value)).toSeries())
}

fun HtxRequest.withTransportDefaults(): HtxRequest =
    if (headerValue("Accept-Encoding") != null) this else withHeader("Accept-Encoding", "identity")

fun parseHtxResponse(payload: HtxBody): HtxResponse {
    val bytes = payload.toArray()
    val boundary = bytes.indexOfHeaderBoundary()
    if (boundary < 0) {
        return HtxResponse(status = 0, body = ByteSeries(bytes))
    }

    val headerText = bytes.decodeToString(0, boundary)
    val lines = headerText.split("\r\n")
    val status = lines.firstOrNull()
        ?.split(' ')
        ?.getOrNull(1)
        ?.toIntOrNull()
        ?: 0
    val headers = lines.drop(1).mapNotNull(::parseHeaderLine).toSeries()
    val encodedBody = bytes.copyOfRange(boundary + 4, bytes.size)
    val contentLengthVal = headers.headerValue("Content-Length")?.trim()?.toIntOrNull()
    val decodedBody = when {
        headers.headerValue("Transfer-Encoding")?.contains("chunked", ignoreCase = true) == true ->
            decodeChunkedBody(encodedBody)
        contentLengthVal != null -> {
            encodedBody.copyOf(minOf(contentLengthVal, encodedBody.size))
        }
        else -> encodedBody
    }

    return HtxResponse(
        status = status,
        body = ByteSeries(decodedBody),
        headers = headers,
    )
}

private fun parseHttpTarget(
    url: String,
    scheme: HtxScheme,
    transportProtocol: HtxTransportProtocol,
    defaultPort: Int,
): HtxTarget {
    val withoutScheme = url.substringAfter("://")
    val authority = withoutScheme.substringBefore("/")
    // An IPv6 literal keeps its brackets, as the url crate's host_str and the Host header write it.
    val hostEnd = if (authority.startsWith('[')) authority.indexOf(']') + 1 else authority.indexOf(':').takeIf { it >= 0 } ?: authority.length
    val host = authority.substring(0, hostEnd)
    val port = authority.substring(hostEnd).removePrefix(":").toIntOrNull() ?: defaultPort
    val pathSuffix = withoutScheme.substringAfter("/", "")
    val requestPath = if (pathSuffix.isEmpty()) "/" else "/$pathSuffix"
    return HtxTarget(
        scheme = scheme,
        transportProtocol = transportProtocol,
        authority = host j port,
        requestPath = requestPath,
    )
}

private fun parseIpfsTarget(
    url: String,
    config: HtxClientConfig,
): HtxTarget {
    val withoutScheme = url.substringAfter("://")
    val cid = withoutScheme.substringBefore("/")
    check(cid.isNotEmpty()) { "IPFS URL requires a CID: $url" }
    val suffix = withoutScheme.substringAfter("/", "")
    val requestPath = buildString {
        append("/ipfs/")
        append(cid)
        if (suffix.isNotEmpty()) {
            append('/')
            append(suffix)
        }
    }
    return HtxTarget(
        scheme = HtxScheme.IPFS,
        transportProtocol = config.ipfsGatewayProtocol,
        authority = config.ipfsGatewayHost j config.ipfsGatewayPort,
        requestPath = requestPath,
        resourceId = cid,
    )
}

private fun HtxTransportProtocol.defaultPort(): Int =
    when (this) {
        HtxTransportProtocol.HTTP -> 80
        HtxTransportProtocol.HTTPS -> 443
    }

fun HtxHeaders.headerValue(name: String): String? {
    for (i in 0 until size) {
        val header = this[i]
        if (header.a.equals(name, ignoreCase = true)) {
            return header.b
        }
    }
    return null
}

private fun HtxMethod.wireToken(): String =
    when (this) {
        HtxMethod.GET -> "GET"
        HtxMethod.HEAD -> "HEAD"
        HtxMethod.POST -> "POST"
        HtxMethod.PUT -> "PUT"
        HtxMethod.PATCH -> "PATCH"
        HtxMethod.DELETE -> "DELETE"
        HtxMethod.OPTIONS -> "OPTIONS"
    }

fun parseHeaderLine(line: String): HtxHeader? {
    val delimiter = line.indexOf(':')
    if (delimiter <= 0) {
        return null
    }
    val name = line.substring(0, delimiter).trim()
    val value = line.substring(delimiter + 1).trim()
    return name.takeIf { it.isNotEmpty() }?.let { it j value }
}

fun ByteArray.indexOfHeaderBoundary(): Int {
    if (size < 4) {
        return -1
    }
    for (i in 0..size - 4) {
        if (this[i] == '\r'.code.toByte() &&
            this[i + 1] == '\n'.code.toByte() &&
            this[i + 2] == '\r'.code.toByte() &&
            this[i + 3] == '\n'.code.toByte()
        ) {
            return i
        }
    }
    return -1
}

private fun decodeChunkedBody(encodedBody: ByteArray): ByteArray {
    val decoded = ArrayList<Byte>()
    require(HtxChunkFraming().advance(encodedBody) { start, end ->
        for (i in start until end) {
            decoded += encodedBody[i]
        }
    }) { "Incomplete HTTP chunked body" }
    return ByteArray(decoded.size) { decoded[it] }
}

/** Incremental HTTP chunk framing; offsets address the retained wire buffer, including trailers. */
internal class HtxChunkFraming(private var offset: Int = 0) {
    private var chunkSize = -1
    private var trailers = false
    private var complete = false

    fun advance(bytes: ByteArray, limit: Int = bytes.size, body: (Int, Int) -> Unit = { _, _ -> }): Boolean {
        while (!complete) {
            if (trailers || chunkSize < 0) {
                val lineEnd = bytes.indexOfCrLf(offset, limit)
                if (lineEnd < 0) return false
                val line = bytes.decodeToString(offset, lineEnd)
                offset = lineEnd + 2
                if (trailers) {
                    if (line.isEmpty()) complete = true
                    else require(parseHeaderLine(line) != null) { "Invalid HTTP chunk trailer" }
                } else {
                    val hex = line.substringBefore(';').trim()
                    require(hex.isNotEmpty() && hex.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) {
                        "Invalid HTTP chunk size"
                    }
                    chunkSize = requireNotNull(hex.toIntOrNull(16)) { "HTTP chunk size exceeds supported range" }
                    trailers = chunkSize == 0
                }
            } else {
                if (chunkSize > limit - offset - 2) return false
                val end = offset + chunkSize
                require(bytes[end] == '\r'.code.toByte() && bytes[end + 1] == '\n'.code.toByte()) {
                    "Invalid HTTP chunk data terminator"
                }
                body(offset, end)
                offset = end + 2
                chunkSize = -1
            }
        }
        return true
    }
}

private fun ByteArray.indexOfCrLf(start: Int, limit: Int = size): Int {
    for (i in start until limit - 1) {
        if (this[i] == '\r'.code.toByte() && this[i + 1] == '\n'.code.toByte()) {
            return i
        }
    }
    return -1
}
