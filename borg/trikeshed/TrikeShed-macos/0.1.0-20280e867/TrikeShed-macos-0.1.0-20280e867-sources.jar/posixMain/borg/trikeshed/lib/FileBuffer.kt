@file:OptIn(ExperimentalForeignApi::class, ExperimentalForeignApi::class)

package borg.trikeshed.lib
import borg.trikeshed.lib.longp.LongSeries
import kotlinx.cinterop.*
import platform.posix.munmap
import platform.posix.PROT_READ
import platform.posix.PROT_WRITE
import simple.PosixFile
import simple.PosixOpenOpts
import kotlin.coroutines.CoroutineContext

actual class FileBuffer actual constructor(
    actual val filename: String,
    actual val initialOffset: Long,
    actual val blkSize: Long,
    actual val readOnly: Boolean,
    actual val closeChannelOnMap: Boolean,
) : LongSeries<Byte>, CoroutineContext.Element {
    actual override val key: CoroutineContext.Key<*> get() = Key
    actual companion object Key : CoroutineContext.Key<FileBuffer>

    init {
        logDebug { "native FileBuffer: $filename, $initialOffset, $blkSize, $readOnly" }
    }

    @OptIn(ExperimentalForeignApi::class)
    var buffer: COpaquePointer? = null
    var file: PosixFile? = null
    private var mappedLength: ULong = 0u

    actual override val a: Long by lazy {
        open()
        if (blkSize == (-1L)) file!!.size else blkSize
    }

    @OptIn(ExperimentalForeignApi::class)
    actual override val b: (Long) -> Byte
        get() = { index: Long ->
            (buffer!!.toLong() + index).toCPointer<ByteVar>()!!.pointed.value
        }

    actual fun close() {
        logDebug { "closing $filename" }
        buffer?.let { mapped ->
            if (mappedLength > 0u) munmap(mapped, mappedLength)
        }
        file?.close()
        file = null
        buffer = null
        mappedLength = 0u
    }

    actual fun open(): Unit = memScoped  {
        if (buffer != null) return
        logDebug { "opening $filename" }
        file = PosixFile(
            path = filename,
            O_FLAGS = if (readOnly) PosixOpenOpts.withFlags(PosixOpenOpts.OpenReadOnly)
            else PosixOpenOpts.withFlags(PosixOpenOpts.O_Rdwr),
        )
        val len: ULong = if (blkSize == (-1L)) file!!.size.toULong() else blkSize.toULong()
        buffer = file!!.mmap(len, prot = PROT_READ or if (readOnly) 0 else PROT_WRITE, offset = initialOffset)
        mappedLength = len
    }

    actual fun isOpen(): Boolean = buffer != null
    actual fun size(): Long = file!!.size

    actual fun get(index: Long): Byte =
        (buffer!!.toLong() + index).toCPointer<ByteVar>()!!.pointed.value

    actual fun put(index: Long, value: Byte) {
        check(!readOnly) { "FileBuffer is read-only" }
        (buffer!!.toLong() + index).toCPointer<ByteVar>()!!.pointed.value = value
    }
}
