package borg.trikeshed.isam.meta

import borg.trikeshed.common.Usable
import borg.trikeshed.couch.isam.FileBackedStringpool
import borg.trikeshed.cursor.ColumnMeta
import borg.trikeshed.isam.RecordMeta
import borg.trikeshed.isam.IsamFileOperations
import borg.trikeshed.lib.*
import borg.trikeshed.userspace.nio.file.spi.FileOperations
import kotlin.math.min

/**
 * 1. create a class that can read the metadata file and create a collection of record constraints
 *
 * the isam metafile format follows this sample
 *
 * ```
 * # format:  coords WS .. EOL names WS .. EOL TypeMememento WS ..
 * # last coord is the recordlen
 * 0 12 12 24 24 32 32 40 40 48 48 56 56 64 64 72 72 76 76 84 84 92
 * Open_time Close_time Open High Low Close Volume Quote_asset_volume Number_of_trades Taker_buy_base_asset_volume Taker_buy_quote_asset_volume
 * IoInstant IoInstant IoDouble IoDouble IoDouble IoDouble IoDouble IoDouble IoInt IoDouble IoDouble
 * ```
 *
 * the ebnf we can use is:
 *
 * ```
 * metafile :=  (coords WS names WS .. EOL)*
 * coords :=  (coord WS)* coord
 * coord :=  number
 * names :=  (name WS)* name
 * name :=  string
 * TypeMemento :=  (IoType WS)* IoType
 * IoType :=  IoInstant | IoDouble | IoString | IoInt
 * ```
 *  2. create a class that can create the binary file
 *
 * the binary file format follows this sample
 *
 *
 */
class IsamMetaFileReader private constructor(
    val metafileFilename: String,
    private val readLines: (String) -> List<String>,
    private val explicitFiles: Boolean,
    private val pool: (String) -> FileBackedStringpool = { FileBackedStringpool(it) },
) : Usable {
    constructor(metafileFilename: String, fileOps: FileOperations? = null) :
        this(metafileFilename, fileOps?.let { it::readAllLines } ?: IsamFileOperations()::readAllLines, fileOps != null)

    internal constructor(metafileFilename: String, files: IsamFileOperations,
                         pool: (String) -> FileBackedStringpool = { FileBackedStringpool(it) }) :
        this(metafileFilename, files::readAllLines, true, pool)

    internal fun withDefaultFiles(files: IsamFileOperations,
                                  pool: (String) -> FileBackedStringpool = this.pool): IsamMetaFileReader =
        IsamMetaFileReader(metafileFilename, if (explicitFiles) readLines else files::readAllLines, true, pool)

    val recordlen: Int get() = constraints.last().end
    val constraints: Series<RecordMeta> get() {
        if (constraints1 == null) open()
        return requireNotNull(constraints1)
    }

    private var constraints1: Series<RecordMeta>? = null

    override fun open() {
        constraints1 = null
        val lines = readLines(metafileFilename).filterNot { it.isBlank() || it.trim().startsWith('#') }
        require(lines.size in 3..5) { "ISAM metadata requires coordinates, names, types, then optional groups and pools" }

        val coords: Series<String> = CharSeries(lines[0]).trim.splitWs() α CharSeries::asString
        val names: Series<String> = CharSeries(lines[1]).trim.splitWs() α CharSeries::asString
        val types: Series<String> = CharSeries(lines[2]).trim.splitWs() α CharSeries::asString

        require(names.size > 0 && types.size == names.size && coords.size.toLong() == names.size.toLong() * 2) {
            "ISAM metadata column counts disagree"
        }
        var tail = 3
        val groupsLine = if (lines.size > tail && !pooled(lines[tail])) lines[tail++].trim() else ""
        val poolsLine = if (lines.size > tail) lines[tail++].trim() else ""
        require(tail == lines.size && (poolsLine.isEmpty() || pooled(poolsLine))) { "ISAM metadata lists groups before pools" }
        val groupSeries: Series<Join<Int, String>> = if (groupsLine.isNotEmpty()) {
            parseGroupsLine(groupsLine, names.size)
        } else {
            names.size j { _: Int -> 0 j "0" }
        }
        val pools = arrayOfNulls<FileBackedStringpool>(names.size)
        if (poolsLine.isNotEmpty()) {
            val directory = directoryOf(metafileFilename)
            val opened = mutableMapOf<String, FileBackedStringpool>()
            for (token in CharSeries(poolsLine).trim.splitWs()) {
                val text = token.asString()
                val eq = text.indexOf('=')
                require(eq > 0) { "Invalid ISAM pool token" }
                val index = text.substring(0, eq).toInt()
                val name = text.substring(eq + 1)
                require(index in 0 until names.size && pools[index] == null && nameable(name)) { "Invalid ISAM pool token" }
                pools[index] = opened.getOrPut(name) { pool(directory + name) }
            }
        }

        val parsed = Array(names.size) { index ->
            val begin = coords[2 * index].toInt()
            val end = coords[2 * index + 1].toInt()
            require(begin >= 0 && end > begin) { "ISAM columns require positive fixed widths" }
            val (groupId, groupName) = groupSeries[index]
            val ioMemento: IOMemento = IOMemento.valueOf(types[index])
            val decoder = ioMemento.createDecoder(end - begin)
            val encoder = ioMemento.createEncoder(end - begin)
            val recordMeta = RecordMeta(names[index], ioMemento, begin, end, decoder, encoder)
            recordMeta.groupId = groupId
            recordMeta.groupName = groupName
            recordMeta.pool = pools[index]
            recordMeta
        }.toSeries()
        validate(parsed)
        constraints1 = parsed
    }

    override fun close() {
        constraints1 = null
    }

    //toString
    override fun toString(): String {
        return "IsamMetaFileReader(metafileFilename='$metafileFilename', recordlen=$recordlen, constraints=$constraints)"
    }

    /** metafile writer function
     * 1. open the metafile descriptor for writing
     * 1. write the file from a collection of record constraints
     * 1. close the file descriptor
     */
    companion object {
        fun parseGroupsLine(line: String, colCount: Int): Series<Join<Int, String>> {
            require(colCount > 0) { "ISAM requires columns" }
            val colToGroupName = mutableMapOf<Int, String>()
            val mentionedGroups = mutableListOf<String>()

            val cs = CharSeries(line).trim
            val tokens: Series<CharSeries> = cs.splitWs()
            for (token in tokens) {
                val colonIdx = token.asString().lastIndexOf(':')
                require(colonIdx > 0 && colonIdx == token.asString().indexOf(':')) { "Invalid ISAM group token" }
                val colListCs  = token.clone().lim(token.pos + colonIdx)
                val groupName  = token.clone().pos(token.pos + colonIdx + 1).asString()
                validateGroupName(groupName)
                if (groupName !in mentionedGroups) mentionedGroups.add(groupName)
                val colSpecs: Series<CharSeries> = (CharSeries(colListCs.asString()) / ',') α { CharSeries(it) }
                for (spec in colSpecs) {
                    val specs = spec.trim
                    val dashIdx = specs.asString().indexOf('-')
                    if (dashIdx > 0) {
                        val lo = specs.clone().lim(specs.pos + dashIdx).asString().toInt()
                        val hi = specs.clone().pos(specs.pos + dashIdx + 1).asString().toInt()
                        require(lo in 0 until colCount && hi in lo until colCount) { "ISAM group range is outside the columns" }
                        for (k in lo..hi) {
                            require(colToGroupName.put(k, groupName) == null) { "ISAM column belongs to multiple groups" }
                        }
                    } else {
                        val index = specs.asString().toInt()
                        require(index in 0 until colCount) { "ISAM group index is outside the columns" }
                        require(colToGroupName.put(index, groupName) == null) { "ISAM column belongs to multiple groups" }
                    }
                }
            }

            var implicitName = mentionedGroups.size.toString()
            while (implicitName in mentionedGroups) implicitName = "_$implicitName"
            val implicitGroupId = mentionedGroups.size

            return colCount j { idx: Int ->
                val gname = colToGroupName[idx] ?: implicitName
                val gid = if (gname == implicitName) {
                    implicitGroupId
                } else {
                    val pos = mentionedGroups.indexOf(gname)
                    if (pos >= 0) pos else implicitGroupId
                }
                gid j gname
            }
        }

        fun write(
            metafilename: String,
            recordMetas: Series<ColumnMeta>,
            varchars: Map<String, Int>,
            fileOps: FileOperations? = null,
            useMonocursorGroupings: Boolean = true
        ): Series<RecordMeta> = writeMetadata(metafilename, recordMetas, varchars,
            { path, lines -> if (fileOps != null) fileOps.write(path, lines) else IsamFileOperations().write(path, lines) },
            useMonocursorGroupings)

        internal fun write(
            metafilename: String,
            recordMetas: Series<ColumnMeta>,
            varchars: Map<String, Int>,
            metadataFiles: IsamFileOperations,
            useMonocursorGroupings: Boolean = true,
        ): Series<RecordMeta> = writeMetadata(metafilename, recordMetas, varchars, metadataFiles::write, useMonocursorGroupings)

        private fun writeMetadata(
            metafilename: String,
            recordMetas: Series<ColumnMeta>,
            varchars: Map<String, Int>,
            writeLines: (String, List<String>) -> Unit,
            useMonocursorGroupings: Boolean,
        ): Series<RecordMeta> {
            val lines = mutableListOf<String>()

            val result = sanitize(recordMetas, varchars, useMonocursorGroupings)
            lines.add("# format:  coords WS .. EOL names WS .. EOL TypeMememento WS .. [EOL]")
            lines.add("# last coord is the recordlen")
            lines.add(result.view.joinToString(" ") { it.begin.toString() + " " + it.end })
            lines.add(result.view.joinToString(" ") { it.name })
            lines.add(result.view.joinToString(" ") { it.type.name })

            val distinctGroups = result.view.map { it.groupId }.toSet()
            if (distinctGroups.size > 1) {
                val maxGroupId = distinctGroups.maxOrNull() ?: 0

                val byGroup = linkedMapOf<String, MutableList<Int>>()
                result.view.forEachIndexed { idx, rm ->
                    if (rm.groupId != maxGroupId)
                        byGroup.getOrPut(rm.groupName) { mutableListOf() }.add(idx)
                }

                val groupTokens = byGroup.entries.map { (gname, cols) ->
                    "${buildColList(cols)}:$gname"
                }
                if (groupTokens.isNotEmpty()) lines.add(groupTokens.joinToString(" "))
            }
            val directory = directoryOf(metafilename)
            val poolTokens = result.view.mapIndexedNotNull { idx, rm ->
                rm.pool?.location?.let { location ->
                    val name = location.removePrefix(directory)
                    require(location.startsWith(directory) && nameable(name)) { "ISAM pool $location must be a file beside $metafilename" }
                    "$idx=$name"
                }
            }
            if (poolTokens.isNotEmpty()) lines.add(poolTokens.joinToString(" "))

            writeLines(metafilename, lines)
            return result
        }

        private fun buildColList(cols: List<Int>): String {
            if (cols.isEmpty()) return ""
            val sorted = cols.sorted()
            val sb = StringBuilder()
            var start = sorted[0]
            var prev = sorted[0]
            fun flush() {
                if (sb.isNotEmpty()) sb.append(',')
                if (start == prev) sb.append(start) else sb.append("$start-$prev")
            }
            for (i in 1 until sorted.size) {
                if (sorted[i] == prev + 1) { prev = sorted[i] }
                else { flush(); start = sorted[i]; prev = sorted[i] }
            }
            flush()
            return sb.toString()
        }

        fun sanitize(
            recordMetas: Series<ColumnMeta>,
            varchars: Map<String, Int>,
            useMonocursorGroupings: Boolean = true
        ): Series<RecordMeta> {
            require(recordMetas.size > 0) { "ISAM requires column metadata" }
            val result = if (recordMetas.view.any { it !is RecordMeta || (min(it.begin, it.end) < 0 && it.child == null) } || useMonocursorGroupings) {
                var offset = 0
                recordMetas.view.map { columnMeta: ColumnMeta ->
                    val name = columnMeta.name.toString()
                    val type = columnMeta.type as? IOMemento ?: throw IllegalArgumentException("No ISAM codec for $name")
                    val len = type.networkSize ?: varchars[name] ?: throw IllegalArgumentException("No fixed width for $name")
                    require(len > 0 && offset <= Int.MAX_VALUE - len) { "ISAM row length exceeds buffer capacity or has a nonpositive width" }
                    val existingGroupId = (columnMeta as? RecordMeta)?.groupId ?: 0
                    val existingGroupName = (columnMeta as? RecordMeta)?.groupName ?: "0"

                    val (groupId, groupName) = if (useMonocursorGroupings && (existingGroupName == "0" || existingGroupName == "default")) {
                        type.ordinal to type.name
                    } else {
                        existingGroupId to existingGroupName
                    }

                    val recordMeta = RecordMeta(
                        name = name,
                        type = type,
                        begin = offset,
                        end = offset + len,
                        decoder = type.createDecoder(len),
                        encoder = type.createEncoder(len),
                        provenance = (columnMeta as? RecordMeta)?.provenance,
                    ).also {
                        it.groupId = groupId
                        it.groupName = groupName
                        it.pool = (columnMeta as? RecordMeta)?.pool
                    }
                    offset += len
                    recordMeta
                }.toSeries()
            } else recordMetas as Series<RecordMeta>
            validate(result)
            return result
        }

        /** Group and pool names name files beside the data file. */
        fun nameable(name: String): Boolean = name.isNotEmpty() && name.none { it.isWhitespace() || it <= ' ' || it in ":/\\" }

        /** A pools line maps dictionary columns to their pool files (`1=key.pool`); a groups token starts `0-3:` or `0,2:`. */
        fun pooled(line: String): Boolean {
            val text = line.trim()
            val k = text.indexOfFirst { !it.isDigit() }
            return k > 0 && text[k] == '='
        }

        fun directoryOf(path: String): String = path.substring(0, maxOf(path.lastIndexOf('/'), path.lastIndexOf('\\')) + 1)

        private fun validateGroupName(name: String) {
            require(nameable(name)) { "Invalid ISAM group name" }
        }

        private fun validate(metadata: Series<RecordMeta>) {
            require(metadata.size > 0) { "ISAM requires column metadata" }
            val groupIds = mutableMapOf<String, Int>()
            val groupNames = mutableMapOf<Int, String>()
            var offset = 0
            for (column in metadata.view) {
                require(column.name.isNotEmpty() && !column.name.startsWith('#') && column.name.none { it.isWhitespace() || it <= ' ' }) {
                    "Invalid ISAM column name"
                }
                require(column.begin == offset && column.end > column.begin) { "ISAM column offsets must be contiguous and positive" }
                val width = column.end - column.begin
                require(column.type.networkSize == null || column.type.networkSize == width) { "ISAM codec width differs from metadata for ${column.name}" }
                validateGroupName(column.groupName)
                require(column.groupId >= 0 && groupIds.getOrPut(column.groupName) { column.groupId } == column.groupId &&
                    groupNames.getOrPut(column.groupId) { column.groupName } == column.groupName) { "ISAM group names and identifiers disagree" }
                offset = column.end
            }
        }
    }
}
