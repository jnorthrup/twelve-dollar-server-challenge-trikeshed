package borg.trikeshed.job

import borg.trikeshed.collections.associative.Cbor
import borg.trikeshed.collections.associative.Item
import borg.trikeshed.collections.associative.itemArrayOf
import borg.trikeshed.collections.associative.itemMapOf
import borg.trikeshed.collections.associative.toItem
import borg.trikeshed.collections.associative.toAny
import borg.trikeshed.cursor.IOMemento
import borg.trikeshed.lib.get
import borg.trikeshed.lib.size
import borg.trikeshed.parse.confix.ConfixDoc
import borg.trikeshed.parse.confix.ConfixCell
import borg.trikeshed.parse.confix.cellKids
import borg.trikeshed.parse.confix.rootCell
import borg.trikeshed.parse.confix.reify
import borg.trikeshed.parse.confix.row
import borg.trikeshed.parse.confix.tag
import borg.trikeshed.parse.confix.value

/**
 * Canonical encoding for ContentId computation.
 *
 * Produces canonical CBOR: definite-length, sorted map keys, minimal encoding.
 * Same logical content always produces the same bytes regardless of input JSON
 * whitespace or key order.
 *
 * Delegates to the existing Cbor codec (RFC 8949) — sorts map keys before encoding
 * to guarantee canonical form.
 */
object CanonicalCbor {

    /** Canonical encode a ConfixDoc to canonical CBOR (sorted-key, definite-length). */
    fun encode(doc: ConfixDoc): ByteArray = Cbor.encode(toCanonical(doc.rootCell?.let { item(it) } ?: itemMapOf()))

    /** [cell] as an [Item]: an object from its flat (key, value) kid pairs, an array from its kids, a scalar reified. */
    fun item(cell: ConfixCell): Item {
        val kids = cell.cellKids
        return when (cell.row.tag) {
            IOMemento.IoObject -> itemMapOf(*Array(kids.size / 2) { (kids[2 * it].reify()?.toString() ?: "") to item(kids[2 * it + 1]) })
            IOMemento.IoArray -> itemArrayOf(List(kids.size) { item(kids[it]) })
            else -> cell.reify().toItem()
        }
    }

    /** Canonical encode a JobCommand to canonical CBOR. */
    @Suppress("UNCHECKED_CAST")
    fun encode(cmd: JobCommand): ByteArray {
        val serializer = JobCommand.serializer() as kotlinx.serialization.KSerializer<JobCommand>
        return borg.trikeshed.parse.confix.ConfixFormat.encodeToByteArray(serializer, cmd)
    }

    /** Decode the canonical command bytes consumed by the reactor and WAL replay. */
    @Suppress("UNCHECKED_CAST")
    fun decodeJobCommand(bytes: ByteArray): JobCommand {
        val serializer = JobCommand.serializer() as kotlinx.serialization.KSerializer<JobCommand>
        val command = borg.trikeshed.parse.confix.ConfixFormat.decodeFromByteArray(serializer, bytes)
        if (command is JobCommand.State) require(encode(command).contentEquals(bytes)) {
            "State command must retain its canonical typed fields"
        }
        return command
    }

    /** Canonical encode any string. */
    fun encode(value: String): ByteArray =
        Cbor.encode(Item.Str(value))

    /** Canonical encode a JobNexusSpec to its canonical bytes. */
    fun encode(spec: JobNexusSpec): ByteArray = spec.canonicalBytes

    /** Decode the canonical bytes of a JobSnapshot. */
    fun decodeJobSnapshot(bytes: ByteArray): JobSnapshot {
        return borg.trikeshed.parse.confix.ConfixFormat.decodeFromByteArray(JobSnapshot.serializer(), bytes)
    }

    /** Canonical encode a JobSnapshot for CID computation. */
    fun encode(snapshot: JobSnapshot): ByteArray {
        // To preserve sorting of dependencies logic if required, we can rely on Confix sorting map keys.
        // If sorting of dependencies themselves is required, it must be done before creating the JobSnapshot
        // or we sort it here and copy. But since they're value objects, they should be created sorted or
        // the serializer will just output what's given.
        // We ensure dependencies are sorted here to maintain previous semantics:
        val sortedDeps = snapshot.dependencies.sortedBy { it.value }
        val copy = if (sortedDeps != snapshot.dependencies) snapshot.copy(dependencies = sortedDeps) else snapshot
        return borg.trikeshed.parse.confix.ConfixFormat.encodeToByteArray(JobSnapshot.serializer(), copy)
    }

    private fun toCanonical(item: Item): Item = when (item) {
        is Item.Map -> {
            val k = item.keys()
            val v = item.values()
            val pairs = mutableListOf<Pair<String, Item>>()
            for (idx in 0 until item.size) {
                pairs.add(k[idx] to toCanonical(v[idx]))
            }
            pairs.sortBy { it.first }
            itemMapOf(*pairs.toTypedArray())
        }
        is Item.Arr -> {
            val arr = mutableListOf<Item>()
            for (idx in 0 until item.size) {
                arr.add(toCanonical(item[idx]))
            }
            itemArrayOf(arr)
        }
        is Item.Tag -> Item.Tag(item.tag, toCanonical(item.item))
        else -> item
    }

    /** Canonical CBOR of a JSON-shaped map (sorted keys, definite lengths). The Couch body-blob format. */
    fun encodeMap(fields: Map<String, Any?>): ByteArray = encodeSortedMap(fields)

    /** Inverse of [encodeMap]: CBOR bytes → JSON-shaped map (String keys, plain values). */
    @Suppress("UNCHECKED_CAST")
    fun decodeMap(bytes: ByteArray): Map<String, Any?> {
        val any = Cbor.decode(bytes).toAny()
        val m = any as? Map<*, *> ?: return emptyMap()
        return m.entries.associate { it.key.toString() to it.value }
    }

    /** Bounded JSON-shaped decode for untrusted bytes; rejects unsupported CBOR structures. */
    fun decodeMapBounded(bytes: ByteArray, maxBytes: Int, maxDepth: Int = 64, maxItems: Int = 1_000_000): Map<String, Any?> {
        val item = Cbor.decodeBounded(bytes, maxBytes, maxDepth, maxItems)
        require(item is Item.Map) { "CBOR root must be a map" }
        @Suppress("UNCHECKED_CAST")
        return item.toAny() as Map<String, Any?>
    }

    private fun encodeSortedMap(fields: Map<String, Any?>): ByteArray {
        val pairs = fields.entries.map { it.key to toCanonical(it.value.toItem()) }.toTypedArray()
        val sortedPairs = pairs.sortedBy { it.first }.toTypedArray()
        return Cbor.encode(itemMapOf(*sortedPairs))
    }
}

/** Operation name for a JobCommand (wire-level string). */
val JobCommand.operationName: String
    get() = when (this) {
        is JobCommand.Submit -> "submit"
        is JobCommand.Update -> "update"
        is JobCommand.Start -> "start"
        is JobCommand.Complete -> "complete"
        is JobCommand.Fail -> "fail"
        is JobCommand.Retry -> "retry"
        is JobCommand.Progress -> "progress"
        is JobCommand.State -> "state"
        is JobCommand.Block -> "block"
        is JobCommand.Cancel -> "cancel"
        is JobCommand.Move -> "move"
        is JobCommand.Acknowledge -> "acknowledge"
        is JobCommand.Retract -> "retract"
    }
