package borg.trikeshed.job

import borg.trikeshed.util.toLowerHex

/**
 * ContentId — SHA-256 over canonical bytes.
 * Format: "sha256:<64 lowercase hex chars>"
 */
data class ContentId(val value: String) {
    init {
        require(
            value.length == SHA256_TEXT_LENGTH &&
                value.startsWith(SHA256_PREFIX) &&
                value.substring(SHA256_PREFIX.length).all { it in LOWER_HEX }
        ) {
            "ContentId must be sha256 followed by 64 lowercase hexadecimal digits"
        }
    }

    companion object {
        fun of(bytes: ByteArray): ContentId {
            val digest = sha256(bytes)
            val hex = digest.toLowerHex()
            return ContentId(SHA256_PREFIX + hex)
        }

        /** Compute ContentId over canonical CBOR of a ConfixDoc. */
        fun of(doc: borg.trikeshed.parse.confix.ConfixDoc): ContentId =
            of(CanonicalCbor.encode(doc))
    }

    val hex: String get() = value.removePrefix("sha256:")
}

private const val LOWER_HEX = "0123456789abcdef"
private const val SHA256_PREFIX = "sha256:"
private const val SHA256_TEXT_LENGTH = 71

/** SHA-256: java.security on JVM, Sha256Pure on JS, Native and Wasm. */
expect fun sha256(bytes: ByteArray): ByteArray
