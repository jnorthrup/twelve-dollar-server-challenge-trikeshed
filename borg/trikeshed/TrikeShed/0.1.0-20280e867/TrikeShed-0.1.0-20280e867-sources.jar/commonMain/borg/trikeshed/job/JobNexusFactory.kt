package borg.trikeshed.job

import borg.trikeshed.parse.confix.confixDoc
import borg.trikeshed.parse.confix.value
import borg.trikeshed.parse.confix.Syntax
import kotlinx.coroutines.CoroutineScope

/**
 * JobNexusFactory — the single effectful composition boundary.
 *
 * Validates capabilities, assembles components in order (scope → CAS → WAL),
 * and rolls back on failure.
 */
object JobNexusFactory {

    fun open(spec: JobNexusSpec, bindings: JobNexusBindings): JobSupervisorElement {
        // Validate bindings
        val scope = bindings.parentScope
            ?: throw IllegalArgumentException("parent scope is required")

        // Capability validation
        if (spec.storage.backend == StorageBackend.File && bindings.fileOps == null) {
            throw IllegalArgumentException("file capability required for File backend")
        }
        if (spec.storage.backend == StorageBackend.LinuxBtrfs && !bindings.linuxStorageAvailable) {
            throw IllegalArgumentException("linux/btrfs capability not available on this platform")
        }

        // Validate spec
        val validationResult = JobNexusSpecValidator.validate(spec)
        if (!validationResult.valid) {
            throw IllegalArgumentException(validationResult.errors.joinToString("; "))
        }

        // Assembly with rollback tracking
        val opened = mutableListOf<String>()
        var orderCounter = 0

        try {
            // scope
            opened.add("scope")
            bindings.closeTrace.add(CloseTraceEntry("scope", ++orderCounter, false))

            // cas
            val cas = bindings.componentFactories.casStoreFactory()
            opened.add("cas")
            bindings.closeTrace.add(CloseTraceEntry("cas", ++orderCounter, false))

            // wal
            val wal = bindings.componentFactories.walFactory()
            opened.add("wal")
            bindings.closeTrace.add(CloseTraceEntry("wal", ++orderCounter, false))

            // Mark all as opened successfully
            return JobSupervisorElement.open(scope, spec.channels.commands, casStore = cas, jobLog = wal)

        } catch (e: Throwable) {
            // Rollback: close all previously opened components in reverse order
            for (compName in opened.reversed()) {
                val entry = bindings.closeTrace.find { it.component == compName && !it.closed }
                if (entry != null) {
                    val idx = bindings.closeTrace.indexOf(entry)
                    bindings.closeTrace[idx] = entry.copy(closed = true)
                }
            }
            // Remove entries for components that were never opened
            val openedSet = opened.toSet()
            bindings.closeTrace.retainAll { it.component in openedSet }
            throw e
        }
    }
}
